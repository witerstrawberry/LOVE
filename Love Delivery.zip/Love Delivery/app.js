// app.js - 小程序入口 App Object
App({
    onLaunch: function (options) {
      // 初始化全局配置
      this.initGlobalConfig();
      // 初始化全局营业状态
      this.initializeBusinessStatus();
      // 不做任何自动路由跳转，保持在当前打开/启动的页面
      // 如需恢复根据角色自动跳转首页的逻辑，可在此处自行添加 wx.reLaunch 相关代码
    },
  
    // 可以提供一个全局方法用于清除身份并退出到选择页
  logout: function () {
    // 清除身份标识和用户信息
    wx.removeStorageSync('selectedRole');
    wx.removeStorageSync('userInfo');
    // 其他清理工作...
    // 重启动到身份选择页
    wx.reLaunch({ url: '/pages/role-select/role-select' });
  },
  
  /**
   * 全局营业状态管理方法
   */
  
  /**
   * 设置全局营业状态
   * @param {boolean} isOpen - 营业状态
   * @param {boolean} silent - 是否静默更新（不触发监听器）
   */
  setGlobalBusinessStatus: function(isOpen, silent = false) {
    this.globalData.merchantBusinessStatus = isOpen;
    
    // 同步到本地存储，确保数据持久化
    try {
      wx.setStorageSync('merchantBusinessStatus', {
        isOpen: isOpen,
        timestamp: Date.now(),
        source: 'globalData'
      });
    } catch (storageError) {
      console.warn('全局状态存储失败:', storageError);
    }
    
    // 如果不是静默更新，触发监听器
    if (!silent && this.businessStatusListeners && this.businessStatusListeners.length > 0) {
      this.businessStatusListeners.forEach(listener => {
        try {
          listener(isOpen);
        } catch (error) {
          console.warn('全局营业状态监听器执行失败:', error);
        }
      });
    }
    
    console.log('全局营业状态已更新:', isOpen);
  },
  
  /**
   * 获取全局营业状态
   * @returns {boolean} - 当前营业状态
   */
  getGlobalBusinessStatus: function() {
    return this.globalData.merchantBusinessStatus || false;
  },
  
  /**
   * 添加营业状态监听器
   * @param {Function} listener - 状态变化监听函数
   * @returns {number} - 监听器ID，用于移除
   */
  addBusinessStatusListener: function(listener) {
    if (!this.businessStatusListeners) {
      this.businessStatusListeners = [];
    }
    
    const listenerId = Date.now() + Math.random();
    this.businessStatusListeners.push({
      id: listenerId,
      callback: listener
    });
    
    return listenerId;
  },
  
  /**
   * 移除营业状态监听器
   * @param {number} listenerId - 监听器ID
   */
  removeBusinessStatusListener: function(listenerId) {
    if (this.businessStatusListeners) {
      this.businessStatusListeners = this.businessStatusListeners.filter(
        listener => listener.id !== listenerId
      );
    }
  },
  
  /**
   * 从本地存储恢复全局营业状态
   */
  restoreBusinessStatusFromStorage: function() {
    try {
      const storedStatus = wx.getStorageSync('merchantBusinessStatus');
      if (storedStatus && typeof storedStatus.isOpen === 'boolean') {
        this.globalData.merchantBusinessStatus = storedStatus.isOpen;
        console.log('从本地存储恢复全局营业状态:', storedStatus.isOpen);
        return storedStatus.isOpen;
      }
    } catch (error) {
      console.warn('恢复全局营业状态失败:', error);
    }
    
    return false; // 默认返回false（打烊状态）
  },
  
  /**
   * 初始化全局营业状态（通常在app启动时调用）
   */
  initializeBusinessStatus: function() {
    const restoredStatus = this.restoreBusinessStatusFromStorage();
    this.setGlobalBusinessStatus(restoredStatus, true); // 静默初始化
  },

  globalData: {
    // 基础域名配置 - 修改此处即可全局更新所有域名
    baseDomain: 'https://baichuang.online/nyxc/',
    // API基础路径（从baseDomain派生，在onLaunch中初始化）
    baseUrl: 'https://baichuang.online/nyxc/api',
    tabBar: null,
    merchantBusinessStatus: false // 全局营业状态
  },
  
  /**
   * 初始化全局配置
   */
  initGlobalConfig: function() {
    // 确保baseUrl从baseDomain派生
    if (this.globalData.baseDomain && !this.globalData.baseUrl.includes(this.globalData.baseDomain)) {
      this.globalData.baseUrl = `${this.globalData.baseDomain}/api`;
    }
  },
})