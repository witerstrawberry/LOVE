// 腾讯地图API调用工具模块
// 注意：使用前请前往腾讯地图开放平台申请真实的API密钥
// 申请地址：https://lbs.qq.com/dev/console/key/manage
const API_KEY = 'SZQBZ-KR7EZ-VHPXS-7TY7S-FU5L5-2FFVJ'; // API密钥

// 腾讯地图API基础URL
const BASE_URL = 'https://apis.map.qq.com/ws';

/**
 * 逆地理编码 - 根据经纬度获取地址信息
 * @param {number} latitude - 纬度
 * @param {number} longitude - 经度
 * @returns {Promise} - 返回包含地址信息的Promise
 */
function reverseGeocode(latitude, longitude) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${BASE_URL}/geocoder/v1/`,
      data: {
        location: `${latitude},${longitude}`,
        key: API_KEY,
        get_poi: 1, // 获取周边POI
        poi_options: 'address_format=short;radius=1000;page_size=20;page_index=1;policy=1',
        output: 'json'
      },
      method: 'GET',
      success: (res) => {
        if (res.data.status === 0) {
          resolve(res.data.result);
        } else {
          reject(new Error(`逆地理编码失败: ${res.data.message || '未知错误'}`));
        }
      },
      fail: (err) => {
        reject(new Error(`请求失败: ${err.errMsg}`));
      }
    });
  });
}

/**
 * 周边搜索 - 获取指定位置附近的社区信息
 * @param {number} latitude - 纬度
 * @param {number} longitude - 经度
 * @param {number} radius - 搜索半径（米）
 * @param {number} pageSize - 每页数量
 * @returns {Promise} - 返回周边社区信息
 */
function searchNearbyCommunities(latitude, longitude, radius = 1000, pageSize = 10) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${BASE_URL}/place/v1/search`,
      data: {
        keyword: '小区|社区|花园|家园|公寓|住宅区',
        boundary: `nearby(${latitude},${longitude},${radius})`,
        key: API_KEY,
        page_size: pageSize,
        page_index: 1,
        output: 'json'
      },
      method: 'GET',
      success: (res) => {
        if (res.data.status === 0) {
          // 转换为前端需要的社区数据格式
          const communities = res.data.data.map((item, index) => ({
            id: index + 1,
            name: item.title,
            address: item.address,
            latitude: parseFloat(item.location.split(',')[1]),
            longitude: parseFloat(item.location.split(',')[0]),
            distance: calculateDistance(latitude, longitude, parseFloat(item.location.split(',')[1]), parseFloat(item.location.split(',')[0]))
          }));
          resolve(communities);
        } else {
          // 提供更详细的错误信息
          const errorMsg = res.data.message || '未知错误';
          const statusCode = res.data.status;
          
          // 特殊处理签名验证失败的情况
          if (errorMsg.includes('签名验证失败') || errorMsg.includes('signature') || statusCode === 120) {
            reject(new Error(`周边搜索失败: 签名验证失败，请检查API密钥配置`));
          } else {
            reject(new Error(`周边搜索失败: ${errorMsg}`));
          }
        }
      },
      fail: (err) => {
        reject(new Error(`请求失败: ${err.errMsg}`));
      }
    });
  });
}

/**
 * 计算两点之间的距离（米）
 * @param {number} lat1 - 第一个点的纬度
 * @param {number} lon1 - 第一个点的经度
 * @param {number} lat2 - 第二个点的纬度
 * @param {number} lon2 - 第二个点的经度
 * @returns {number} - 距离（米）
 */
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // 地球半径（米）
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

module.exports = {
  reverseGeocode,
  searchNearbyCommunities,
  calculateDistance
};