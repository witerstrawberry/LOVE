/**
 * 全局配置工具
 * 用于统一管理域名和资源路径
 */

/**
 * 获取应用实例
 */
const app = getApp();

/**
 * 获取基础域名
 * @returns {string} 基础域名，如 'https://baichuang.online/nyxc/'
 */
function getBaseDomain() {
  return app.globalData.baseDomain || 'https://baichuang.online/nyxc/';
}

/**
 * 获取API基础URL
 * @returns {string} API基础URL，如 'https://baichuang.online/nyxc/api'
 */
function getBaseUrl() {
  return app.globalData.baseUrl || 'https://baichuang.online/nyxc/api';
}

/**
 * 获取资源完整URL（用于图片等静态资源）
 * @param {string} path - 资源路径，如 '/uploads/part/vol_1.png'
 * @returns {string} 完整的资源URL
 */
function getResourceUrl(path) {
  const baseDomain = getBaseDomain();
  // 确保路径以 / 开头
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  return `${baseDomain}${cleanPath}`;
}

/**
 * 获取API完整URL
 * @param {string} path - API路径，如 '/merchant/check-status'
 * @returns {string} 完整的API URL
 */
function getApiUrl(path) {
  const baseUrl = getBaseUrl();
  // 确保路径不以 / 开头（baseUrl已经包含/api）
  const cleanPath = path.startsWith('/') ? path.substring(1) : path;
  return `${baseUrl}/${cleanPath}`;
}

module.exports = {
  getBaseDomain,
  getBaseUrl,
  getResourceUrl,
  getApiUrl
};

