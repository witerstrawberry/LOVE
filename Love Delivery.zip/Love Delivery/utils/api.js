/**
 * API工具类 - 统一管理API请求
 */

// 获取应用实例
const app = getApp();
/**
 * 发起HTTP请求的封装函数
 * @param {string} url - 请求地址
 * @param {string} method - 请求方法
 * @param {object} data - 请求数据
 * @param {object} options - 其他选项
 */
function request(url, method = 'GET', data = {}, options = {}) {
  return new Promise((resolve, reject) => {
    // 获取token
    const token = wx.getStorageSync('token');
    
    // 设置请求头
    const header = {
      'content-type': 'application/json',
      ...options.header
    };
    
    // 如果有token，添加到请求头
    if (token) {
      header['Authorization'] = `Bearer ${token}`;
    }

    // 构建完整的URL - 使用全局配置的baseUrl
    const baseUrl = app.globalData.baseUrl || 'https://baichuang.online/nyxc/';
    console.log('使用的baseUrl:', baseUrl);
    console.log('原始请求路径:', url);
    let fullUrl;
    if (url.startsWith('http')) {
      fullUrl = url;
    } else {
      // 确保URL路径正确拼接（处理斜杠问题）
      const cleanUrl = url.startsWith('/') ? url.substring(1) : url;
      fullUrl = `${baseUrl}/${cleanUrl}`;
    }
    console.log('构建的完整URL:', fullUrl);
    let requestData = data;

    // 收集所有查询参数（包括options中的params）
    const allQueryParams = {};
    
    // 如果有options中的params参数，添加到查询参数中
    if (options.params && typeof options.params === 'object') {
      Object.assign(allQueryParams, options.params);
    }
    
    // 对于GET请求，将data也作为查询参数
    if (method === 'GET' && data && Object.keys(data).length > 0) {
      Object.assign(allQueryParams, data);
      requestData = {}; // GET请求不发送body数据
    }
    
    // 如果有查询参数，拼接到URL中
    if (Object.keys(allQueryParams).length > 0) {
      const queryString = Object.keys(allQueryParams)
        .map(key => {
          const value = allQueryParams[key];
          // 对于数字类型的参数，直接使用原始值而不进行字符串转换
          if (typeof value === 'number') {
            return `${encodeURIComponent(key)}=${value}`;
          } else {
            return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
          }
        })
        .join('&');
      
      // 添加查询参数到URL
      if (fullUrl.includes('?')) {
        fullUrl = `${fullUrl}&${queryString}`;
      } else {
        fullUrl = `${fullUrl}?${queryString}`;
      }
    }

    console.log(`API请求即将发送: ${method} ${fullUrl}`);
    console.log('请求头:', header);
    console.log('请求数据:', requestData);

    wx.request({
      url: fullUrl,
      method,
      data: requestData,
      header,
      // 设置超时时间，默认15秒
      timeout: options.timeout || 15000,
      success: (res) => {
        console.log(`API请求 ${method} ${url}:`, res.data);
        console.log('HTTP状态码:', res.statusCode);
        
        // 检查HTTP状态码
        if (res.statusCode >= 200 && res.statusCode < 300) {
          // 检查响应数据是否存在
          if (res.data === undefined || res.data === null) {
            console.error(`API响应数据为空: ${method} ${url}`);
            reject({
              statusCode: res.statusCode,
              message: '响应数据为空',
              response: res.data,
              fullResponse: res
            });
          } else {
            resolve(res.data);
          }
        } else {
          // HTTP错误 - 提取更详细的错误信息
          const errorMessage = res.data?.message || 
                               res.data?.error || 
                               res.data?.msg || 
                               `请求失败 (状态码: ${res.statusCode})`;
          
          console.error(`API请求失败 ${method} ${url}: 状态码=${res.statusCode}, 消息=${errorMessage}`);
          console.error('完整响应数据:', JSON.stringify(res.data));
          reject({
            statusCode: res.statusCode,
            message: errorMessage,
            response: res.data,
            fullResponse: res
          });
        }
      },
      fail: (error) => {
        console.error(`API请求失败 ${method} ${url}:`, error);
        // 增强错误处理，提供更具体的错误信息
        let errorMessage = '网络错误，请检查网络连接';
        if (error.errMsg && error.errMsg.includes('timeout')) {
          errorMessage = '请求超时，请稍后重试';
        }
        reject({
          statusCode: 0,
          message: errorMessage,
          originalError: error
        });
      }
    });
  });
}

/**
 * GET请求
 */
function get(url, data = {}, options = {}) {
  return request(url, 'GET', data, options);
}

/**
 * POST请求
 */
function post(url, data = {}, options = {}) {
  return request(url, 'POST', data, options);
}

/**
 * PUT请求
 */
function put(url, data = {}, options = {}) {
  return request(url, 'PUT', data, options);
}

/**
 * DELETE请求
 */
function del(url, data = {}, options = {}) {
  return request(url, 'DELETE', data, options);
}

/**
 * PATCH请求
 */
function patch(url, data = {}, options = {}) {
  return request(url, 'PATCH', data, options);
}

// 认证相关API
const authAPI = {
  // 用户登录
  login: (phone, password) => post('/auth/login', { phone, password }),
  
  // 用户注册
  register: (userData) => post('/auth/register', userData),
  
  // 用户登出
  logout: () => post('/auth/logout'),
  
  // 获取用户信息
  getProfile: () => get('/auth/profile'),
  
  // 更新用户信息
  updateProfile: (userData) => put('/auth/profile', userData),
  
  // 修改密码
  changePassword: (oldPassword, newPassword) => put('/auth/password', { oldPassword, newPassword }),
  
  // 检查手机号是否已注册
  checkPhone: (phone) => post('/auth/check-phone', { phone })
};

// 商品相关API
const productAPI = {
  // 获取商品列表
  getProducts: (params = {}) => {
    const queryString = Object.keys(params)
      .filter(key => params[key] !== '' && params[key] !== null && params[key] !== undefined)
      .map(key => `${key}=${encodeURIComponent(params[key])}`)
      .join('&');
    return get(`/products${queryString ? '?' + queryString : ''}`);
  },
  
  // 获取商品详情
  getProductById: (id) => {
    // 确保id是有效的数字
    const validId = parseInt(id);
    if (isNaN(validId) || validId < 1) {
      return Promise.reject({ statusCode: 400, message: '商品ID格式不正确' });
    }
    // 使用正确的API路径格式
    return get(`/products/${validId}`);
  },
  
  // 根据分类获取商品
  getProductsByCategory: (categoryId, params = {}) => {
    const queryString = Object.keys(params)
      .filter(key => params[key] !== '' && params[key] !== null && params[key] !== undefined)
      .map(key => `${key}=${encodeURIComponent(params[key])}`)
      .join('&');
    return get(`/products/category/${categoryId}${queryString ? '?' + queryString : ''}`);
  },
  
  // 搜索商品
  searchProducts: (keyword, params = {}) => {
    const allParams = { keyword, ...params };
    const queryString = Object.keys(allParams)
      .filter(key => allParams[key] !== '' && allParams[key] !== null && allParams[key] !== undefined)
      .map(key => `${key}=${encodeURIComponent(allParams[key])}`)
      .join('&');
    return get(`/products/search?${queryString}`);
  },
  
  // 获取分类列表
  getCategories: (includeCount = false) => {
    return get(`/products/categories${includeCount ? '?include_count=true' : ''}`);
  },
  
  // 获取分类详情
  getCategoryById: (id, limit = 5) => {
    return get(`/products/category/${id}?limit=${limit}`);
  },
  
  // 创建商品
  createProduct: (productData) => {
    return post('/products', productData);
  },

  // 更新商品
  updateProduct: (productId, data) => {
    return put(`/products/${productId}`, data);
  },

  // 删除商品
  deleteProduct: (productId, data = {}) => {
    return del(`/products/${productId}`, data);
  }
};


// 购物车相关API
const cartAPI = {
  // 获取购物车列表
  getCartItems: () => {
    return get('/cart');
  },

  // 添加商品到购物车
  addToCart: (productId, quantity = 1) => {
    return post('/cart', { product_id: productId, quantity });
  },

  // 更新购物车商品数量
  updateCartItem: (productId, quantity) => {
    return put('/cart', { product_id: productId, quantity });
  },

  // 删除购物车商品
  removeCartItem: (productId) => {
    return del(`/cart/${productId}`);
  },

  // 清空购物车
  clearCart: () => {
    return del('/cart');
  }
};





// 订单相关API
const orderAPI = {
  // 创建订单
  createOrder: (orderData) => {
    return post('/order', orderData);
  },

  // 获取商家订单列表
  getMerchantOrders: (params = {}) => {
    const { status, page = 1, pageSize = 10, merchant_id } = params;
    const queryParams = { page, limit: pageSize };
    if (status) {
      queryParams.status = status;
    }
    if (merchant_id) {
      queryParams.merchantId = merchant_id; // 修复参数名称
    }
    console.log('API调用参数:', queryParams);
    return get('/order/merchant/orders', queryParams);
  },

  // 获取用户订单列表
  getUserOrders: (params = {}) => {
    const { status, page = 1, pageSize = 10 } = params;
    const queryParams = { page, limit: pageSize };
    if (status) {
      queryParams.status = status;
    }
    return get('/order', queryParams);
  },

  // 获取订单详情
  getOrderDetail: (orderId) => {
    return get(`/order/${orderId}`);
  },

  // 更新订单状态
  updateOrderStatus: (orderId, status) => {
    const userInfo = wx.getStorageSync('userInfo');
    const merchantId = userInfo && userInfo.merchant_id ? userInfo.merchant_id : '';
    
    // 构建查询参数，包含商家ID
    const queryParams = merchantId ? { merchantId } : {};
    
    // 构建请求头，包含商家ID
    const header = merchantId ? { 'x-merchant-id': merchantId } : {};
    
    return put(`/order/${orderId}/status`, { status }, { params: queryParams, header });
  },

  // 取消订单
  cancelOrder: (orderId) => {
    return put(`/order/${orderId}/cancel`);
  },

  // 删除订单
  deleteOrder: (orderId) => {
    return del(`/order/${orderId}`);
  },

  // 获取订单统计信息
  getOrderStats: () => {
    console.log('发起订单统计API请求，URL: /order/stats');
    return get('/order/stats');
  }
};

// 首页相关API
const homePageAPI = {
  // 获取轮播图数据
  getBanners: () => {
    return get('/homepage/banners');
  }
};

// 积分API
const pointsAPI = {
  // 使用积分支付
  payWithPoints: (productId, quantity = 1) => {
    return post('/points/pay', {
      productId,
      quantity
    });
  },
  
  // 获取用户积分余额
  getUserPointsBalance: () => {
    return get('/points/balance');
  },
  
  // 获取积分详情
  getPointsDetails: (userId = null) => {
    // 如果提供了用户ID，将其作为参数传递给后端
    if (userId) {
      return get('/points/details?userId=' + userId);
    }
    // 否则调用不带参数的接口
    return get('/points/details');
  },
  
  // 获取积分历史记录
  getPointsHistory: (page = 1, pageSize = 20) => {
    return get('/points/history', {
      page,
      limit: pageSize  // 修改为 limit 以匹配后端期望的参数名
    });
  }
};

// 地址相关API
const addressAPI = {
  // 获取地址列表
  getAddressList: (params = {}) => {
    const { page = 1, pageSize = 10, userId = '' } = params;
    // 构建参数对象，只包含有值的参数
    const requestParams = { page, limit: pageSize };  // 修改为 limit 以匹配后端期望的参数名
    // 如果提供了userId，则添加到请求参数中
    if (userId) {
      requestParams.userId = userId;
    }
    return get('/addresses', requestParams);
  },
  
  // 获取单个地址详情
  getAddressById: (id) => {
    return get(`/addresses/${id}`);
  },
  
  // 添加新地址
  addAddress: (addressData) => {
    return post('/addresses', addressData);
  },
  
  // 更新地址
  updateAddress: (id, addressData) => {
    return put(`/addresses/${id}`, addressData);
  },
  
  // 删除地址
  deleteAddress: (id, userId = '') => {
    // 如果提供了userId，则在请求体中传递
    const data = userId ? { userId } : {};
    return del(`/addresses/${id}`, data);
  },
  
  // 设置默认地址
  setDefaultAddress: (id, userId = '') => {
    // 如果提供了userId，则在请求体中传递
    const data = userId ? { userId } : {};
    return put(`/addresses/${id}/default`, data);
  }
};

// 收藏相关API
const favoriteAPI = {
  // 添加商家到收藏
  addFavorite: (merchantId) => {
    return post('/favorites', { merchantId });
  },
  
  // 取消收藏商家
  removeFavorite: (merchantId) => {
    return del(`/favorites/${merchantId}`);
  },
  
  // 获取用户的收藏列表
  getUserFavorites: (params = {}) => {
    const { page = 1, limit = 10 } = params;
    return get('/favorites', { page, limit });
  },
  
  // 检查商家是否已收藏
  checkFavoriteStatus: (merchantId) => {
    return get(`/favorites/check/${merchantId}`);
  }
};

// 联系人相关API
const contactsAPI = {
  // 获取当前用户的联系人列表
  getContacts: () => {
    return get('/contacts');
  },
  
  // 获取所有相关联系人
  getAllRelatedContacts: () => {
    return get('/contacts/all');
  },
  
  // 获取联系人详情
  getContactById: (contactId) => {
    return get(`/contacts/${contactId}`);
  },
  
  // 创建联系人
  createContact: (contactData) => {
    return post('/contacts', contactData);
  },
  
  // 更新联系人
  updateContact: (contactId, contactData) => {
    return put(`/contacts/${contactId}`, contactData);
  },
  
  // 删除联系人
  deleteContact: (contactId) => {
    return del(`/contacts/${contactId}`);
  },
  
  // 设置主要联系人
  setPrimaryContact: (contactId) => {
    return patch(`/contacts/${contactId}/primary`);
  }
};

// 家庭端相关API
const familyAPI = {
  getDashboard: () => get('/family/dashboard'),
  getProfile: () => get('/family/profile')
};

// AI 相关 API
const aiAPI = {
  // 获取菜品推荐 - 设置20秒超时，因为AI调用可能需要较长时间
  getDishRecommendations: (params) => {
    return post('/ai/dish-recommendations', params, { timeout: 20000 });
  },

  // 获取营养建议
  getNutritionAdvice: (userId) => {
    return get(`/ai/nutrition-advice/${userId || 'current'}`);
  },

  // 获取个性化菜单
  getPersonalizedMenu: (params) => {
    return post('/ai/personalized-menu', params);
  },

  // 更新用户饮食偏好
  updateFoodPreferences: (preferences) => {
    return put('/ai/food-preferences', { preferences });
  },

  // 获取食材替换建议
  getIngredientSubstitutes: (ingredient) => {
    return get(`/ai/ingredient-substitutes/${encodeURIComponent(ingredient)}`);
  }
};

// 商家相关API
const merchantAPI = {
  // 获取商家详细信息
  getMerchantInfo: () => {
    return get('/merchant/private/info');
  },

  // 获取公开的商家信息（无需登录）
  getPublicMerchantInfo: (params = {}) => {
    return get('/merchant/public/info', params);
  },
  
  // 更新商家信息
  updateMerchantInfo: (merchantData) => {
    return post('/merchant/private/save', merchantData);
  },
  
  // 更新营业状态 - 新增方法
  updateBusinessStatus: (isOpen) => {
    return post('/merchant/private/business-status', { is_open: isOpen ? 1 : 0 });
  },
  
  // 获取营业状态 - 新增方法
  getBusinessStatus: () => {
    return get('/merchant/private/business-status');
  },
  
  // 获取商家经营数据统计
  getMerchantStats: () => {
    return get('/merchant/private/stats');
  }
};

// 商家通知相关API
const notificationAPI = {
  getNotifications: (params = {}) => {
    return get('/notifications', params);
  },

  createNotification: (data) => {
    return post('/notifications', data);
  },

  updateNotification: (id, data) => {
    return put(`/notifications/${id}`, data);
  },

  deleteNotification: (id, data = {}) => {
    return del(`/notifications/${id}`, data);
  }
};

// 老人健康信息相关API
const elderlyInfoAPI = {
  /**
   * 获取子女绑定的老人数量
   * @param {number} childId
   */
  getChildStats: (childId) => {
    if (childId) {
      return get(`/elderly-info/stats/child/${childId}`);
    }
    return get('/elderly-info/stats/child');
  },

  /**
   * 根据老人user_id统计数量
   */
  getUserStats: (userId) => {
    if (!userId) {
      return Promise.reject({ statusCode: 400, message: '缺少userId参数' });
    }
    return get(`/elderly-info/stats/user/${userId}`);
  },

  /**
   * 获取老人信息列表
   */
  getElderlyInfos: (params = {}) => {
    return get('/elderly-info', params);
  },

  /**
   * 更新老人健康信息
   */
  updateElderlyInfo: (id, data) => {
    if (!id) {
      return Promise.reject({ statusCode: 400, message: '缺少记录ID' });
    }
    return put(`/elderly-info/${id}`, data);
  },

  /**
   * 新增老人健康信息
   */
  createElderlyInfo: (data) => {
    return post('/elderly-info', data);
  },

  /**
   * 删除老人健康信息
   */
  deleteElderlyInfo: (id) => {
    if (!id) {
      return Promise.reject({ statusCode: 400, message: '缺少记录ID' });
    }
    return del(`/elderly-info/${id}`);
  }
};

// 任务相关API
const taskAPI = {
  // 获取任务列表
  getTaskList: (params = {}) => {
    return get('/tasks', params);
  },
  
  // 获取任务详情
  getTaskDetail: (taskId) => {
    return get(`/tasks/${taskId}`);
  },
  
  // 创建任务
  createTask: (taskData) => {
    return post('/tasks', taskData);
  },
  
  // 更新任务
  updateTask: (taskId, taskData) => {
    return put(`/tasks/${taskId}`, taskData);
  },
  
  // 删除任务
  deleteTask: (taskId) => {
    return del(`/tasks/${taskId}`);
  },
  
  // 认领任务
  claimTask: (taskId) => {
    return post(`/tasks/${taskId}/claim`);
  },
  
  // 取消认领任务
  unclaimTask: (taskId) => {
    return post(`/tasks/${taskId}/unclaim`);
  },
  
  // 测试接口：手动触发生成第二天的配送任务
  testGenerateTasks: () => {
    return post('/tasks/test/generate');
  }
};

module.exports = {
  request,
  get,
  post,
  put,
  del,
  patch,
  authAPI,
  productAPI,
  cartAPI,
  orderAPI,
  homePageAPI,
  pointsAPI,
  addressAPI,
  favoriteAPI,
  contactsAPI,
  familyAPI,
  aiAPI,
  merchantAPI,
  notificationAPI,
  elderlyInfoAPI,
  taskAPI
};