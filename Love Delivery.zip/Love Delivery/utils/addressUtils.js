/**
 * 地址格式化工具
 * 将JSON格式的地址字符串转换为可读格式
 */

/**
 * 格式化配送地址
 * @param {string|object} addressData - 地址数据（JSON字符串或对象）
 * @returns {string} 格式化后的地址字符串
 */
function formatDeliveryAddress(addressData) {
  if (!addressData) {
    return '暂无配送地址';
  }

  // 如果是字符串，尝试解析为JSON
  let addressObj = addressData;
  if (typeof addressData === 'string') {
    // 检查是否是JSON字符串
    if (addressData.trim().startsWith('{')) {
      try {
        addressObj = JSON.parse(addressData);
      } catch (e) {
        // 如果不是有效的JSON，直接返回原字符串
        console.warn('地址数据不是有效的JSON格式:', addressData);
        return addressData;
      }
    } else {
      // 如果不是JSON格式，直接返回
      return addressData;
    }
  }

  // 如果是对象，提取地址信息
  if (typeof addressObj === 'object' && addressObj !== null) {
    const name = addressObj.name || addressObj.recipient_name || '';
    const phone = addressObj.phone || addressObj.recipient_phone || '';
    const province = addressObj.province || '';
    const city = addressObj.city || '';
    const district = addressObj.district || '';
    const detail = addressObj.detail || addressObj.detail_address || addressObj.address || '';

    // 构建地址字符串
    const parts = [];
    
    // 姓名和电话
    if (name || phone) {
      const contactInfo = [name, phone].filter(Boolean).join(' ');
      if (contactInfo) {
        parts.push(contactInfo);
      }
    }

    // 地址信息
    const addressParts = [province, city, district, detail].filter(Boolean);
    if (addressParts.length > 0) {
      parts.push(addressParts.join(''));
    }

    // 如果有信息，返回格式化后的字符串
    if (parts.length > 0) {
      return parts.join(' | ');
    }
  }

  // 如果无法解析，返回原数据
  return typeof addressData === 'string' ? addressData : '地址格式错误';
}

/**
 * 格式化地址为简洁格式（仅地址，不含联系人信息）
 * @param {string|object} addressData - 地址数据（JSON字符串或对象）
 * @returns {string} 格式化后的地址字符串
 */
function formatAddressOnly(addressData) {
  if (!addressData) {
    return '暂无地址';
  }

  let addressObj = addressData;
  if (typeof addressData === 'string') {
    if (addressData.trim().startsWith('{')) {
      try {
        addressObj = JSON.parse(addressData);
      } catch (e) {
        return addressData;
      }
    } else {
      return addressData;
    }
  }

  if (typeof addressObj === 'object' && addressObj !== null) {
    const province = addressObj.province || '';
    const city = addressObj.city || '';
    const district = addressObj.district || '';
    const detail = addressObj.detail || addressObj.detail_address || addressObj.address || '';

    const addressParts = [province, city, district, detail].filter(Boolean);
    return addressParts.length > 0 ? addressParts.join('') : '地址格式错误';
  }

  return typeof addressData === 'string' ? addressData : '地址格式错误';
}

/**
 * 提取联系人信息
 * @param {string|object} addressData - 地址数据（JSON字符串或对象）
 * @returns {object} 包含name和phone的对象
 */
function extractContactInfo(addressData) {
  if (!addressData) {
    return { name: '', phone: '' };
  }

  let addressObj = addressData;
  if (typeof addressData === 'string') {
    if (addressData.trim().startsWith('{')) {
      try {
        addressObj = JSON.parse(addressData);
      } catch (e) {
        return { name: '', phone: '' };
      }
    } else {
      return { name: '', phone: '' };
    }
  }

  if (typeof addressObj === 'object' && addressObj !== null) {
    return {
      name: addressObj.name || addressObj.recipient_name || '',
      phone: addressObj.phone || addressObj.recipient_phone || ''
    };
  }

  return { name: '', phone: '' };
}

module.exports = {
  formatDeliveryAddress,
  formatAddressOnly,
  extractContactInfo
};

