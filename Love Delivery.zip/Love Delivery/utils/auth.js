// utils/auth.js
const { post } = require('./request');

/**
 * 认证相关API
 */
const authAPI = {
  /**
   * 用户登录
   * @param {string} phone - 手机号
   * @param {string} password - 密码
   * @returns {Promise}
   */
  async login(phone, password) {
    try {
      const res = await post('/auth/login', {
        phone,
        password
      }, {
        showLoading: false
      });
      
      // 格式化返回数据
      return {
        success: res && res.code === 200,
        data: {
          token: res.data?.token,
          userInfo: res.data?.user
        }
      };
    } catch (error) {
      console.error('登录API错误:', error);
      return {
        success: false,
        message: error.message || '登录失败'
      };
    }
  },
  
  /**
   * 用户注册
   * @param {object} userInfo - 用户信息
   * @returns {Promise}
   */
  async register(userInfo) {
    try {
      const res = await post('/auth/register', userInfo, {
        showLoading: false
      });
      
      // 格式化返回数据
      return {
        success: res && res.code === 200,
        data: res.data,
        message: res.message
      };
    } catch (error) {
      console.error('注册API错误:', error);
      return {
        success: false,
        message: error.message || '注册失败'
      };
    }
  }
};

/**
 * 保存登录信息
 * @param {object|string} data - 登录数据对象或token
 * @param {object} [userInfo] - 用户信息（可选）
 */
function saveLoginInfo(data, userInfo) {
  // 如果data是对象，从中提取token和userInfo
  if (typeof data === 'object' && data !== null) {
    if (data.token) {
      wx.setStorageSync('token', data.token);
    }
    
    // 处理authController返回的格式 - 从success响应中提取用户信息
    if (data.data) {
      // 从data字段中提取用户信息
      userInfo = data.data;
    } else if (data.userInfo) {
      // 兼容旧格式
      userInfo = data.userInfo;
    } else {
      // 如果data本身就是用户信息对象（没有data字段），则直接使用
      // 检查是否包含用户信息的关键字段
      if (data.id || data.username || data.phone || data.nickname) {
        userInfo = data;
      }
    }
  } else if (typeof data === 'string') {
    // 如果data是字符串，将其视为token
    wx.setStorageSync('token', data);
  }
  
  if (userInfo) {
    console.log('保存用户信息到本地存储:', userInfo);
    // 将用户信息转换为JSON字符串后存储
    wx.setStorageSync('userInfo', JSON.stringify(userInfo));
    // 更新全局用户信息
    const app = getApp();
    app.globalData.userInfo = userInfo;
    
    // 特别存储积分信息，方便其他地方快速访问
    if (userInfo.points !== undefined) {
      wx.setStorageSync('userPoints', userInfo.points);
      if (app.globalData) {
        app.globalData.userPoints = userInfo.points;
      }
    }
  }
  
  return userInfo; // 返回保存的用户信息，便于调用者使用
}

/**
 * 处理登录成功后的逻辑
 */
function handleLoginSuccess() {
  // 优先根据后端返回的用户角色（role_id）决定入口页面
  const userInfo = getUserInfo();
  const roleId = userInfo && userInfo.role_id;

  // 默认老人端首页
  let targetPage = '/pages/old-index/order-index';

  if (roleId === 2) {
    // 商家
    targetPage = '/pages/restaurant/index';
  } else if (roleId === 3) {
    // 志愿者
    targetPage = '/pages/volunteer/index';
  } else if (roleId === 4) {
    // 子女
    targetPage = '/pages/family/family_index';
  } else if (roleId === 5) {
    // 管理员：进入管理员后台（用户管理页）
    targetPage = '/pages/Admin/admin_user_list';
  } else if (roleId === 1) {
    // 老人
    targetPage = '/pages/old-index/order-index';
  }

  // 兼容旧逻辑：如果没有role_id，但本地还有selectedRole，则作为兜底
  if (!roleId) {
    const selectedRole = wx.getStorageSync('selectedRole');
    const selectedId = selectedRole ? selectedRole.id : '';
    if (selectedId === 'restaurant') {
      targetPage = '/pages/restaurant/index';
    } else if (selectedId === 'volunteer') {
      targetPage = '/pages/volunteer/index';
    } else if (selectedId === 'elder') {
      targetPage = '/pages/old-index/order-index';
    } else if (selectedId === 'family') {
      targetPage = '/pages/family/family_index';
    }
  }

  wx.reLaunch({ url: targetPage });
}

/**
 * 获取存储的token
 * @returns {string|null}
 */
function getToken() {
  return wx.getStorageSync('token') || null;
}

/**
 * 获取存储的用户信息
 * @returns {object|null}
 */
function getUserInfo() {
  try {
    const storedInfo = wx.getStorageSync('userInfo');
    if (!storedInfo) return null;
    
    // 解析存储的用户信息（如果是JSON字符串）
    if (typeof storedInfo === 'string') {
      return JSON.parse(storedInfo);
    }
    return storedInfo;
  } catch (e) {
    console.error('解析用户信息失败:', e);
    return null;
  }
}

/**
 * 检查用户是否已登录
 * @returns {boolean}
 */
function isLoggedIn() {
  return !!getToken() && !!getUserInfo();
}

/**
 * 登出
 */
function logout() {
  wx.removeStorageSync('token');
  wx.removeStorageSync('userInfo');
  
  // 清空全局用户信息
  const app = getApp();
  app.globalData.userInfo = null;
}

module.exports = {
  authAPI,
  saveLoginInfo,
  handleLoginSuccess,
  getToken,
  getUserInfo,
  isLoggedIn,
  logout
};