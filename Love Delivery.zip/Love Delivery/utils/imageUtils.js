// 图片URL处理工具
const app = getApp();
const BASE_URL = app.globalData.baseUrl.replace('/api', ''); // 移除/api后缀

/**
 * 将相对路径或本地URL转换为完整的云服务器图片URL
 * @param {string} path - 图片路径，如 'huawei2.jpg' 或 '/img/huawei2.jpg' 或 'http://localhost:3000/uploads/avatars/avatar.jpg'
 * @returns {string} 完整的图片URL
 */
function getFullImageUrl(path) {
  if (!path) return '';
  
  // 如果是本地URL，替换为云服务器URL
  if (path.startsWith('http://localhost:3000') || path.startsWith('https://localhost:3000')) {
    // 提取相对路径部分
    const relativePath = path.replace('http://localhost:3000', '').replace('https://localhost:3000', '');
    console.log('替换本地URL为云服务器URL:', path, '->', BASE_URL + relativePath);
    return BASE_URL + relativePath;
  }
  
  // 如果已经是完整的云服务器URL则直接返回
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }
  
  // 处理相对路径，确保路径格式正确
  let relativePath = path;
  
  // 如果路径已经以/img开头，直接使用（后端已配置/img映射到uploads/img）
  if (relativePath.startsWith('/img')) {
    // 不需要添加/uploads前缀，因为后端已经直接映射了/img路径
    console.log('构建图片URL(直接使用/img):', BASE_URL + relativePath);
    return BASE_URL + relativePath;
  }
  
  // 如果路径不以/开头，添加/img前缀
  if (!relativePath.startsWith('/')) {
    relativePath = '/img/' + relativePath;
  }
  // 如果路径以/uploads开头，直接使用
  else if (relativePath.startsWith('/uploads')) {
    // 保持原样
  }
  // 其他情况，默认添加/img前缀
  else {
    relativePath = '/img' + relativePath;
  }
  
  const fullUrl = BASE_URL + relativePath;
  console.log('构建图片URL:', relativePath, '->', fullUrl);
  return fullUrl;
}

module.exports = {
  getFullImageUrl
};