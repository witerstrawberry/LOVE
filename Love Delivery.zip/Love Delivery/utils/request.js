// 通用请求工具函数
const app = getApp();

/**
 * 发送请求的封装函数
 * @param {string} url - 接口路径
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function request(url, options = {}) {
  return new Promise((resolve, reject) => {
    // 显示加载提示
    if (options.showLoading !== false) {
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
    }

    // 构建完整的URL
    const baseUrl = app.globalData.baseUrl;
    const fullUrl = url.startsWith('http') ? url : `${baseUrl}${url}`;

    // 设置默认请求头
    const header = {
      'content-type': 'application/json',
      ...options.header
    };

    // 如果存在token，则添加到请求头
    let token = wx.getStorageSync('token');
    
    // 如果没有真实token，使用测试token进行开发测试
    if (!token) {
      console.log('使用测试token进行API请求');
      token = 'test-token';
    }
    
    header['Authorization'] = `Bearer ${token}`;
    console.log('请求头中的Authorization:', header['Authorization']);

    // 发送请求
    wx.request({
      url: fullUrl,
      method: options.method || 'GET',
      data: options.data || {},
      header: header,
      timeout: options.timeout || 15000, // 设置默认超时时间为15秒
      success: (res) => {
        // 隐藏加载提示
        if (options.showLoading !== false) {
          wx.hideLoading();
        }

        // 处理响应
        if (res.statusCode === 200) {
          if (res.data.success || res.data.code === 0) {
            resolve(res.data);
          } else {
            // 显示错误信息
            if (options.showError !== false) {
              wx.showToast({
                title: res.data.message || '请求失败',
                icon: 'none'
              });
            }
            reject(res.data);
          }
        } else if (res.statusCode === 401) {
          // 未授权，跳转到登录页
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          app.globalData.userInfo = null;
          
          wx.showToast({
            title: '请先登录',
            icon: 'none'
          });
          
          setTimeout(() => {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }, 1500);
          
          reject({ code: 401, message: '未授权' });
        } else if (res.statusCode === 409) {
          // 资源冲突（例如手机号已被注册）
          if (options.showError !== false) {
            wx.showToast({
              title: res.data?.message || '该账号已被注册',
              icon: 'none'
            });
          }
          reject({ code: 409, message: res.data?.message || '请求冲突' });
        } else if (res.statusCode === 400) {
          // 请求参数错误
          if (options.showError !== false) {
            wx.showToast({
              title: res.data?.message || '请求参数错误',
              icon: 'none'
            });
          }
          reject({ code: 400, message: res.data?.message || '请求参数错误' });
        } else if (res.statusCode === 403) {
          // 禁止访问
          if (options.showError !== false) {
            wx.showToast({
              title: res.data?.message || '无权限访问',
              icon: 'none'
            });
          }
          reject({ code: 403, message: res.data?.message || '禁止访问' });
        } else {
          // 其他错误
          if (options.showError !== false) {
            wx.showToast({
              title: res.data?.message || `请求失败(${res.statusCode})`,
              icon: 'none'
            });
          }
          reject({ code: res.statusCode, message: res.data?.message || '请求失败' });
        }
      },
      fail: (err) => {
        // 隐藏加载提示
        if (options.showLoading !== false) {
          wx.hideLoading();
        }

        // 显示错误信息，根据错误类型提供更具体的提示
        if (options.showError !== false) {
          let errorMessage = '网络错误，请重试';
          if (err.errMsg && err.errMsg.includes('timeout')) {
            errorMessage = '请求超时，请稍后重试';
          }
          wx.showToast({
            title: options.customErrorMsg || errorMessage,
            icon: 'none',
            duration: 3000
          });
        }
        reject(err);
      },
      complete: options.complete
    });
  });
}

/**
 * GET请求
 * @param {string} url - 接口路径
 * @param {object} params - 请求参数
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function get(url, params = {}, options = {}) {
  return request(url, {
    method: 'GET',
    data: params,
    ...options
  });
}

/**
 * POST请求
 * @param {string} url - 接口路径
 * @param {object} data - 请求数据
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function post(url, data = {}, options = {}) {
  return request(url, {
    method: 'POST',
    data: data,
    ...options
  });
}

/**
 * PUT请求
 * @param {string} url - 接口路径
 * @param {object} data - 请求数据
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function put(url, data = {}, options = {}) {
  return request(url, {
    method: 'PUT',
    data: data,
    ...options
  });
}

/**
 * DELETE请求
 * @param {string} url - 接口路径
 * @param {object} data - 请求数据
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function del(url, data = {}, options = {}) {
  return request(url, {
    method: 'DELETE',
    data: data,
    ...options
  });
}

/**
 * PATCH请求
 * @param {string} url - 接口路径
 * @param {object} data - 请求数据
 * @param {object} options - 请求选项
 * @returns {Promise} - 返回Promise对象
 */
function patch(url, data = {}, options = {}) {
  return request(url, {
    method: 'PATCH',
    data: data,
    ...options
  });
}

module.exports = {
  request,
  get,
  post,
  put,
  delete: del,
  patch
};