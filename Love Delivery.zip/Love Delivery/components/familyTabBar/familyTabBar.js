Component({
  properties: {
    currentPage: {
      type: String,
      value: 'family_index'
    }
  },

  methods: {
    switchTab(e) {
      const page = e.currentTarget.dataset.page;
      if (page === this.data.currentPage) return;
      
      let url = '';
      switch(page) {
        case 'family_index':
          url = '/pages/family/family_index';
          break;
        case 'merchant-list':
          url = '/pages/family/merchant-list';
          break;
        case 'order-food':
          url = '/pages/family/order-food';
          break;
        case 'family_profile':
          url = '/pages/family/family_profile';
          break;
      }
      
      wx.navigateTo({
        url: url,
        fail: function() {
          // 如果navigateTo失败（可能是因为页面栈已满），尝试redirectTo
          wx.redirectTo({
            url: url
          });
        }
      });
    }
  }
});