// components/volunteerTabBar/volunteerTabBar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    currentTab: {
      type: String,
      value: 'index'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {},

  /**
   * 组件的方法列表
   */
  methods: {
    switchTab(e) {
      const tab = e.currentTarget.dataset.tab;
      // 获取当前页面路径，避免重复导航到相同页面
      const pages = getCurrentPages();
      const currentPage = pages[pages.length - 1];
      const currentPagePath = currentPage.route;
      let url = '';
      switch (tab) {
        case 'index':
          url = '/pages/volunteer/index';
          break;
        case 'notice':
          url = '/pages/volunteer/vol_notice';
          break;
        case 'profile':
          url = '/pages/volunteer/vol_profile';
          break;
        default:
          url = '/pages/volunteer/index';
      }

      // 检查是否需要导航（避免重复导航到当前页面）
      if (!currentPagePath.includes(url.replace('/pages/', ''))) {
        wx.navigateTo({
          url: url,
          fail: function () {
            // 如果navigateTo失败（可能是因为页面栈已满），尝试redirectTo
            wx.redirectTo({
              url: url
            });
          }
        });
      }
    }
  }
})