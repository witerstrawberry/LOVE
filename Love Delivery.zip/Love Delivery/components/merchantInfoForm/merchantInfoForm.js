// components/merchantInfoForm/merchantInfoForm.js
const { getApiUrl } = require('../../utils/config');

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    visible: {
      type: Boolean,
      value: false,
      observer: 'onVisibleChange'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currentStep: 1,
    totalSteps: 2,
    merchantInfo: {
      name: '',
      phone: '',
      contactPerson: '',
      businessHours: '',
      address: '',
      description: '',
      category: '',
      healthLicense: '',
      minOrderAmount: 0,
      deliveryFee: 0,
      deliveryScope: '',
      creditCode: '',
      email: '',
      website: '',
      businessLicenseImage: '',
      restaurantImage: '',
      kitchenImage: ''
    },
    categoryOptions: ['社区食堂', '老年餐配送', '营养餐服务', '其他'],
    formErrors: {}
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 监听visible属性变化
    onVisibleChange(newVal) {
      if (newVal) {
        // 当表单显示时，加载现有商家信息
        this.loadMerchantData();
      } else {
        // 当表单隐藏时，重置表单
        this.resetForm();
      }
    },

    // 从后端加载商家信息
    loadMerchantData() {
      const that = this;
      
      wx.request({
        url: getApiUrl('/merchant/private/info'),
        method: 'GET',
        header: {
          'content-type': 'application/json',
          'Authorization': wx.getStorageSync('token') || '',
          'Cache-Control': 'no-cache',
          'If-Modified-Since': '0'
        },
        success: (res) => {
          console.log('加载商家信息结果:', res.data);
          if (res.data && res.data.success && res.data.data) {
            const merchantData = res.data.data;
            
            // 更新表单数据
            that.setData({
              'merchantInfo.name': merchantData.name || '',
              'merchantInfo.phone': merchantData.phone || '',
              'merchantInfo.contactPerson': merchantData.contact_person || merchantData.contactPerson || '',
              'merchantInfo.businessHours': merchantData.business_hours || merchantData.businessHours || '',
              'merchantInfo.address': merchantData.address || '',
              'merchantInfo.description': merchantData.description || '',
              'merchantInfo.category': merchantData.category || '',
              'merchantInfo.minOrderAmount': merchantData.min_order_amount || 0,
              'merchantInfo.deliveryFee': merchantData.delivery_fee || 0,
              'merchantInfo.deliveryScope': merchantData.delivery_scope || '',
              'merchantInfo.creditCode': merchantData.credit_code || '',
              'merchantInfo.email': merchantData.email || '',
              'merchantInfo.website': merchantData.website || '',
              'merchantInfo.businessLicenseImage': merchantData.business_license_image || merchantData.businessLicenseImage || '',
              'merchantInfo.restaurantImage': merchantData.restaurant_scene_image || merchantData.restaurantImage || '',
              'merchantInfo.kitchenImage': merchantData.kitchen_image || merchantData.kitchenImage || ''
            });
            
            console.log('商家信息已加载到表单:', that.data.merchantInfo);
          }
        },
        fail: (error) => {
          console.error('加载商家信息失败:', error);
        }
      });
    },

    // 关闭弹窗
    onClose() {
      this.triggerEvent('close');
    },

    // 输入框内容变化
    onInput(e) {
      const { field } = e.currentTarget.dataset;
      const { value } = e.detail;
      
      this.setData({
        [`merchantInfo.${field}`]: value
      });
      
      // 清除该字段的错误信息
      if (this.data.formErrors[field]) {
        this.setData({
          [`formErrors.${field}`]: ''
        });
      }
    },
    
    // 上传图片
    uploadImage(e) {
      const { field } = e.currentTarget.dataset;
      const that = this;
      
      wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        success(res) {
          const tempFilePath = res.tempFiles[0].tempFilePath;
          
          // 显示加载提示
          wx.showLoading({
            title: '上传中...',
          });
          
          // 这里应该调用上传到服务器的API，暂时使用临时文件路径
          setTimeout(() => {
            wx.hideLoading();
            that.setData({
              [`merchantInfo.${field}`]: tempFilePath
            });
            wx.showToast({
              title: '上传成功',
              icon: 'success'
            });
          }, 1000);
        },
        fail(err) {
          console.error('选择图片失败:', err);
        }
      });
    },
    
    // 预览图片
    previewImage(e) {
      const { field } = e.currentTarget.dataset;
      const imageUrl = this.data.merchantInfo[field];
      
      if (imageUrl) {
        wx.previewImage({
          urls: [imageUrl]
        });
      }
    },

    // 选择类别
    onCategoryChange(e) {
      const { value } = e.detail;
      this.setData({
        'merchantInfo.category': value
      });
    },

    // 下一步
    nextStep() {
      // 验证当前步骤
      if (!this.validateCurrentStep()) {
        return;
      }
      
      if (this.data.currentStep < this.data.totalSteps) {
        this.setData({
          currentStep: this.data.currentStep + 1
        });
      } else {
        // 最后一步，提交表单
        this.submitForm();
      }
    },

    // 上一步
    prevStep() {
      if (this.data.currentStep > 1) {
        this.setData({
          currentStep: this.data.currentStep - 1
        });
      }
    },

    // 验证当前步骤的表单
    validateCurrentStep() {
      const errors = {};
      const { merchantInfo, currentStep } = this.data;
      
      if (currentStep === 1) {
        // 第一步验证
        if (!merchantInfo.name || merchantInfo.name.trim() === '') {
          errors.name = '请输入商家名称';
        }
        if (!merchantInfo.phone || merchantInfo.phone.trim() === '') {
          errors.phone = '请输入联系电话';
        } else if (!/^1[3-9]\d{9}$|^0\d{2,3}-\d{7,8}$/.test(merchantInfo.phone)) {
          errors.phone = '请输入正确的电话号码';
        }
        if (!merchantInfo.contactPerson || merchantInfo.contactPerson.trim() === '') {
          errors.contactPerson = '请输入联系人姓名';
        }
        if (!merchantInfo.businessHours || merchantInfo.businessHours.trim() === '') {
          errors.businessHours = '请输入营业时间';
        }
        // 验证社会统一社会信用代码
        if (merchantInfo.creditCode && merchantInfo.creditCode.trim() !== '') {
          if (!/^[0-9A-HJ-NPQRTUWXY]{2}\d{6}[0-9A-HJ-NPQRTUWXY]{10}$/.test(merchantInfo.creditCode.trim())) {
            errors.creditCode = '请输入正确的18位社会统一社会信用代码';
          }
        }
        // 验证邮箱
        if (merchantInfo.email && merchantInfo.email.trim() !== '') {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(merchantInfo.email.trim())) {
            errors.email = '请输入正确的邮箱地址';
          }
        }
        // 验证网址
        if (merchantInfo.website && merchantInfo.website.trim() !== '') {
          const websiteRegex = /^https?:\/\/[^\s$.?#].[^\s]*$/i;
          if (!websiteRegex.test(merchantInfo.website.trim())) {
            errors.website = '请输入正确的网址（包含http://或https://）';
          }
        }
      } else if (currentStep === 2) {
        // 第二步验证
        if (!merchantInfo.address || merchantInfo.address.trim() === '') {
          errors.address = '请输入详细地址';
        }
        if (!merchantInfo.category) {
          errors.category = '请选择商家分类';
        }
        if (!merchantInfo.minOrderAmount || parseFloat(merchantInfo.minOrderAmount) < 0) {
          errors.minOrderAmount = '请输入有效的最低起送金额';
        }
        
        // 图片字段验证
        if (!merchantInfo.businessLicenseImage) {
          errors.businessLicenseImage = '请上传营业资格证';
        }
        
        if (!merchantInfo.restaurantImage) {
          errors.restaurantImage = '请上传餐厅实景图片';
        }
        
        if (!merchantInfo.kitchenImage) {
          errors.kitchenImage = '请上传后厨场景图片';
        }
      }
      
      this.setData({ formErrors: errors });
      return Object.keys(errors).length === 0;
    },

    // 提交表单
    submitForm() {
      const { merchantInfo } = this.data;
      
      // 显示加载提示
      wx.showLoading({
        title: '保存中...',
      });
      
      // 调用父组件的保存方法
      this.triggerEvent('submit', { merchantInfo });
    },

    // 重置表单
    resetForm() {
      this.setData({
        currentStep: 1,
        merchantInfo: {
          name: '',
          phone: '',
          contactPerson: '',
          businessHours: '',
          address: '',
          description: '',
          category: '',
          healthLicense: '',
          minOrderAmount: 0,
          deliveryFee: 0,
          deliveryScope: '',
          creditCode: '',
          email: '',
          website: '',
          businessLicenseImage: '',
          restaurantImage: '',
          kitchenImage: ''
        },
        formErrors: {}
      });
    }
  }
});