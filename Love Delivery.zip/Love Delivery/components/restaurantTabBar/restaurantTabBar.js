Component({
  properties: {
    currentPage: {
      type: String,
      value: 'index'
    }
  },

  methods: {
    switchTab(e) {
      const page = e.currentTarget.dataset.page;
      if (page === this.data.currentPage) return;
      
      wx.navigateTo({
        url: `/pages/restaurant/${page}`
      });
    }
  }
});