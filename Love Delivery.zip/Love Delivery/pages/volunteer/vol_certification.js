// pages/volunteer/vol_certification.js
// 导入工具类和组件
import { post } from '../../utils/request';
import userStores from '../../stores/userStores';
const { getApiUrl } = require('../../utils/config');

Page({
  /**
   * 页面的初始数据
   */
  data: {
    formData: {
      real_name: '',
      id_card: '',
      gender: 0, // 0:未选择, 1:男, 2:女
      age: '',
      address: '',
      emergency_contact: '',
      created_at: ''
    },
    hasCertification: false,
    certificationStatus: 0, // 0:未认证, 1:已认证, 2:审核中, 3:认证失败
    statusText: '未认证',
    statusClass: 'status-unverified',
    submitting: false,
    submitButtonText: '提交认证'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面加载，开始处理登录状态');
    
    // 首先检查是否有token
    const token = wx.getStorageSync('token');
    console.log('onLoad - token存在:', !!token);
    
    // 页面加载时检查用户登录状态
    this.checkUserLoginStatus().then(isLoggedIn => {
      console.log('onLoad - 登录状态检查结果:', isLoggedIn);
      
      if (isLoggedIn) {
        // 用户已登录，检查认证状态
        console.log('用户已登录，正在检查认证状态');
        this.checkCertificationStatus();
      } else {
        // 如果token存在但仍被判定为未登录，提供特殊处理
        if (token && token !== '') {
          console.log('token存在但判定为未登录，提供备选访问方案');
          wx.showModal({
            title: '登录状态异常',
            content: '检测到您可能已登录，但无法获取完整用户信息。是否尝试继续访问？',
            success: (res) => {
              if (res.confirm) {
                console.log('用户确认继续访问');
                // 即使登录状态检查失败，也允许用户尝试访问
                this.checkCertificationStatus();
              } else {
                console.log('用户取消继续，导航到登录页');
                wx.navigateTo({
                  url: '/pages/login/login'
                });
              }
            }
          });
        } else {
          // 用户未登录，提示并导航到登录页面
          console.log('token不存在，执行正常登录流程');
          wx.showToast({
            title: '请先登录',
            icon: 'none'
          });
          // 延迟跳转，让用户看到提示
          setTimeout(() => {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }, 1500);
        }
      }
    }).catch(error => {
      console.error('处理登录状态时发生错误:', error);
      // 错误处理：如果有token，仍然允许用户尝试访问
      const token = wx.getStorageSync('token');
      if (token && token !== '') {
        wx.showModal({
          title: '加载异常',
          content: '页面加载过程中发生错误。是否尝试继续访问？',
          success: (res) => {
            if (res.confirm) {
              this.checkCertificationStatus();
            } else {
              wx.navigateTo({
                url: '/pages/login/login'
              });
            }
          }
        });
      } else {
        wx.showToast({
          title: '加载失败，请重新登录',
          icon: 'none'
        });
        setTimeout(() => {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }, 1500);
      }
    });
  },
  
  /**
   * 检查用户登录状态
   * @returns {Promise<boolean>} 用户是否已登录
   */
  checkUserLoginStatus: function() {
    return new Promise((resolve) => {
      try {
        // 详细记录登录状态检查过程
        console.log('开始检查用户登录状态');
        
        // 检查token是否存在
        const token = wx.getStorageSync('token');
        console.log('Token存在状态:', !!token);
        
        // 如果token不存在，肯定未登录
        if (!token || token === '') {
          console.log('Token不存在，判定为未登录');
          resolve(false);
          return;
        }
        
        // 尝试获取用户信息
        const userInfo = userStores.getUserInfo();
        console.log('从userStores获取的用户信息:', userInfo);
        
        // 优先检查userStores中的user_id
        if (userInfo && userInfo.user_id) {
          console.log('从userStores成功获取到user_id:', userInfo.user_id);
          resolve(true);
          return;
        }
        
        // 备用方案1：直接从本地存储获取user_id
        const directUserId = wx.getStorageSync('user_id');
        console.log('从本地存储直接获取的user_id:', directUserId);
        if (directUserId && directUserId !== '') {
          console.log('从本地存储成功获取到user_id');
          resolve(true);
          return;
        }
        
        // 备用方案2：尝试从userInfo对象中获取其他可能的用户标识符
        if (userInfo) {
          // 检查是否有其他可能的用户ID字段
          const hasOtherIdField = Object.keys(userInfo).some(key => 
            key.includes('id') || key.includes('ID') || key === '_id'
          );
          console.log('userInfo中是否包含其他ID字段:', hasOtherIdField);
          if (hasOtherIdField) {
            console.log('检测到用户信息中包含ID相关字段，判定为已登录');
            // 同步更新user_id到本地存储
            try {
              const potentialId = Object.values(userInfo).find(val => 
                val && (typeof val === 'string' || typeof val === 'number')
              );
              if (potentialId) {
                wx.setStorageSync('user_id', potentialId);
                console.log('已将潜在用户ID同步到本地存储:', potentialId);
              }
            } catch (syncError) {
              console.error('同步用户ID失败:', syncError);
            }
            resolve(true);
            return;
          }
        }
        
        // 如果所有检查都失败，判定为未登录
        console.log('所有登录状态检查均失败，判定为未登录');
        resolve(false);
      } catch (error) {
        console.error('检查用户登录状态时发生错误:', error);
        // 即使发生错误，只要token存在，也可以尝试判定为已登录
        const token = wx.getStorageSync('token');
        if (token && token !== '') {
          console.log('发生错误但token存在，尝试判定为已登录');
          resolve(true);
        } else {
          resolve(false);
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 每次页面显示时重新检查认证状态
    this.checkCertificationStatus();
  },

  /**
   * 返回上一页
   */
  navigateBack: function() {
    wx.navigateBack();
  },
  
  /**
   * 诊断登录状态（用于测试）
   */
  diagnoseLoginStatus: function() {
    console.log('===== 开始登录状态诊断 =====');
    
    // 获取并显示token信息
    const token = wx.getStorageSync('token');
    console.log('Token值:', token ? '存在（已隐藏具体值）' : '不存在');
    
    // 获取并显示user_id
    const userId = wx.getStorageSync('user_id');
    console.log('直接存储的user_id:', userId || '不存在');
    
    // 获取并显示完整的用户信息
    const userInfo = userStores.getUserInfo();
    console.log('从userStores获取的用户信息:', JSON.stringify(userInfo));
    
    // 执行完整的登录状态检查
    this.checkUserLoginStatus().then(isLoggedIn => {
      console.log('完整登录状态检查结果:', isLoggedIn);
      
      // 显示诊断结果对话框
      wx.showModal({
        title: '登录状态诊断结果',
        content: `Token: ${token ? '已存在' : '不存在'}\n` +
                 `user_id: ${userId || '不存在'}\n` +
                 `用户信息: ${userInfo ? '已获取' : '未获取'}\n` +
                 `综合判定: ${isLoggedIn ? '已登录' : '未登录'}\n\n` +
                 '详细信息已输出到控制台',
        showCancel: false
      });
      
      // 如果诊断显示已登录但页面未正确加载，提供重新加载选项
      if (isLoggedIn && this.data.certificationStatus === 0) {
        wx.showModal({
          title: '检测到异常',
          content: '您已登录但认证信息可能未正确加载，是否重新检查认证状态？',
          success: (res) => {
            if (res.confirm) {
              this.checkCertificationStatus();
            }
          }
        });
      }
    }).catch(error => {
      console.error('诊断过程中发生错误:', error);
      wx.showToast({
        title: '诊断失败，请查看控制台',
        icon: 'none'
      });
    });
    
    console.log('===== 诊断完成 =====');
  },

  /**
   * 真实姓名输入
   */
  onRealNameInput: function(e) {
    this.setData({
      'formData.real_name': e.detail.value
    });
  },

  /**
   * 身份证号输入
   */
  onIdCardInput: function(e) {
    // 只允许输入数字和大写字母X
    let value = e.detail.value.replace(/[^\dXx]/g, '').toUpperCase();
    this.setData({
      'formData.id_card': value
    });
  },

  /**
   * 性别选择
   */
  onGenderSelect: function(e) {
    const gender = parseInt(e.currentTarget.dataset.gender);
    this.setData({
      'formData.gender': gender
    });
  },

  /**
   * 年龄输入
   */
  onAgeInput: function(e) {
    // 只允许输入数字
    let value = e.detail.value.replace(/[^\d]/g, '');
    this.setData({
      'formData.age': value
    });
  },

  /**
   * 地址输入
   */
  onAddressInput: function(e) {
    this.setData({
      'formData.address': e.detail.value
    });
  },

  /**
   * 紧急联系人电话输入
   */
  onEmergencyContactInput: function(e) {
    // 只允许输入数字
    let value = e.detail.value.replace(/[^\d]/g, '');
    this.setData({
      'formData.emergency_contact': value
    });
  },

  /**
   * 检查认证状态
   */
  checkCertificationStatus() {
    console.log('开始检查认证状态');
    const that = this;
    
    // 先获取当前登录用户的真实ID
    this.getCurrentUserId().then(userId => {
      console.log('当前登录用户ID:', userId);
    
    if (!userId) {
      console.error('检查认证状态失败：未找到user_id');
      wx.showToast({
        title: '登录信息缺失，请重新登录',
        icon: 'none'
      });
      return;
    }
    
    // 获取token用于请求头
    const token = wx.getStorageSync('token');
    if (!token || token === '') {
      console.error('检查认证状态失败：未找到token');
      wx.showToast({
        title: '登录状态失效，请重新登录',
        icon: 'none'
      });
      return;
    }
    
    wx.request({
      url: `${getApiUrl('/volunteer/certification/status')}?user_id=${encodeURIComponent(userId)}`,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      success: function(res) {
        console.log('获取认证状态响应:', res);
          console.log('请求的用户ID:', userId);
        
        // 处理各种响应情况
        if (!res || !res.data) {
          console.error('无效的响应数据');
          wx.showToast({
            title: '服务器响应异常',
            icon: 'none'
          });
          return;
        }
        
        if (res.data.success) {
          // 成功响应
          const certificationData = res.data.data;
          console.log('获取到的认证数据:', certificationData);
          
          if (certificationData) {
              // 验证返回的数据是否属于当前用户（通过user_id判断）
            // 格式化日期
            if (certificationData.created_at) {
              certificationData.created_at = that.formatDate(certificationData.created_at);
            }
            
            const { statusText, statusClass } = that.getStatusInfo(certificationData.status);
            
            that.setData({
              hasCertification: true,
              certificationStatus: certificationData.status || 0,
              formData: {
                real_name: certificationData.real_name || '',
                id_card: certificationData.id_card || '',
                gender: certificationData.gender || 0,
                age: certificationData.age || '',
                address: certificationData.address || '',
                emergency_contact: certificationData.emergency_contact || '',
                phone: certificationData.phone || '',
                created_at: certificationData.created_at
              },
              statusText: statusText,
              statusClass: statusClass,
              submitButtonText: that.getSubmitButtonText(certificationData.status)
            });
          } else {
              // 没有认证数据，清空表单
              console.log('用户尚未提交认证信息，清空表单');
            that.setData({
              hasCertification: false,
              certificationStatus: 0,
              statusText: '未认证',
              statusClass: 'unknown',
                submitButtonText: '提交认证',
                formData: {
                  real_name: '',
                  id_card: '',
                  gender: 0,
                  age: '',
                  address: '',
                  emergency_contact: '',
                  created_at: ''
                }
            });
          }
          return;
        }
        
        if (res.data.code === 401 || res.data.code === 403) {
          // 身份验证错误
          console.error('认证状态请求被拒绝:', res.data.code, res.data.message);
          wx.showModal({
            title: '登录过期',
            content: '您的登录状态已过期，需要重新登录。',
            showCancel: false,
            success: (res) => {
              if (res.confirm) {
                wx.navigateTo({
                  url: '/pages/login/login'
                });
              }
            }
          });
        } else {
            // 其他错误，清空表单
          console.error('获取认证状态失败:', res.data.code, res.data.message);
            that.setData({
              hasCertification: false,
              formData: {
                real_name: '',
                id_card: '',
                gender: 0,
                age: '',
                address: '',
                emergency_contact: '',
                created_at: ''
              }
            });
          wx.showToast({
            title: res.data.message || '获取认证状态失败',
            icon: 'none'
          });
        }
      },
      fail: function(error) {
        console.error('获取认证状态请求失败:', error);
        
        // 根据错误类型提供更具体的反馈
        if (error.errMsg && error.errMsg.includes('request:fail')) {
          wx.showModal({
            title: '网络连接失败',
            content: '无法连接到服务器，请检查网络连接后重试。',
            showCancel: false,
            success: (res) => {
              if (res.confirm) {
                // 用户确认后重试
                that.checkCertificationStatus();
              }
            }
          });
        } else {
          wx.showToast({
            title: '获取认证状态失败',
            icon: 'none'
          });
        }
      },
      complete: function() {
        console.log('认证状态检查请求完成');
      }
      });
    }).catch(error => {
      console.error('获取用户ID失败:', error);
      wx.showToast({
        title: '获取用户信息失败，请重新登录',
        icon: 'none'
      });
    });
  },
  
  /**
   * 获取状态样式和文本
   */
  getStatusInfo(status) {
    let statusText = '';
    let statusClass = '';
    
    switch (status) {
      case 1:
        statusText = '已认证';
        statusClass = 'success';
        break;
      case 2:
        statusText = '审核中';
        statusClass = 'pending';
        break;
      case 3:
        statusText = '认证失败';
        statusClass = 'rejected';
        break;
      default:
        statusText = '未认证';
        statusClass = 'unknown';
    }
    
    return { statusText, statusClass };
  },
  
  /**
   * 获取提交按钮文本
   */
  getSubmitButtonText(status) {
    switch (status) {
      case 1:
        return '更新信息';
      case 2:
        return '审核中';
      case 3:
        return '重新提交';
      default:
        return '提交认证';
    }
  },

  /**
   * 更新状态显示
   */
  updateStatusDisplay() {
    const status = this.data.certificationStatus;
    const { statusText, statusClass } = this.getStatusInfo(status);
    const submitButtonText = this.getSubmitButtonText(status);
    
    this.setData({
      statusText: statusText,
      statusClass: statusClass,
      submitButtonText: submitButtonText
    });
  },

  /**
   * 验证身份证号（简化校验：18位数字和大写字母X）
   */
  validateIdCard: function(idCard) {
    // 简化验证：只要求18位，包含数字和大写字母X
    const reg = /^[0-9X]{18}$/;
    if (!reg.test(idCard)) {
      console.log('身份证号格式不正确，必须是18位数字和大写字母X');
      return false;
    }
    
    return true;
  },
  
  /**
   * 验证表单
   */
  validateForm: function() {
    const { real_name, id_card, gender, age, address, emergency_contact } = this.data.formData;
    
    // 验证必填项
    if (!real_name || real_name.trim().length === 0) {
      wx.showToast({ title: '请输入真实姓名', icon: 'none' });
      return false;
    }
    
    if (real_name.trim().length < 2 || real_name.trim().length > 10) {
      wx.showToast({ title: '姓名长度应在2-10个字符之间', icon: 'none' });
      return false;
    }
    
    if (!id_card || id_card.trim().length === 0) {
      wx.showToast({ title: '请输入身份证号', icon: 'none' });
      return false;
    }
    
    // 更严格的身份证号验证
    if (!this.validateIdCard(id_card)) {
      wx.showToast({ title: '请输入有效的身份证号', icon: 'none' });
      return false;
    }
    
    if (gender === 0) {
      wx.showToast({ title: '请选择性别', icon: 'none' });
      return false;
    }
    
    // 验证年龄
    if (age && (parseInt(age) < 16 || parseInt(age) > 70)) {
      wx.showToast({ title: '志愿者年龄应在16-70岁之间', icon: 'none' });
      return false;
    }
    
    // 验证地址
    if (address && address.trim().length < 5) {
      wx.showToast({ title: '请输入详细的居住地址', icon: 'none' });
      return false;
    }
    
    if (!emergency_contact || emergency_contact.trim().length === 0) {
      wx.showToast({ title: '请输入紧急联系人电话', icon: 'none' });
      return false;
    }
    
    // 严格的手机号验证
    const phoneReg = /^1[3-9]\d{9}$/;
    if (!phoneReg.test(emergency_contact)) {
      wx.showToast({ title: '请输入有效的手机号', icon: 'none' });
      return false;
    }
    
    return true;
  },

  /**
   * 提交认证信息
   */
  submitCertification: function() {
    if (this.data.submitting) return;
    
    // 验证表单
    if (!this.validateForm()) {
      return;
    }
    
    this.setData({ submitting: true });
    const that = this;
    
    // 获取当前登录用户的真实ID
    this.getCurrentUserId().then(userId => {
    console.log('提交阶段解析到的user_id:', userId);
    
    // 验证user_id是否有效
    if (!userId) {
      wx.showToast({
        title: '无法获取用户信息，请重新登录',
        icon: 'none'
      });
        that.setData({ submitting: false });
      return;
    }
    
    // 打印提交的数据，用于调试
    const submitData = {
      user_id: userId,
        ...that.data.formData
    };
    console.log('提交的数据:', submitData);
    
    post('/volunteer/certification', submitData).then(res => {
      if (res && res.success) {
        wx.showToast({ 
          title: '提交成功，已通过认证', 
          icon: 'success',
          duration: 2000,
          success: function() {
            // 更新认证状态
            that.setData({
              hasCertification: true,
              certificationStatus: 1,
              formData: {
                ...that.data.formData,
                created_at: that.formatDate(new Date())
              }
            });
            that.updateStatusDisplay();
          }
        });
      } else {
        wx.showToast({ 
          title: res?.message || '提交失败', 
          icon: 'none' 
        });
      }
    }).catch(error => {
      console.error('提交认证失败:', error);
      wx.showToast({ 
        title: '网络错误，请稍后重试', 
        icon: 'none' 
      });
    }).finally(() => {
        that.setData({ submitting: false });
      });
    }).catch(error => {
      console.error('获取用户ID失败:', error);
      wx.showToast({
        title: '获取用户信息失败，请重新登录',
        icon: 'none'
      });
      that.setData({ submitting: false });
    });
  },

  /**
   * 格式化日期
   */
  formatDate: function(date) {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    const hours = d.getHours().toString().padStart(2, '0');
    const minutes = d.getMinutes().toString().padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}`;
  },
  
  /**
   * 统一获取用户ID（已弃用，使用getCurrentUserId替代）
   */
  getUserId() {
    try {
      const userInfo = userStores.getUserInfo();
      if (userInfo && userInfo.user_id) {
        return userInfo.user_id;
      }
      
      const storedUserId = wx.getStorageSync('user_id');
      if (storedUserId) {
        return storedUserId;
      }
    } catch (error) {
      console.error('获取user_id失败:', error);
    }
    
    return '';
  },

  /**
   * 获取当前登录用户的真实ID（从API获取，确保准确性）
   */
  getCurrentUserId() {
    return new Promise((resolve, reject) => {
      // 总是从API获取最新的用户ID，确保准确性
      console.log('从API获取当前用户ID');
      const { authAPI } = require('../../utils/api');
      authAPI.getProfile()
        .then(res => {
          if (res && res.success && res.data && res.data.id) {
            const userId = res.data.id.toString();
            console.log('从API获取到的用户ID:', userId);
            
            // 保存到本地存储
            wx.setStorageSync('user_id', userId);
            const storedUserInfo = wx.getStorageSync('userInfo') || {};
            storedUserInfo.id = userId;
            wx.setStorageSync('userInfo', storedUserInfo);
            
            resolve(userId);
          } else {
            console.error('API返回的用户信息中没有ID字段，响应:', res);
            reject(new Error('无法获取用户ID'));
          }
        })
        .catch(error => {
          console.error('获取用户信息失败:', error);
          // API失败时，尝试使用本地存储的ID作为备用
          const storedUserId = wx.getStorageSync('user_id');
          if (storedUserId && storedUserId !== '') {
            console.log('API失败，使用本地存储的用户ID:', storedUserId);
            resolve(storedUserId);
          } else {
            reject(error);
          }
        });
    });
  }
});