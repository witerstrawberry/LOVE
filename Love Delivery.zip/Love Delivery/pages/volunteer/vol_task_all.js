// pages/volunteer/vol_task_all.js
const { get } = require('../../utils/request');

Page({
  /**
   * 页面的初始数据
   */
  data: {
    tasks: [],
    searchQuery: '',
    filteredTasks: [],
    loading: true,
    error: '',
    sortBy: 'default', // 默认排序
    showFilter: false, // 筛选面板显示状态
    filterOptions: {
      status: 'all',
      type: 'all'
    },
    // 时间筛选相关
    showTimeFilter: false, // 时间筛选下拉框显示状态
    timeFilterDays: 0, // 时间筛选天数，0表示全部时间
    timeFilterText: '时间', // 时间筛选显示文本
    // 人数排序相关
    showVolunteerSort: false, // 人数排序下拉框显示状态
    volunteerSortOrder: '', // 人数排序顺序，asc: 从少到多，desc: 从多到少
    volunteerSortText: '人数' // 人数排序显示文本
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadTasks();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.loadTasks();
  },

  /**
   * 加载任务列表
   */
  loadTasks: function () {
    wx.showLoading({ title: '加载任务中' });
    this.setData({ loading: true, error: '' });
    
    get('/tasks')
      .then(res => {
        if (res && res.success && res.data && Array.isArray(res.data.tasks)) {
          const formatted = res.data.tasks.map(task => ({
            id: task.task_id,
            title: task.task_title,
            status: this.mapStatus(task.status),
            time: this.formatTaskTime(task.start_time, task.end_time),
            start_time: task.start_time, // 保存原始开始时间用于筛选
            end_time: task.end_time, // 保存原始结束时间用于筛选
            location: task.address,
            volunteersNeeded: task.require_num,
            description: task.task_content,
            isClaimed: !!task.is_claimed,
            merchantName: task.merchant_name || '',
            orderCount: task.order_count || 0,
            taskType: task.task_type,
            statusCode: task.status
          }));
          this.setData({ 
            tasks: formatted,
            filteredTasks: formatted
          });
        } else {
          wx.showToast({ title: res?.message || '获取任务失败', icon: 'none' });
          this.setData({ error: '获取任务失败' });
        }
      })
      .catch(error => {
        console.error('加载任务失败:', error);
        wx.showToast({ title: error?.message || '加载任务失败', icon: 'none' });
        this.setData({ error: '网络错误，请稍后重试' });
      })
      .finally(() => {
        wx.hideLoading();
        this.setData({ loading: false });
      });
  },

  /**
   * 搜索输入处理
   */
  onSearchInput: function (e) {
    const searchQuery = e.detail.value;
    this.setData({ searchQuery });
    this.filterTasks();
  },

  /**
   * 清除搜索
   */
  clearSearch: function () {
    this.setData({ searchQuery: '' });
    this.filterTasks();
  },

  /**
   * 筛选任务
   */
  filterTasks: function () {
    const { tasks, searchQuery, filterOptions, timeFilterDays } = this.data;
    let filtered = [...tasks];

    // 按关键词搜索
    if (searchQuery) {
      const keyword = searchQuery.toLowerCase();
      filtered = filtered.filter(task => 
        (task.title && task.title.toLowerCase().includes(keyword)) ||
        (task.description && task.description.toLowerCase().includes(keyword)) ||
        (task.location && task.location.toLowerCase().includes(keyword)) ||
        (task.merchantName && task.merchantName.toLowerCase().includes(keyword))
      );
    }

    // 按状态筛选
    if (filterOptions.status !== 'all') {
      filtered = filtered.filter(task => task.statusCode === parseInt(filterOptions.status));
    }

    // 按类型筛选
    if (filterOptions.type !== 'all') {
      filtered = filtered.filter(task => task.taskType === filterOptions.type);
    }

    // 按时间段筛选
    if (timeFilterDays > 0) {
      const now = new Date();
      // 计算N天前的日期（只比较日期，不考虑时间）
      const daysAgo = new Date(now);
      daysAgo.setDate(now.getDate() - timeFilterDays);
      daysAgo.setHours(0, 0, 0, 0); // 设置为当天的0点
      
      // 今天的日期（只比较日期部分）
      const today = new Date(now);
      today.setHours(0, 0, 0, 0);
      
      filtered = filtered.filter(task => {
        if (!task.start_time) {
          console.log('任务缺少开始时间，跳过:', task.id);
          return false;
        }
        try {
          // 解析任务的开始时间
        const taskDate = new Date(task.start_time);
          if (isNaN(taskDate.getTime())) {
            console.log('任务开始时间格式无效，跳过:', task.id, task.start_time);
            return false;
          }
          // 只比较日期部分，忽略时间
          taskDate.setHours(0, 0, 0, 0);
          // 筛选条件：任务日期 >= N天前 且 <= 今天（近N天内的任务）
          const isInRange = taskDate >= daysAgo && taskDate <= today;
          if (!isInRange) {
            console.log(`任务日期不在筛选范围内: 任务日期=${taskDate.toISOString().split('T')[0]}, 筛选范围=${daysAgo.toISOString().split('T')[0]} 至 ${today.toISOString().split('T')[0]}`);
          }
          return isInRange;
        } catch (error) {
          console.error('解析任务时间失败:', error, task);
          return false;
        }
      });
      
      console.log(`时间筛选完成: 筛选条件=近${timeFilterDays}天, 筛选前=${tasks.length}个任务, 筛选后=${filtered.length}个任务`);
    }

    // 排序
    filtered = this.sortTasks(filtered, this.data.sortBy);

    this.setData({ filteredTasks: filtered });
  },

  /**
   * 排序任务
   */
  sortTasks: function (tasks, sortBy) {
    const sorted = [...tasks];
    switch (sortBy) {
      case 'time':
        // 按时间排序（假设时间格式可以直接比较）
        return sorted.sort((a, b) => new Date(a.time) - new Date(b.time));
      case 'volunteers':
        // 按所需志愿者数量排序，支持升序和降序
        const { volunteerSortOrder } = this.data;
        if (volunteerSortOrder === 'asc') {
          return sorted.sort((a, b) => a.volunteersNeeded - b.volunteersNeeded);
        } else if (volunteerSortOrder === 'desc') {
          return sorted.sort((a, b) => b.volunteersNeeded - a.volunteersNeeded);
        }
        return sorted;
      case 'status':
        // 按状态排序
        return sorted.sort((a, b) => a.statusCode - b.statusCode);
      default:
        // 默认排序（按任务ID）
        return sorted.sort((a, b) => a.id - b.id);
    }
  },

  /**
   * 切换排序方式
   */
  changeSort: function (e) {
    const sortBy = e.currentTarget.dataset.sort;
    this.setData({ sortBy });
    this.filterTasks();
  },

  /**
   * 切换筛选面板
   */
  toggleFilter: function () {
    this.setData({ showFilter: !this.data.showFilter });
  },

  /**
   * 应用筛选
   */
  applyFilter: function () {
    this.setData({ showFilter: false });
    this.filterTasks();
  },

  /**
   * 重置筛选
   */
  resetFilter: function () {
    this.setData({
      filterOptions: {
        status: 'all',
        type: 'all'
      },
      // 重置时间筛选
      timeFilterDays: 0,
      timeFilterText: '时间',
      // 重置人数排序
      volunteerSortOrder: '',
      volunteerSortText: '人数'
    });
    this.filterTasks();
  },

  /**
   * 选择筛选条件
   */
  selectFilter: function (e) {
    const { type, value } = e.currentTarget.dataset;
    this.setData({
      [`filterOptions.${type}`]: value
    });
  },

  /**
   * 切换时间筛选下拉框
   */
  toggleTimeFilter: function () {
    // 关闭其他下拉框
    this.setData({
      showVolunteerSort: false,
      showTimeFilter: !this.data.showTimeFilter
    });
  },

  /**
   * 选择时间筛选
   */
  selectTimeFilter: function (e) {
    const days = parseInt(e.currentTarget.dataset.days);
    let text = '时间';
    switch (days) {
      case 0:
        text = '全部时间';
        break;
      case 7:
        text = '近一周';
        break;
      case 15:
        text = '近15天';
        break;
      case 30:
        text = '近30天';
        break;
    }
    this.setData({
      timeFilterDays: days,
      timeFilterText: text,
      showTimeFilter: false
    });
    this.filterTasks();
  },

  /**
   * 切换人数排序下拉框
   */
  toggleVolunteerSort: function () {
    // 关闭其他下拉框
    this.setData({
      showTimeFilter: false,
      showVolunteerSort: !this.data.showVolunteerSort
    });
  },

  /**
   * 选择人数排序方式
   */
  selectVolunteerSort: function (e) {
    const order = e.currentTarget.dataset.order;
    this.setData({
      volunteerSortOrder: order,
      sortBy: 'volunteers', // 设置为人数排序
      showVolunteerSort: false
    });
    this.filterTasks();
  },

  /**
   * 关闭所有筛选和排序菜单
   */
  closeAllFilters: function () {
    this.setData({
      showTimeFilter: false,
      showVolunteerSort: false
    });
  },

  /**
   * 查看任务详情
   */
  viewTaskDetail: function (e) {
    const taskId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/volunteer/vol_data?id=' + taskId
    });
  },

  /**
   * 认领任务
   */
  claimTask: function (e) {
    // 阻止事件冒泡
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    }
    
    const taskId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认认领',
      content: '确定要认领这个任务吗？',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/volunteer/vol_task_detail?id=' + taskId + '&action=claim'
          });
        }
      }
    });
  },

  /**
   * 格式化任务时间
   * 格式：2024年11月13日6：00-2024年11月13日20：00
   */
  formatTaskTime: function (start, end) {
    if (!start || !end) return '';
    const startTime = new Date(start);
    const endTime = new Date(end);
    
    // 格式化日期为年月日格式
    const formatDate = (date) => {
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      return `${year}年${month}月${day}日`;
    };
    
    // 格式化时间为时：分格式
    const formatTime = (date) => {
      const hours = date.getHours();
      const minutes = date.getMinutes();
      return `${hours}：${minutes.toString().padStart(2, '0')}`;
    };
    
    const startDateStr = formatDate(startTime);
    const startTimeStr = formatTime(startTime);
    const endDateStr = formatDate(endTime);
    const endTimeStr = formatTime(endTime);
    
    // 如果开始和结束是同一天，只显示一次日期
    if (startDateStr === endDateStr) {
      return `${startDateStr}${startTimeStr}-${endTimeStr}`;
    } else {
      return `${startDateStr}${startTimeStr}-${endDateStr}${endTimeStr}`;
    }
  },

  /**
   * 映射任务状态
   */
  mapStatus: function (status) {
    switch (status) {
      case 1:
        return '招募中';
      case 2:
        return '进行中';
      case 3:
        return '已完成';
      case 4:
        return '已取消';
      default:
        return '未知状态';
    }
  }
})