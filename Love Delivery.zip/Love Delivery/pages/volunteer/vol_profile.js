// pages/volunteer/vol_profile.js
const { authAPI } = require('../../utils/api');
const { get } = require('../../utils/request');
const { getFullImageUrl } = require('../../utils/imageUtils');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {
      name: '',
      id: '',
      avatar: '/images/default-avatar.png.txt'
    },
    stats: {
      totalHours: 0,
      totalTasks: 0,
      rating: 4.8
    },
    loading: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.loadUserInfo();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 每次页面显示时刷新用户信息
    this.loadUserInfo();
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo() {
    try {
      this.setData({ loading: true });
      
      // 获取用户基本信息
      const response = await authAPI.getProfile();
      console.log('获取到的用户信息:', response);
      
      // 检查响应是否成功并且有data字段
      if (response.success && response.data) {
        const userProfile = response.data;
        
        // 使用getFullImageUrl处理头像URL，确保替换localhost:3000为正确的云服务器域名
        let avatarUrl = userProfile.avatar || '/images/default-avatar.png.txt';
        avatarUrl = getFullImageUrl(avatarUrl);
        
        // 构建用户信息对象，适配前端显示格式
        const formattedUserInfo = {
          name: userProfile.nickname || userProfile.phone || '志愿者',
          id: userProfile.id ? `VOL${String(userProfile.id).padStart(6, '0')}` : '',
          avatar: avatarUrl
        };
        
        // 设置用户信息
        this.setData({ userInfo: formattedUserInfo });
        
        // 获取志愿者统计信息（这里假设有一个专门的API，暂时使用模拟数据）
        this.loadVolunteerStats();
      } else {
        console.error('API返回数据结构异常:', response);
        wx.showToast({
          title: '数据格式错误',
          icon: 'none'
        });
      }
      
    } catch (error) {
      console.error('获取用户信息失败:', error);
      wx.showToast({
        title: '获取信息失败，请重试',
        icon: 'none'
      });
    } finally {
      this.setData({ loading: false });
    }
  },
  
  /**
   * 加载志愿者统计信息
   */
  async loadVolunteerStats() {
    try {
      const res = await get('/tasks/volunteer/stats');
      if (res && res.success && res.data) {
        const statsData = {
          totalHours: Number(res.data.total_hours || 0),
          totalTasks: Number(res.data.total_tasks || 0),
          rating: 4.8 // 服务评分硬编码为4.8
        };
        this.setData({ stats: statsData });
      } else {
        // 即使API失败，也设置默认值，确保rating显示为4.8
        this.setData({ 
          stats: {
            ...this.data.stats,
            rating: 4.8
          }
        });
        wx.showToast({ title: res?.message || '获取统计信息失败', icon: 'none' });
      }
    } catch (error) {
      console.error('获取统计信息失败:', error);
      // API调用失败时，也要确保rating显示为4.8
      this.setData({ 
        stats: {
          ...this.data.stats,
          rating: 4.8
        }
      });
      wx.showToast({ title: error?.message || '获取统计信息失败', icon: 'none' });
    }
  },

  /**
   * 编辑头像（选择图片并上传，同时更新后端 users 表的 avatar_url 字段）
   */
  editProfile() {
    const app = getApp();
    const token = wx.getStorageSync('token');
    const { getBaseUrl } = require('../../utils/config');
    const baseUrl = getBaseUrl();
    const uploadUrl = `${baseUrl}/upload/avatar`;

    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const filePath = res.tempFilePaths[0];
        wx.showLoading({
          title: '上传中...',
          mask: true
        });

        wx.uploadFile({
          url: uploadUrl,
          filePath,
          name: 'avatar',
          header: {
            'Authorization': token ? `Bearer ${token}` : ''
          },
          formData: {
            // 不传 user_type，使用默认 /uploads/avatars 目录
            type: 'avatar'
          },
          success: async (uploadRes) => {
            try {
              const data = typeof uploadRes.data === 'string'
                ? JSON.parse(uploadRes.data)
                : uploadRes.data;

              if (!data || !data.success || !data.data || !data.data.url) {
                wx.showToast({
                  title: data?.error || data?.message || '上传失败',
                  icon: 'none',
                  duration: 3000
                });
                return;
              }

              let avatarUrl = data.data.url;
              console.log('上传返回的原始URL:', avatarUrl);
              
              // 将localhost:3000的URL转换为相对路径，用于保存到数据库
              let urlToSave = avatarUrl;
              if (avatarUrl && (avatarUrl.startsWith('http://localhost:3000') || avatarUrl.startsWith('https://localhost:3000'))) {
                // 提取相对路径部分（如 /uploads/avatars/avatar-xxx.jpg）
                urlToSave = avatarUrl.replace('http://localhost:3000', '').replace('https://localhost:3000', '');
                console.log('转换为相对路径用于保存:', urlToSave);
              }
              
              // 使用getFullImageUrl处理头像URL，确保替换localhost:3000为正确的云服务器域名（用于前端显示）
              avatarUrl = getFullImageUrl(avatarUrl);
              console.log('处理后的完整URL（用于显示）:', avatarUrl);

              // 调用后端更新用户资料，写入 users 表的 avatar_url 字段（保存相对路径）
              await authAPI.updateProfile({
                avatar_url: urlToSave // 保存相对路径到后端
              });

              // 前端立即更新头像显示，使用处理后的完整URL
              this.setData({
                'userInfo.avatar': avatarUrl
              });

              wx.showToast({
                title: '头像更新成功',
                icon: 'success'
              });
            } catch (e) {
              console.error('解析上传结果或更新资料失败:', e);
              wx.showToast({
                title: '头像更新失败，请重试',
                icon: 'none'
              });
            }
          },
          fail: (err) => {
            console.error('头像上传失败:', err);
            let errorMsg = '上传失败，请检查网络';
            // 尝试从错误响应中获取具体错误信息
            if (err.errMsg && err.errMsg.includes('timeout')) {
              errorMsg = '上传超时，请重试';
            } else if (err.statusCode === 400) {
              // 如果是400错误，可能是文件大小超限
              errorMsg = '文件过大，请选择较小的图片';
            }
            wx.showToast({
              title: errorMsg,
              icon: 'none',
              duration: 3000
            });
          },
          complete: () => {
            wx.hideLoading();
          }
        });
      },
      fail: () => {
        // 用户取消选择图片，不做提示
      }
    });
  },

  /**
   * 查看我的任务
   */
  viewMyTasks() {
    wx.navigateTo({
      url: '/pages/volunteer/vol_my_tasks?status=ongoing'
    });
  },

  /**
   * 查看已完成任务
   */
  viewCompletedTasks() {
    wx.navigateTo({
      url: '/pages/volunteer/vol_my_tasks?status=completed'
    });
  },

  /**
   * 查看志愿者认证
   */
  viewCertification() {
    wx.navigateTo({
      url: '/pages/volunteer/vol_certification'
    });
  },

  /**
   * 查看账号设置
   */
  viewSettings() {
    wx.navigateTo({
      url: '/pages/volunteer/vol_settings'
    });
  },

  /**
   * 查看帮助中心
   */
  viewHelp() {
    wx.navigateTo({
      url: '/pages/help-center/index'
    });
  },

  /**
   * 联系客服
   */
  contactSupport() {
    wx.makePhoneCall({
      phoneNumber: '400-123-4567'
    });
  },

  /**
   * 关于我们
   */
  aboutUs() {
    wx.showModal({
      title: '关于我们',
      content: '颐养食光志愿者服务平台\n致力于为社区老人提供优质的志愿服务\n版本：1.0.0',
      showCancel: false
    });
  },

  /**
   * 退出登录
   */
  logout() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除登录状态
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          
          // 跳转到登录页
          wx.redirectTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  }
})