// pages/volunteer/vol_task_detail.js
const { get, post, put } = require('../../utils/request');

Page({
  /**
   * 页面的初始数据
   */
  data: {
    orderId: '',
    userRoleId: null, // 用户角色ID：2=商家，3=志愿者
    showTabBar: true, // 是否显示TabBar
    showActionButtons: true, // 是否显示操作按钮
    taskInfo: {
      id: '',
      title: '爱心餐配送任务',
      status: 'waiting_volunteer',
      orderNo: '',
      createTime: '',
      restaurant: {
        name: '',
        address: '',
        latitude: 0,
        longitude: 0
      },
      recipient: {
        name: '',
        phone: '',
        address: '',
        latitude: 0,
        longitude: 0
      },
      currentLocation: null,
      distance: '',
      estimatedTime: ''
    },
    // 任务进度步骤，对应订单status枚举
    progressSteps: [
      {
        key: 'volunteer_accepted',
        title: '志愿者已接单',
        description: '志愿者已确认接单',
        completed: false,
        time: ''
      },
      {
        key: 'arrived_restaurant',
        title: '已到达餐厅',
        description: '志愿者已到达餐厅取餐',
        completed: false,
        time: ''
      },
      {
        key: 'shipped',
        title: '配送中',
        description: '志愿者正在配送途中',
        completed: false,
        time: ''
      },
      {
        key: 'delivered',
        title: '已送达',
        description: '餐食已送达给老人',
        completed: false,
        time: ''
      },
      {
        key: 'completed',
        title: '已完成',
        description: '任务已完成',
        completed: false,
        time: ''
      }
    ],
    // 当前登录用户是否为本单志愿者
    isCurrentVolunteer: false,
    // 订单是否有志愿者接单
    hasVolunteer: false,
    // 下一个状态按钮文字
    nextButtonText: '',
    // 是否可以更新状态
    canUpdateStatus: false,
    // 是否显示"无法接取"提示
    showCannotClaim: false,
    // 定位相关
    locationAuth: false,
    locationInterval: null,
    // 地图相关数据
    mapInfo: {
      centerLongitude: 113.27,
      centerLatitude: 23.13,
      scale: 15
    },
    mapMarkers: [],
    mapPolyline: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取用户角色ID
    const userInfo = wx.getStorageSync('userInfo');
    const roleId = userInfo?.role_id ? Number(userInfo.role_id) : null;
    
    // 根据角色ID控制显示
    const showTabBar = roleId === 3; // 只有志愿者显示TabBar
    const showActionButtons = roleId === 3; // 只有志愿者显示操作按钮
    
    this.setData({
      userRoleId: roleId,
      showTabBar,
      showActionButtons
    });
    
    if (options.orderId) {
      this.setData({
        orderId: options.orderId
      });
      this.fetchTaskDetails();
    } else {
      wx.showToast({ title: '缺少订单ID', icon: 'none' });
    }
    
    // 只有志愿者需要定位权限
    if (roleId === 3) {
      this.checkLocationAuth();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 页面显示时开始定位
    this.startLocationTracking();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // 页面隐藏时停止定位
    this.stopLocationTracking();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // 页面卸载时停止定位
    this.stopLocationTracking();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.fetchTaskDetails();
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },

  /**
   * 获取任务详情
   */
  fetchTaskDetails: function() {
    const { orderId } = this.data;
    if (!orderId) return;

    wx.showLoading({ title: '加载中...' });
    get(`/order/${orderId}/tracking`)
      .then(res => {
        console.log('订单轨迹接口返回数据:', res);
        if (!res || !res.success || !res.data) {
          wx.showToast({ title: res?.message || '获取订单详情失败', icon: 'none' });
          return;
        }

        const { order, isCurrentVolunteer, hasVolunteer = false, logs = [] } = res.data;
        console.log('=== 订单轨迹数据解析 ===');
        console.log('原始返回数据:', JSON.stringify(res.data, null, 2));
        console.log('订单对象:', order);
        console.log('订单状态:', order?.status);
        console.log('是否为志愿者:', isCurrentVolunteer);
        console.log('是否有志愿者接单:', hasVolunteer);
        console.log('轨迹日志:', logs);

        if (!order) {
          console.error('订单数据为空');
          wx.showToast({ title: '订单数据为空', icon: 'none' });
          return;
        }

        // 构建任务信息对象
        const taskInfo = {
          id: order.id || '',
          title: '爱心餐配送任务',
          status: order.status || 'pending',
          orderNo: order.order_no || '',
          createTime: order.created_at || '',
          restaurant: {
            name: order.restaurant_name || order.merchant_name || '餐厅',
            address: order.restaurant_address || order.merchant_address || '',
            latitude: Number(order.restaurant_latitude) || Number(order.merchant_latitude) || 0,
            longitude: Number(order.restaurant_longitude) || Number(order.merchant_longitude) || 0
          },
          recipient: {
            name: order.recipient_name || order.user_nickname || '未填写',
            phone: order.recipient_phone || order.user_phone || '未填写',
            address: order.delivery_address || '未填写配送地址',
            latitude: Number(order.recipient_latitude) || 0,
            longitude: Number(order.recipient_longitude) || 0
          },
          distance: '',
          estimatedTime: ''
        };

        console.log('构建的taskInfo:', JSON.stringify(taskInfo, null, 2));

        // 计算进度步骤
        const progressSteps = this.computeProgressSteps(order.status || 'pending', logs || []);
        console.log('计算后的progressSteps:', JSON.stringify(progressSteps, null, 2));

        // 计算按钮显示逻辑
        const currentStatus = order.status || 'pending';
        const nextStatusInfo = this.getNextStatusInfoForStatus(currentStatus);
        
        // 判断按钮显示逻辑
        let nextButtonText = '';
        let showCannotClaim = false;
        let canUpdateStatus = false;
        
        if (currentStatus === 'waiting_volunteer') {
          // 等待志愿者接单状态
          if (hasVolunteer && !isCurrentVolunteer) {
            // 已有其他志愿者接单，当前用户无法接取
            showCannotClaim = true;
            canUpdateStatus = false;
          } else {
            // 可以接单，显示"志愿者已接单"按钮
            nextButtonText = '志愿者已接单';
            canUpdateStatus = true; // waiting_volunteer状态下，允许接单
          }
        } else if (currentStatus === 'completed') {
          // 已完成，不显示按钮
          nextButtonText = '';
          canUpdateStatus = false;
        } else {
          // 其他状态：如果当前用户是志愿者，显示对应按钮
          if (isCurrentVolunteer && nextStatusInfo) {
            nextButtonText = nextStatusInfo.buttonText;
            canUpdateStatus = this.canUpdateStatus(currentStatus);
          } else {
            // 不是当前用户的订单，显示"无法接取"
            showCannotClaim = true;
            canUpdateStatus = false;
          }
        }

        // 更新页面数据
        this.setData({
          taskInfo,
          isCurrentVolunteer: !!isCurrentVolunteer,
          hasVolunteer: !!hasVolunteer,
          progressSteps,
          nextButtonText,
          canUpdateStatus,
          showCannotClaim
        }, () => {
          console.log('=== setData完成 ===');
          console.log('当前taskInfo:', this.data.taskInfo);
          console.log('当前progressSteps:', this.data.progressSteps);
          console.log('当前isCurrentVolunteer:', this.data.isCurrentVolunteer);
        });

        // 根据餐厅和收货人位置更新地图
        if (taskInfo.restaurant.longitude && taskInfo.restaurant.latitude) {
          this.updateMapMarkersAndRoutes(
            taskInfo.restaurant.longitude,
            taskInfo.restaurant.latitude
          );
        }
      })
      .catch(err => {
        console.error('获取订单轨迹失败:', err);
        wx.showToast({ title: err?.message || '加载失败', icon: 'none' });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  /**
   * 检查定位权限
   */
  checkLocationAuth: function() {
    const that = this;
    wx.getSetting({
      success: function(res) {
        if (res.authSetting['scope.userLocation']) {
          that.setData({ locationAuth: true });
          that.getLocation();
        } else {
          that.setData({ locationAuth: false });
        }
      }
    });
  },

  /**
   * 请求定位权限
   */
  requestLocationAuth: function() {
    const that = this;
    wx.authorize({
      scope: 'scope.userLocation',
      success: function() {
        that.setData({ locationAuth: true });
        that.getLocation();
      },
      fail: function() {
        that.setData({ locationAuth: false });
        wx.showModal({
          title: '定位权限',
          content: '请在设置中开启定位权限，以便我们为您提供准确的导航服务',
          success: function(res) {
            if (res.confirm) {
              wx.openSetting();
            }
          }
        });
      }
    });
  },

  /**
   * 获取当前位置
   */
  getLocation: function() {
    const that = this;
    wx.getLocation({
      type: 'gcj02',
      altitude: true,
      success: function(res) {
        const currentLocation = {
          latitude: res.latitude,
          longitude: res.longitude,
          accuracy: res.accuracy,
          altitude: res.altitude
        };
        that.setData({
          currentLocation,
          // 更新地图中心为当前位置
          'mapInfo.centerLongitude': res.longitude,
          'mapInfo.centerLatitude': res.latitude
        });
        that.calculateDistance();
        
        // 更新地图标记和路线
        that.updateMapMarkersAndRoutes(res.longitude, res.latitude);
      },
      fail: function(res) {
        console.error('获取位置失败:', res);
        wx.showToast({
          title: '获取位置失败',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 开始位置追踪
   */
  startLocationTracking: function() {
    if (!this.data.locationAuth) {
      this.requestLocationAuth();
      return;
    }
    
    // 每10秒更新一次位置
    this.data.locationInterval = setInterval(() => {
      this.getLocation();
    }, 10000);
  },

  /**
   * 停止位置追踪
   */
  stopLocationTracking: function() {
    if (this.data.locationInterval) {
      clearInterval(this.data.locationInterval);
      this.data.locationInterval = null;
    }
  },

  /**
   * 计算距离和预计时间
   */
  calculateDistance: function() {
    if (!this.data.currentLocation || !this.data.taskInfo.restaurant) return;
    
    const { latitude: currentLat, longitude: currentLon } = this.data.currentLocation;
    const { latitude: restaurantLat, longitude: restaurantLon } = this.data.taskInfo.restaurant;
    
    // 简单的距离计算（实际项目中可以使用更精确的算法）
    const distance = this.calculateHaversineDistance(
      currentLat, currentLon,
      restaurantLat, restaurantLon
    );
    
    // 估计时间（假设步行速度为5km/h）
    const estimatedTime = Math.round((distance / 5) * 60);
    
    this.setData({
      'taskInfo.distance': distance.toFixed(2) + 'km',
      'taskInfo.estimatedTime': estimatedTime + '分钟'
    });
  },

  /**
   * 使用Haversine公式计算两点之间的距离
   */
  calculateHaversineDistance: function(lat1, lon1, lat2, lon2) {
    const R = 6371; // 地球半径（公里）
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  },

  /**
   * 角度转弧度
   */
  toRad: function(deg) {
    return deg * (Math.PI/180);
  },

  /**
   * 更新地图标记和路线
   */
  updateMapMarkersAndRoutes: function(longitude, latitude) {
    const taskInfo = this.data.taskInfo;
    
    // 创建标记点
    const markers = [
      // 骑手位置标记
      {
        id: 0,
        longitude: longitude,
        latitude: latitude,
        width: 30,
        height: 30,
        title: '我的位置'
      },
      // 餐厅位置标记
      {
        id: 1,
        longitude: taskInfo.restaurant.longitude || longitude,
        latitude: taskInfo.restaurant.latitude || latitude,
        width: 30,
        height: 30,
        title: taskInfo.restaurant.name
      },
      // 接收者位置标记
      {
        id: 2,
        longitude: taskInfo.recipient.longitude || longitude,
        latitude: taskInfo.recipient.latitude || latitude,
        width: 30,
        height: 30,
        title: taskInfo.recipient.name
      }
    ];
    
    // 创建路线（根据任务进度决定显示哪段路线）
    let polyline = [];
    const currentStep = this.getCurrentStepIndex();
    
    // 根据任务进度显示不同的路线
    if (currentStep < 2) {
      // 显示当前位置到餐厅的路线
      polyline = [{
        points: [
          { longitude: longitude, latitude: latitude },
          { longitude: taskInfo.restaurant.longitude, latitude: taskInfo.restaurant.latitude }
        ],
        color: '#07c160',
        width: 4,
        dottedLine: false
      }];
    } else {
      // 显示餐厅到接收者的路线
      polyline = [{
        points: [
          { longitude: taskInfo.restaurant.longitude, latitude: taskInfo.restaurant.latitude },
          { longitude: taskInfo.recipient.longitude, latitude: taskInfo.recipient.latitude }
        ],
        color: '#07c160',
        width: 4,
        dottedLine: false
      }];
    }
    
    this.setData({
      mapMarkers: markers,
      mapPolyline: polyline
    });
  },
  
  /**
   * 根据当前订单状态和日志计算进度步骤
   */
  computeProgressSteps: function(currentStatus, logs = []) {
    // 定义进度步骤模板
    const progressStepsTemplate = [
      {
        key: 'volunteer_accepted',
        title: '志愿者已接单',
        description: '志愿者已确认接单',
        completed: false,
        time: ''
      },
      {
        key: 'arrived_restaurant',
        title: '已到达餐厅',
        description: '志愿者已到达餐厅取餐',
        completed: false,
        time: ''
      },
      {
        key: 'shipped',
        title: '配送中',
        description: '志愿者正在配送途中',
        completed: false,
        time: ''
      },
      {
        key: 'delivered',
        title: '已送达',
        description: '餐食已送达给老人',
        completed: false,
        time: ''
      },
      {
        key: 'completed',
        title: '已完成',
        description: '任务已完成',
        completed: false,
        time: ''
      }
    ];

    const order = ['volunteer_accepted', 'arrived_restaurant', 'shipped', 'delivered', 'completed'];
    const idx = order.indexOf(currentStatus);
    const timeMap = {};
    
    // 从日志中提取每个状态的时间
    logs.forEach(log => {
      if (log.to_status && !timeMap[log.to_status]) {
        timeMap[log.to_status] = log.created_at;
      }
    });

    // 计算每个步骤的完成状态和时间
    const steps = progressStepsTemplate.map(step => {
      const stepIndex = order.indexOf(step.key);
      const isCompleted = stepIndex !== -1 && idx !== -1 && stepIndex <= idx;
      return {
        ...step,
        completed: isCompleted,
        time: this.formatDateTime(timeMap[step.key]) || ''
      };
    });
    
    console.log('computeProgressSteps 计算结果:', {
      currentStatus,
      idx,
      timeMap,
      steps
    });
    
    return steps;
  },

  /**
   * 获取当前进度步骤索引（用于地图展示）
   */
  getCurrentStepIndex: function() {
    const steps = this.data.progressSteps;
    for (let i = steps.length - 1; i >= 0; i--) {
      if (steps[i].completed) {
        return i;
      }
    }
    return 0;
  },

  /**
   * 订单状态中文文案
   */
  mapStatusText: function(status) {
    switch (status) {
      case 'pending':
        return '待付款';
      case 'cancelled':
        return '已取消';
      case 'refunded':
        return '已退款';
      case 'paid':
        return '顾客已下单';
      case 'customer_accepted':
        return '顾客已确认';
      case 'merchant_accepted':
        return '商家已接单';
      case 'waiting_volunteer':
        return '等待志愿者接单';
      case 'volunteer_accepted':
        return '志愿者已接单';
      case 'arrived_restaurant':
        return '已到达餐厅';
      case 'shipped':
        return '配送中';
      case 'delivered':
        return '已送达';
      case 'completed':
        return '已完成';
      default:
        return '未知状态';
    }
  },



  /**
   * 获取当前时间
   */
  getCurrentTime: function() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  },

  /**
   * 格式化日期时间，将ISO格式转换为YYYY-MM-DD HH:mm:ss格式
   */
  formatDateTime: function(value) {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    const h = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    const sec = String(date.getSeconds()).padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}:${sec}`;
  },

  /**
   * 志愿者接单（waiting_volunteer状态下）
   */
  acceptOrder: function() {
    const { orderId, taskInfo, hasVolunteer } = this.data;

    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' });
      return;
    }

    if (taskInfo.status !== 'waiting_volunteer') {
      wx.showToast({ title: '订单状态不正确', icon: 'none' });
      return;
    }

    // 检查是否已有其他志愿者接单
    if (hasVolunteer) {
      wx.showToast({ title: '该订单已被其他志愿者接取', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '接单中...' });
    post(`/order/${orderId}/accept`)
      .then(res => {
        if (res && res.success) {
          wx.showToast({
            title: '志愿者已接单，状态更新成功',
            icon: 'success'
          });
          // 重新拉取订单+轨迹，保持前端进度与后端一致
          this.fetchTaskDetails();
        } else {
          wx.showToast({ title: res?.message || '接单失败', icon: 'none' });
        }
      })
      .catch(err => {
        console.error('接单失败:', err);
        wx.showToast({ title: err?.message || '接单失败', icon: 'none' });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  /**
   * 通用订单状态更新（志愿者操作）
   */
  updateOrderStatus: function(targetStatus, options = {}) {
    const { requiredStatus, successMessage } = options;
    const { orderId, taskInfo, isCurrentVolunteer } = this.data;

    if (!isCurrentVolunteer) {
      wx.showToast({ title: '仅该订单志愿者可操作', icon: 'none' });
      return;
    }

    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' });
      return;
    }

    if (requiredStatus && taskInfo.status !== requiredStatus) {
      wx.showToast({
        title: `状态更新失败：当前订单不处于${this.mapStatusText(requiredStatus)}状态`,
        icon: 'none'
      });
      return;
    }

    wx.showLoading({ title: '提交中...' });
    put(`/order/${orderId}/status`, { status: targetStatus })
      .then(res => {
        if (res && res.success) {
          wx.showToast({
            title: successMessage || '状态更新成功',
            icon: 'success'
          });
          // 重新拉取订单+轨迹，保持前端进度与后端一致
          this.fetchTaskDetails();
        } else {
          wx.showToast({ title: res?.message || '状态更新失败', icon: 'none' });
        }
      })
      .catch(err => {
        console.error('更新订单状态失败:', err);
        wx.showToast({ title: err?.message || '状态更新失败', icon: 'none' });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  /**
   * 获取下一个状态和按钮文字（根据当前状态）
   */
  getNextStatusInfo: function() {
    return this.getNextStatusInfoForStatus(this.data.taskInfo.status);
  },

  /**
   * 根据状态获取下一个状态信息（静态方法）
   */
  getNextStatusInfoForStatus: function(currentStatus) {
    const statusFlow = {
      'waiting_volunteer': {
        nextStatus: 'volunteer_accepted',
        buttonText: '志愿者已接单',
        successMessage: '志愿者已接单，状态更新成功'
      },
      'volunteer_accepted': {
        nextStatus: 'arrived_restaurant',
        buttonText: '已到达餐厅',
        successMessage: '已标记到达餐厅'
      },
      'arrived_restaurant': {
        nextStatus: 'shipped',
        buttonText: '配送中',
        successMessage: '已标记配送中'
      },
      'shipped': {
        nextStatus: 'delivered',
        buttonText: '已送达',
        successMessage: '已标记送达'
      },
      'delivered': {
        nextStatus: 'completed',
        buttonText: '已完成',
        successMessage: '已标记任务完成'
      }
    };
    return statusFlow[currentStatus] || null;
  },

  /**
   * 判断是否可以更新状态
   */
  canUpdateStatus: function(currentStatus) {
    const volunteerStatuses = ['waiting_volunteer', 'volunteer_accepted', 'arrived_restaurant', 'shipped', 'delivered'];
    return volunteerStatuses.includes(currentStatus);
  },

  /**
   * 统一的状态更新按钮点击处理
   */
  handleStatusUpdate: function() {
    const { taskInfo } = this.data;
    const statusInfo = this.getNextStatusInfo();
    
    if (!statusInfo) {
      wx.showToast({
        title: '当前状态无法进行下一步操作',
        icon: 'none'
      });
      return;
    }

    // 特殊处理：waiting_volunteer状态下，调用接单接口
    if (taskInfo.status === 'waiting_volunteer' && statusInfo.nextStatus === 'volunteer_accepted') {
      this.acceptOrder();
      return;
    }

    // 其他状态更新，调用普通状态更新接口
    this.updateOrderStatus(statusInfo.nextStatus, {
      requiredStatus: taskInfo.status,
      successMessage: statusInfo.successMessage
    });
  },

  /**
   * 标记为到达餐厅（保留兼容性）
   */
  markArrivedAtRestaurant: function() {
    this.updateOrderStatus('arrived_restaurant', {
      requiredStatus: 'volunteer_accepted',
      successMessage: '已标记到达餐厅'
    });
  },

  /**
   * 标记为配送中（保留兼容性）
   */
  markDelivering: function() {
    this.updateOrderStatus('shipped', {
      requiredStatus: 'arrived_restaurant',
      successMessage: '已标记配送中'
    });
  },

  /**
   * 标记为已送达（保留兼容性）
   */
  markDelivered: function() {
    this.updateOrderStatus('delivered', {
      requiredStatus: 'shipped',
      successMessage: '已标记送达'
    });
  },

  /**
   * 标记为已完成（保留兼容性）
   */
  markCompleted: function() {
    this.updateOrderStatus('completed', {
      requiredStatus: 'delivered',
      successMessage: '已标记任务完成'
    });
  },

  /**
   * 拨打电话给接收者
   */
  callRecipient: function() {
    const phone = this.data.taskInfo.recipient.phone;
    wx.makePhoneCall({
      phoneNumber: phone
    });
  },

  /**
   * 导航到餐厅
   */
  navigateToRestaurant: function() {
    const { latitude, longitude, name } = this.data.taskInfo.restaurant;
    wx.openLocation({
      latitude,
      longitude,
      name,
      scale: 18
    });
  },

  /**
   * 导航到接收者位置
   */
  navigateToRecipient: function() {
    const { latitude, longitude, name } = this.data.taskInfo.recipient;
    wx.openLocation({
      latitude,
      longitude,
      name,
      scale: 18
    });
  },

  /**
   * 处理定位权限按钮点击
   */
  handleLocationAuth: function() {
    this.requestLocationAuth();
  },

  /**
   * 志愿者已接单
   */
  handleVolunteerAccepted: function() {
    this.updateOrderStatus('volunteer_accepted', {
      requiredStatus: 'waiting_volunteer',
      successMessage: '志愿者已接单，状态更新成功'
    });
  }
});