// pages/volunteer/index.js
const { get, post } = require('../../utils/request');
const { getResourceUrl } = require('../../utils/config');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 轮播图数据
    banners: [
      { id: '1', image: getResourceUrl('uploads/part/vol_1.png'), title: '社区关爱行动' },
      { id: '2', image: getResourceUrl('/uploads/part/vol_2.png'), title: '志愿者招募' },
      { id: '3', image: getResourceUrl('/uploads/part/vol_3.png'), title: '志愿服务月' }
    ],
    // 导航功能数据
    navFunctions: [
      { id: '1', name: '任务列表', icon: '📋', page: '/pages/volunteer/vol_task_all' },
      { id: '2', name: '志愿者认证', icon: '📜', page: '/pages/volunteer/vol_certification' },
      { id: '3', name: '个人资料', icon: '👤', page: '/pages/volunteer/vol_mine_information' },
      { id: '4', name: '帮助中心', icon: '❓', page: '/pages/help-center/index' }
    ],
    tasks: [], // 原始任务列表（已排序）
    displayedTasks: [], // 当前显示的任务列表（最多显示前N个）
    allTasks: [], // 保存所有任务（用于搜索等）
    searchQuery: '',
    displayCount: 3, // 初始显示的任务数量
    hasMore: false // 是否还有更多任务
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.loadTasks();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.loadTasks();
  },

  /**
   * 加载任务数据
   */
  loadTasks() {
    wx.showLoading({ title: '加载任务中' });
    get('/tasks')
      .then(res => {
        if (res && res.success && res.data && Array.isArray(res.data.tasks)) {
          const now = new Date().getTime();
          
          // 格式化任务数据，并保存原始时间用于排序
          const formatted = res.data.tasks.map(task => {
            const startTime = new Date(task.start_time).getTime();
            // 计算与当前时间的距离（绝对值，用于排序）
            const timeDistance = Math.abs(startTime - now);
            
            return {
              id: task.task_id,
              title: task.task_title,
              status: this.mapStatus(task.status),
              time: this.formatTaskTime(task.start_time, task.end_time),
              location: task.address,
              volunteersNeeded: task.require_num,
              description: task.task_content,
              isClaimed: !!task.is_claimed,
              merchantName: task.merchant_name || '',
              orderCount: task.order_count || 0,
              taskType: task.task_type,
              startTime: startTime, // 保存开始时间戳用于排序
              timeDistance: timeDistance // 保存与当前时间的距离用于排序
            };
          });
          
          // 按时间距离排序：距离当前时间越近的越靠上
          formatted.sort((a, b) => a.timeDistance - b.timeDistance);
          
          // 重置显示数量为初始的3个
          const displayCount = 3;
          const displayedTasks = formatted.slice(0, displayCount);
          const hasMore = formatted.length > displayCount;
          
          this.setData({ 
            tasks: displayedTasks, // 当前显示的任务
            allTasks: formatted, // 保存所有任务
            displayedTasks: displayedTasks, // 显示的任务列表
            displayCount: displayCount, // 重置显示数量
            hasMore: hasMore
          });
        } else {
          wx.showToast({ title: res?.message || '获取任务失败', icon: 'none' });
        }
      })
      .catch(error => {
        console.error('加载任务失败:', error);
        wx.showToast({ title: error?.message || '加载任务失败', icon: 'none' });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  /**
   * 搜索输入处理
   */
  onSearchInput(e) {
    const searchQuery = e.detail.value;
    this.setData({
      searchQuery
    });
    // 实时搜索任务
    this.filterTasks(searchQuery);
  },

  /**
   * 根据搜索词过滤任务
   */
  filterTasks(keyword) {
    if (!keyword.trim()) {
      // 如果搜索词为空，重新加载任务
      this.loadTasks();
      return;
    }

    // 在所有任务中进行搜索（使用allTasks）
    const allTasks = this.data.allTasks || [];
    if (allTasks.length > 0) {
      const filtered = allTasks.filter(task => 
        (task.title && task.title.toLowerCase().includes(keyword.toLowerCase())) ||
        (task.description && task.description.toLowerCase().includes(keyword.toLowerCase())) ||
        (task.location && task.location.toLowerCase().includes(keyword.toLowerCase())) ||
        (task.merchantName && task.merchantName.toLowerCase().includes(keyword.toLowerCase()))
      );
      
      // 搜索结果时显示所有匹配的任务，不限制数量
      this.setData({
        tasks: filtered,
        displayedTasks: filtered,
        hasMore: false // 搜索时不显示"加载更多"
      });
    } else {
      // 如果还没有任务数据，先加载所有任务然后过滤
      wx.showLoading({ title: '搜索中' });
      get('/tasks')
        .then(res => {
          if (res && res.success && res.data && Array.isArray(res.data.tasks)) {
            const now = new Date().getTime();
            
            const formatted = res.data.tasks.map(task => {
              const startTime = new Date(task.start_time).getTime();
              const timeDistance = Math.abs(startTime - now);
              
              return {
                id: task.task_id,
                title: task.task_title,
                status: this.mapStatus(task.status),
                time: this.formatTaskTime(task.start_time, task.end_time),
                location: task.address,
                volunteersNeeded: task.require_num,
                description: task.task_content,
                isClaimed: !!task.is_claimed,
                merchantName: task.merchant_name || '',
                orderCount: task.order_count || 0,
                taskType: task.task_type,
                startTime: startTime,
                timeDistance: timeDistance
              };
            });
            
            formatted.sort((a, b) => a.timeDistance - b.timeDistance);
            
            // 过滤任务
            const filtered = formatted.filter(task => 
              (task.title && task.title.toLowerCase().includes(keyword.toLowerCase())) ||
              (task.description && task.description.toLowerCase().includes(keyword.toLowerCase())) ||
              (task.location && task.location.toLowerCase().includes(keyword.toLowerCase())) ||
              (task.merchantName && task.merchantName.toLowerCase().includes(keyword.toLowerCase()))
            );
            
            this.setData({ 
              tasks: filtered,
              displayedTasks: filtered,
              allTasks: formatted,
              hasMore: false // 搜索时不显示"加载更多"
            });
          }
        })
        .catch(error => {
          console.error('搜索任务失败:', error);
          wx.showToast({ title: error?.message || '搜索失败', icon: 'none' });
        })
        .finally(() => {
          wx.hideLoading();
        });
    }
  },

  /**
   * 清除搜索内容
   */
  clearSearch() {
    this.setData({
      searchQuery: ''
    });
    // 清除搜索后重新加载任务（恢复默认显示3个）
    this.loadTasks();
  },

  /**
   * 加载更多任务
   */
  loadMoreTasks() {
    const allTasks = this.data.allTasks || [];
    const currentCount = this.data.displayCount || 3;
    const newCount = currentCount + 3; // 每次加载3个
    
    const displayedTasks = allTasks.slice(0, newCount);
    const hasMore = allTasks.length > newCount;
    
    this.setData({
      displayedTasks: displayedTasks,
      tasks: displayedTasks,
      displayCount: newCount,
      hasMore: hasMore
    });
  },

  /**
   * 导航功能点击处理
   */
  navigateToFunction(e) {
    const { page } = e.currentTarget.dataset;
    if (page) {
      wx.navigateTo({
        url: page
      });
    }
  },

  /**
   * 轮播图点击处理
   */
  onBannerClick(e) {
    const { id, title } = e.currentTarget.dataset;
    wx.showToast({
      title: `点击了${title}`,
      icon: 'none'
    });
  },

  /**
   * 查看任务详情
   */
  viewTaskDetail(e) {
    const taskId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/volunteer/vol_data?id=' + taskId
    });
  },

  /**
   * 认领任务
   */
  claimTask(e) {
    // 安全检查，确保stopPropagation方法存在才调用
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation(); // 阻止冒泡，避免触发viewTaskDetail
    }
    const taskId = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认认领',
      content: '确定要认领这个任务吗？',
      success: (res) => {
        if (res.confirm) {
          post(`/tasks/${taskId}/claim`)
            .then(claimRes => {
              if (claimRes && claimRes.success) {
                wx.showToast({ title: '认领成功', icon: 'success' });
                this.loadTasks();
              } else {
                wx.showToast({ title: claimRes?.message || '认领失败', icon: 'none' });
              }
            })
            .catch(error => {
              console.error('认领任务失败:', error);
              wx.showToast({ title: error?.message || '认领失败', icon: 'none' });
            });
        }
      }
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.loadTasks();
    wx.stopPullDownRefresh();
  },

  formatTaskTime(start, end) {
    if (!start || !end) return '';
    const startTime = new Date(start);
    const endTime = new Date(end);
    const format = (date) => {
      const m = (date.getMonth() + 1).toString().padStart(2, '0');
      const d = date.getDate().toString().padStart(2, '0');
      const h = date.getHours().toString().padStart(2, '0');
      const min = date.getMinutes().toString().padStart(2, '0');
      return `${m}-${d} ${h}:${min}`;
    };
    return `${format(startTime)} - ${endTime.getHours().toString().padStart(2, '0')}:${endTime.getMinutes().toString().padStart(2, '0')}`;
  },

  mapStatus(status) {
    switch (status) {
      case 1:
        return '招募中';
      case 2:
        return '进行中';
      case 3:
        return '已完成';
      case 4:
        return '已取消';
      default:
        return '未知状态';
    }
  }
})