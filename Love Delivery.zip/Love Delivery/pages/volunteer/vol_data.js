// pages/volunteer/vol_task_detail.js
const { get, post } = require('../../utils/request');

const DELIVERY_KEYWORDS = ['配送', '外卖', '外送', 'delivery', '快递', '送餐'];

Page({

  /**
   * 页面的初始数据
   */
  data: {
    taskId: '',
    task: {
      title: '',
      status: '',
      time: '',
      location: '',
      volunteersNeeded: 0,
      contactPerson: '',
      contactPhone: '',
      description: '',
      guideSteps: [],
      notice: ''
    },
    canClaim: true,
    isClaimedByCurrentUser: false, // 当前用户是否已接取任务
    loading: false,
    isDeliveryTask: false,
    deliveryTaskInfo: null,
    deliveryOrders: [],
    ordersLoading: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (options.id) {
      this.setData({
        taskId: options.id
      });
      this.loadTaskDetail(options.id);
    }
  },

  /**
   * 加载任务详情
   */
  loadTaskDetail(taskId) {
    if (!taskId) return;
    this.setData({ loading: true });
    wx.showLoading({ title: '加载中...' });

    get(`/tasks/${taskId}`)
      .then(res => {
        if (res && res.success && res.data) {
          const detail = res.data;
          const formattedTask = {
            title: detail.task_title,
            status: this.mapStatus(detail.status),
            time: this.formatTaskTime(detail.start_time, detail.end_time),
            location: detail.address,
            volunteersNeeded: detail.require_num,
            contactPerson: detail.contact_name || detail.merchant_name || '联系人',
            contactPhone: detail.contact_phone || detail.merchant_phone || '',
            description: detail.task_content || '',
            guideSteps: (detail.task_content ? detail.task_content.split('\n').filter(Boolean) : []),
            notice: detail.notice || '请准时到达集合地点，听从现场负责人安排。'
          };

          const isDeliveryTask = this.checkDeliveryTask(detail.task_type);

          this.setData({
            task: formattedTask,
            canClaim: !detail.is_claimed,
            isDeliveryTask,
            deliveryTaskInfo: isDeliveryTask ? this.formatDeliveryTaskInfo(detail) : null
          });
          
          // 检查当前用户是否已接取任务
          this.checkUserTaskRelation(taskId);

          if (isDeliveryTask) {
            this.loadTaskOrders(taskId, { silent: true });
          }
        } else {
          wx.showToast({ title: res?.message || '未找到任务', icon: 'none' });
        }
      })
      .catch(error => {
        console.error('获取任务详情失败:', error);
        wx.showToast({ title: error?.message || '加载失败', icon: 'none' });
      })
      .finally(() => {
        wx.hideLoading();
        this.setData({ loading: false });
      });
  },

  loadTaskOrders(taskId, opts = {}) {
    if (!taskId) return;
    const requestOptions = {};
    if (opts.silent) {
      requestOptions.showLoading = false;
    } else {
      this.setData({ ordersLoading: true });
    }

    get(`/tasks/${taskId}/orders`, {}, requestOptions)
      .then(res => {
        if (!res || !res.success || !res.data) {
          wx.showToast({ title: res?.message || '获取订单失败', icon: 'none' });
          return;
        }

        const taskInfo = this.formatDeliveryTaskInfo(res.data.task);
        let orders = Array.isArray(res.data.orders)
          ? res.data.orders
              .filter(order => order.status !== 'pending') // 过滤掉代付款状态的订单
              .map(order => this.formatOrder(order))
          : [];

        // 排序：将已完成的订单排在最下方
        orders = orders.sort((a, b) => {
          // 如果a是已完成状态，b不是，返回1，将a排在后面
          if (a.status === 'completed' && b.status !== 'completed') {
            return 1;
          }
          // 如果b是已完成状态，a不是，返回-1，将b排在后面
          if (b.status === 'completed' && a.status !== 'completed') {
            return -1;
          }
          // 其他情况，保持原有顺序
          return 0;
        });

        this.setData({
          deliveryTaskInfo: taskInfo,
          deliveryOrders: orders
        });
      })
      .catch(error => {
        console.error('获取任务关联订单失败:', error);
        wx.showToast({ title: error?.message || '请求失败', icon: 'none' });
      })
      .finally(() => {
        this.setData({ ordersLoading: false });
        if (opts.silent) {
          wx.stopPullDownRefresh();
        }
      });
  },

  checkDeliveryTask(taskType) {
    if (!taskType) return false;
    const raw = `${taskType}`;
    const lower = raw.toLowerCase();
    return DELIVERY_KEYWORDS.some(keyword => raw.includes(keyword) || lower.includes(keyword));
  },

  formatDeliveryTaskInfo(task = {}) {
    if (!task) return null;
    return {
      title: task.task_title || '未命名任务',
      statusText: this.mapStatus(task.status),
      type: task.task_type || '任务',
      address: task.address || '暂无任务地址',
      timeRange: this.formatTaskTime(task.start_time, task.end_time),
      merchantName: task.merchant_name || '未提供',
      contactName: task.contact_name || task.merchant_name || '联系人',
      contactPhone: task.contact_phone || task.merchant_phone || ''
    };
  },

  formatOrder(order = {}) {
    const statusKey = order.status ? order.status : 'unknown';
    const assignedVolunteerId = order.assigned_volunteer_id || order.volunteer_id || null;
    const assignedVolunteerName = order.volunteer_name || '';
    const canClaim = statusKey === 'waiting_volunteer' && !assignedVolunteerId;
    const claimHint = statusKey === 'waiting_volunteer'
      ? (canClaim ? '' : (assignedVolunteerName ? `${assignedVolunteerName} 已接单` : '该订单已被其他志愿者接取'))
      : '';

    return {
      orderId: order.order_id,
      orderNo: order.order_no || '--',
      status: statusKey,
      statusText: this.mapOrderStatus(statusKey),
      statusClass: `status-${statusKey}`,
      recipientName: order.recipient_name || '未填写',
      recipientPhone: order.recipient_phone || '',
      deliveryAddress: (() => {
        const { formatAddressOnly } = require('../../utils/addressUtils');
        const formatted = formatAddressOnly(order.delivery_address || '');
        return formatted || '暂无配送地址';
      })(),
      totalAmount: this.formatMoney(order.total_amount),
      deliveryFee: this.formatMoney(order.delivery_fee),
      orderType: order.order_type || '',
      remark: order.remark || '',
      createdAt: this.formatDateTime(order.created_at),
      updatedAt: this.formatDateTime(order.updated_at),
      assignedVolunteerId,
      assignedVolunteerName,
      canClaim,
      claimHint,
      deliveryStatus: order.volunteer_delivery_status || '',
      acceptTime: order.accept_time || '',
      pickupTime: order.pickup_time || '',
      deliveryTime: order.delivery_time || ''
    };
  },


  /**
   * 返回上一页
   */
  navigateBack() {
    wx.navigateBack();
  },

  /**
   * 认领任务
   */
  claimTask() {
    wx.showModal({
      title: '确认认领',
      content: '确定要认领这个任务吗？',
      success: (res) => {
        if (res.confirm) {
          post(`/tasks/${this.data.taskId}/claim`)
            .then(res => {
              if (res && res.success) {
                wx.showToast({ title: '认领成功', icon: 'success' });
                this.setData({ 
                  canClaim: false,
                  isClaimedByCurrentUser: true // 更新为当前用户已接取
                });
              } else {
                wx.showToast({ title: res?.message || '认领失败', icon: 'none' });
              }
            })
            .catch(error => {
              console.error('认领任务失败:', error);
              wx.showToast({ title: error?.message || '认领失败', icon: 'none' });
            });
        }
      }
    });
  },

  /**
   * 取消认领
   */
  cancelTask() {
    wx.showModal({
      title: '取消认领',
      content: '确定要取消认领这个任务吗？',
      success: (res) => {
        if (res.confirm) {
          // TODO: 后端尚未提供取消接口，这里仅提示
          wx.showToast({
            title: '请联系管理员取消',
            icon: 'none'
          });
        }
      }
    });
  },

  /**
   * 联系负责人
   */
  contactPerson() {
    const phone = this.data.task.contactPhone;
    if (!phone) {
      wx.showToast({ title: '暂无联系电话', icon: 'none' });
      return;
    }
    wx.makePhoneCall({
      phoneNumber: phone
    });
  },

  callTaskContact() {
    const phone = this.data.deliveryTaskInfo?.contactPhone || this.data.task.contactPhone;
    if (!phone) {
      wx.showToast({ title: '暂无联系人电话', icon: 'none' });
      return;
    }
    wx.makePhoneCall({ phoneNumber: phone });
  },

  callRecipient(e) {
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    }
    const phone = e?.currentTarget?.dataset?.phone;
    if (!phone) {
      wx.showToast({ title: '暂无联系电话', icon: 'none' });
      return;
    }
    wx.makePhoneCall({ phoneNumber: phone });
  },
  
  /**
   * 检查当前用户与任务的关系
   */
  checkUserTaskRelation(taskId) {
    if (!taskId) return;
    
    get(`/tasks/${taskId}/user-relation`)
      .then(res => {
        if (res && res.success && res.data) {
          // 假设后端返回的数据中包含isClaimed字段表示当前用户是否已接取
          this.setData({
            isClaimedByCurrentUser: res.data.isClaimed || false
          });
        }
      })
      .catch(error => {
        console.error('检查用户任务关系失败:', error);
        // 出错时默认设置为未接取
        this.setData({
          isClaimedByCurrentUser: false
        });
      });
  },

  openTaskTracking(e) {
    const { orderId } = e.currentTarget.dataset || {};
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: `/pages/volunteer/vol_task_detail?orderId=${orderId}`
    });
  },

  formatTaskTime(start, end) {
    if (!start || !end) return '';
    const startDate = new Date(start);
    const endDate = new Date(end);
    const format = (date) => {
      const y = date.getFullYear();
      const m = (date.getMonth() + 1).toString().padStart(2, '0');
      const d = date.getDate().toString().padStart(2, '0');
      const h = date.getHours().toString().padStart(2, '0');
      const min = date.getMinutes().toString().padStart(2, '0');
      return `${y}-${m}-${d} ${h}:${min}`;
    };
    return `${format(startDate)} 至 ${format(endDate)}`;
  },

  mapStatus(status) {
    switch (status) {
      case 1:
        return '招募中';
      case 2:
        return '进行中';
      case 3:
        return '已完成';
      case 4:
        return '已取消';
      default:
        return '未知状态';
    }
  },

  formatDateTime(value) {
    if (!value) return '--';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    const h = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    const sec = String(date.getSeconds()).padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}:${sec}`;
  },

  formatMoney(value) {
    const num = Number(value);
    if (Number.isNaN(num)) {
      return '0.00';
    }
    return num.toFixed(2);
  },

  mapOrderStatus(status) {
        
    // 处理null、undefined和空字符串
    if (status === null || status === undefined || status === '') {
      console.log('处理特殊状态值:', status);
      return '未知状态';
    }
    
    // 确保status是字符串类型，并转换为小写
    const statusStr = String(status).toLowerCase();
    console.log('转换后的状态字符串:', statusStr);
    
    switch (statusStr) {
      case 'pending':
        return '待付款';
      case 'paid':
        return '已支付';
      case 'waiting_volunteer':
        return '待志愿者接单';
      case 'volunteer_accepted':
        return '志愿者已接单';
      case 'completed':
        console.log('匹配到completed状态');
        return '已完成';
      case 'arrived_restaurant':
        return '已到达餐厅';
      case 'shipped':
        return '配送中';
      case 'delivered':
        return '已送达';
      case 'cancelled':
        return '已取消';
      case 'refunded':
        return '已退款';
      default:
        console.log('未匹配到的状态，返回原始值:', statusStr);
        return `状态: ${String(status)}`;
    }
  },

  /**
   * 领取订单
   */
  claimOrder(e) {
    const { orderId } = e.currentTarget.dataset || {};
    if (!orderId) {
      wx.showToast({ title: '参数缺失', icon: 'none' });
      return;
    }

    wx.showModal({
      title: '确认领取',
      content: '确定要领取这个订单吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' });
          post(`/order/${orderId}/accept`)
            .then(res => {
              if (res && res.success) {
                wx.showToast({ title: '领取成功', icon: 'success' });
                // 刷新订单列表
                this.loadTaskOrders(this.data.taskId);
              } else {
                wx.showToast({ title: res?.message || '领取失败', icon: 'none' });
              }
            })
            .catch(error => {
              console.error('领取订单失败:', error);
              wx.showToast({ title: error?.message || '领取失败', icon: 'none' });
            })
            .finally(() => {
              wx.hideLoading();
            });
        }
      }
    });
  }
})