const { get } = require('../../utils/request');
const { authAPI } = require('../../utils/api');
const { getFullImageUrl } = require('../../utils/imageUtils');

Page({
  data: {
    volunteerInfo: {
      real_name: '',
      genderText: '',
      age: '',
      emergency_contact: '',
      address: '',
      service_hours: 0,
      created_at: '',
      statusText: '',
      phone: '',
      avatar_url: '',
      nickname: '',
      formattedId: ''
    },
    volunteerTasks: []
  },

  onLoad() {
    this.loadVolunteerInfo();
    this.loadVolunteerTasks();
  },

  onShow() {
    this.loadVolunteerInfo();
    this.loadVolunteerTasks();
  },

  loadVolunteerInfo() {
    let userId = wx.getStorageSync('user_id');
    const storedUser = wx.getStorageSync('userInfo');
    if (!userId && storedUser && storedUser.id) {
      userId = storedUser.id;
      wx.setStorageSync('user_id', userId);
    }

    if (!userId) {
      authAPI.getProfile()
        .then(res => {
          if (res && res.success && res.data && res.data.id) {
            wx.setStorageSync('user_id', res.data.id);
            this.fetchVolunteerInfo(res.data.id);
          } else {
            wx.showToast({ title: '请先登录', icon: 'none' });
          }
        })
        .catch(() => {
          wx.showToast({ title: '请先登录', icon: 'none' });
        });
      return;
    }

    this.fetchVolunteerInfo(userId);
  },

  fetchVolunteerInfo(userId) {
    get('/volunteer/profile', { user_id: userId }, { showLoading: true })
      .then(res => {
        if (res && res.success && res.data) {
          const info = res.data;
          const formattedId = info.volunteer_id ? `VOL${String(info.volunteer_id).padStart(6, '0')}` : '';
          
          // 处理头像URL：使用getFullImageUrl确保路径正确
          let avatarUrl = info.avatar_url || '';
          if (avatarUrl) {
            avatarUrl = getFullImageUrl(avatarUrl);
            console.log('头像原始路径:', info.avatar_url);
            console.log('头像完整路径:', avatarUrl);
          }
          
          // 获取服务时长（从统计接口获取）
          this.fetchServiceHours(userId, (serviceHours) => {
            this.setData({
              volunteerInfo: {
                real_name: info.real_name || '',
                genderText: this.mapGender(info.gender),
                age: info.age || '',
                emergency_contact: info.emergency_contact || '',
                address: info.address || '',
                service_hours: serviceHours,
                created_at: info.created_at ? this.formatDate(info.created_at) : '',
                statusText: this.mapStatus(info.status),
                phone: info.phone || '',
                avatar_url: avatarUrl,
                nickname: info.nickname || '',
                formattedId
              }
            });
          });
        } else {
          wx.showToast({ title: res?.message || '获取资料失败', icon: 'none' });
        }
      })
      .catch(error => {
        console.error('获取志愿者资料失败:', error);
        wx.showToast({ title: error?.message || '获取资料失败', icon: 'none' });
      });
  },

  /**
   * 获取服务时长（从统计接口获取）
   */
  fetchServiceHours(userId, callback) {
    get('/tasks/volunteer/stats', {}, { showLoading: false })
      .then(res => {
        console.log('统计接口返回数据:', res);
        if (res && res.success && res.data) {
          const totalHours = Number(res.data.total_hours || 0);
          console.log('从统计接口获取的服务时长 (total_hours):', totalHours);
          callback(totalHours);
        } else {
          console.warn('获取服务时长失败，返回数据:', res);
          callback(0);
        }
      })
      .catch(error => {
        console.error('获取服务时长失败:', error);
        callback(0);
      });
  },

  loadVolunteerTasks() {
    get('/tasks/volunteer/list', {}, { showLoading: false })
      .then(res => {
        if (res && res.success && Array.isArray(res.data)) {
          const tasks = res.data.map(item => {
            // 使用任务状态（task_status）而不是志愿者任务关系状态（volunteer_status）
            // 因为任务状态才是真实的：1=招募中，2=进行中，3=已完成，4=已取消
            const taskStatus = item.task_status || item.volunteer_status;
            console.log('任务状态数据:', {
              task_id: item.task_id,
              task_status: item.task_status,
              volunteer_status: item.volunteer_status,
              mapped_status: this.mapTaskStatus(taskStatus)
            });
            
            return {
              relation_id: item.relation_id,
              task_id: item.task_id,
              title: item.task_title,
              statusText: this.mapTaskStatus(taskStatus), // 使用任务状态
              taskStatus: taskStatus, // 保存原始状态值
              timeRange: this.formatTaskTime(item.start_time, item.end_time),
              address: item.address,
              merchant: item.merchant_name || '平台任务',
              accept_time: item.accept_time ? this.formatDate(item.accept_time) : '',
              content: item.task_content || '',
              type: item.task_type || ''
            };
          });
          this.setData({ volunteerTasks: tasks });
        }
      })
      .catch(error => {
        console.error('获取志愿者任务列表失败:', error);
      });
  },

  mapGender(gender) {
    switch (Number(gender)) {
      case 1:
        return '男';
      case 2:
        return '女';
      default:
        return '未填写';
    }
  },

  mapStatus(status) {
    switch (Number(status)) {
      case 1:
        return '已认证';
      case 2:
        return '审核中';
      case 3:
        return '认证失败';
      default:
        return '未认证';
    }
  },

  formatDate(dateStr) {
    const date = new Date(dateStr);
    if (Number.isNaN(date.getTime())) return dateStr;
    const y = date.getFullYear();
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const d = date.getDate().toString().padStart(2, '0');
    const h = date.getHours().toString().padStart(2, '0');
    const min = date.getMinutes().toString().padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}`;
  },

  formatTaskTime(start, end) {
    if (!start || !end) return '';
    return `${this.formatDate(start)} 至 ${this.formatDate(end)}`;
  },

  mapTaskStatus(status) {
    // 任务状态映射：1=招募中，2=进行中，3=已完成，4=已取消
    switch (Number(status)) {
      case 1:
        return '招募中';
      case 2:
        return '进行中';
      case 3:
        return '已完成';
      case 4:
        return '已取消';
      default:
        return '未知状态';
    }
  }
});

