import { get } from '../../utils/request';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    notices: [],
    loading: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.loadNotices();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.loadNotices();
  },

  /**
   * 加载通知数据
   */
  loadNotices() {
    if (this.data.loading) return;
    this.setData({ loading: true });
    
    get('/volunteer/notifications', { limit: 50 }, { showLoading: false })
      .then(res => {
        const list = res?.data?.notifications || [];
        const notices = list.map(item => ({
          id: item.id,
          title: item.title,
          content: item.content,
          summary: this.generateSummary(item.content),
          time: this.formatTime(item.created_at),
          merchant_name: item.merchant_name || '系统消息',
          isNew: this.isNewNotice(item.created_at)
        }));
        this.setData({ notices });
      })
      .catch(error => {
        console.error('加载通知失败:', error);
        wx.showToast({
          title: error?.message || '加载通知失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ loading: false });
      });
  },

  /**
   * 查看通知详情
   */
  viewNoticeDetail(e) {
    const noticeId = e.currentTarget.dataset.id;
    const notice = this.data.notices.find(n => n.id === noticeId);
    
    if (!notice) {
      wx.showToast({
        title: '通知不存在或已被删除',
        icon: 'none'
      });
      return;
    }
    
    wx.showModal({
      title: notice.title,
      content: notice.content,
      showCancel: false,
      success: () => {
        // 标记为已读
        if (notice.isNew) {
          const notices = this.data.notices;
          const index = notices.findIndex(n => n.id === noticeId);
          if (index !== -1) {
            notices[index].isNew = false;
            this.setData({
              notices: notices
            });
          }
        }
      }
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.loadNotices();
    wx.stopPullDownRefresh();
  },

  formatTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const y = d.getFullYear();
    const m = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    const hh = d.getHours().toString().padStart(2, '0');
    const mm = d.getMinutes().toString().padStart(2, '0');
    const ss = d.getSeconds().toString().padStart(2, '0');
    return `${y}-${m}-${day} ${hh}:${mm}:${ss}`;
  },

  generateSummary(content = '') {
    const clean = content.replace(/\s+/g, ' ');
    return clean.length > 30 ? `${clean.slice(0, 30)}...` : clean;
  },

  isNewNotice(dateStr) {
    if (!dateStr) return false;
    const created = new Date(dateStr).getTime();
    const now = Date.now();
    const diff = now - created;
    const threeDays = 3 * 24 * 60 * 60 * 1000;
    return diff <= threeDays;
  },

  /**
   * 判断通知是否在24小时内发布
   */
  isRecent(dateStr) {
    if (!dateStr) return false;
    const created = new Date(dateStr).getTime();
    const now = Date.now();
    const diff = now - created;
    const oneDay = 24 * 60 * 60 * 1000; // 24小时
    return diff <= oneDay;
  }
})