const { get, patch } = require('../../utils/request');
const { getUserInfo } = require('../../stores/userStores');

Page({
  data: {
    activeTab: 'merchants',
    merchants: [],
    page: 1,
    limit: 20,
    totalPages: 1,
    loading: false
  },

  onLoad() {
    const userInfo = getUserInfo();
    if (!userInfo || userInfo.role_id !== 5) {
      wx.showModal({
        title: '无权限',
        content: '仅管理员可以访问该页面',
        showCancel: false,
        success: () => {
          wx.navigateBack();
        }
      });
      return;
    }

    this.loadMerchants(true);
  },

  // 管理员局部导航跳转
  goToUsers() {
    wx.redirectTo({
      url: '/pages/Admin/admin_user_list'
    });
  },

  goToMerchants() {
    // 当前页，无需跳转
  },

  goToNotifications() {
    wx.redirectTo({
      url: '/pages/Admin/admin_notifications'
    });
  },

  onPullDownRefresh() {
    this.loadMerchants(true);
    wx.stopPullDownRefresh();
  },

  onReachBottom() {
    if (this.data.page < this.data.totalPages) {
      this.loadMerchants(false);
    }
  },

  loadMerchants(reset = false) {
    if (this.data.loading) return;

    const nextPage = reset ? 1 : this.data.page + 1;
    this.setData({ loading: true });

    get('/admin/merchants', { page: nextPage, limit: this.data.limit }, { showLoading: false })
      .then(res => {
        const data = res.data || {};
        const list = data.merchants || data.merchant || [];
        const totalPages = (data.pagination && data.pagination.totalPages) || data.totalPages || 1;

        this.setData({
          merchants: reset ? list : this.data.merchants.concat(list),
          page: nextPage,
          totalPages
        });
      })
      .catch(err => {
        console.error('加载商家列表失败:', err);
        wx.showToast({
          title: err.message || '加载商家列表失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ loading: false });
      });
  },

  onSetOpen(e) {
    this.changeMerchantStatus(e.currentTarget.dataset.id, 1);
  },

  onSetClose(e) {
    this.changeMerchantStatus(e.currentTarget.dataset.id, 0);
  },

  changeMerchantStatus(merchantId, isOpen) {
    if (!merchantId) return;

    const text = isOpen ? '设为营业' : '设为打烊';
    wx.showModal({
      title: '确认操作',
      content: `确定要${text}吗？`,
      success: (res) => {
        if (!res.confirm) return;

        patch(`/admin/merchants/${merchantId}/status`, { is_open: isOpen }, { showLoading: true })
          .then(() => {
            wx.showToast({
              title: '操作成功',
              icon: 'success'
            });
            this.loadMerchants(true);
          })
          .catch(err => {
            console.error('更新商家状态失败:', err);
            wx.showToast({
              title: err.message || '更新商家状态失败',
              icon: 'none'
            });
          });
      }
    });
  }
});


