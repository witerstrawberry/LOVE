const { get, post, delete: del } = require('../../utils/request');
const { getUserInfo } = require('../../stores/userStores');

Page({
  data: {
    activeTab: 'notifications',
    title: '',
    content: '',
    notices: [],
    loading: false,
    submitting: false
  },

  onLoad() {
    const userInfo = getUserInfo();
    if (!userInfo || userInfo.role_id !== 5) {
      wx.showModal({
        title: '无权限',
        content: '仅管理员可以访问该页面',
        showCancel: false,
        success: () => {
          wx.navigateBack();
        }
      });
      return;
    }

    this.loadNotices();
  },

  // 管理员局部导航跳转
  goToUsers() {
    wx.redirectTo({
      url: '/pages/Admin/admin_user_list'
    });
  },

  goToMerchants() {
    wx.redirectTo({
      url: '/pages/Admin/admin_merchant_list'
    });
  },

  goToNotifications() {
    // 当前页，无需跳转
  },

  onPullDownRefresh() {
    this.loadNotices();
    wx.stopPullDownRefresh();
  },

  onTitleInput(e) {
    this.setData({ title: e.detail.value || '' });
  },

  onContentInput(e) {
    this.setData({ content: e.detail.value || '' });
  },

  formatTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const y = d.getFullYear();
    const m = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    const hh = d.getHours().toString().padStart(2, '0');
    const mm = d.getMinutes().toString().padStart(2, '0');
    return `${y}-${m}-${day} ${hh}:${mm}`;
  },

  loadNotices() {
    if (this.data.loading) return;
    this.setData({ loading: true });

    // 使用志愿者通知接口获取系统消息列表（后端已将系统消息标记为merchant_name=系统消息）
    get('/volunteer/notifications', { limit: 50 }, { showLoading: false })
      .then(res => {
        const list = (res && res.data && res.data.notifications) || [];
        const systemNotices = list
          .filter(item => item.type === 'system')
          .map(item => ({
            id: item.id,
            title: item.title,
            content: item.content,
            time: this.formatTime(item.created_at)
          }));

        this.setData({ notices: systemNotices });
      })
      .catch(err => {
        console.error('加载系统消息失败:', err);
        wx.showToast({
          title: err.message || '加载系统消息失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ loading: false });
      });
  },

  onSubmit() {
    if (!this.data.title.trim()) {
      wx.showToast({
        title: '请填写标题',
        icon: 'none'
      });
      return;
    }
    if (!this.data.content.trim()) {
      wx.showToast({
        title: '请填写内容',
        icon: 'none'
      });
      return;
    }

    if (this.data.submitting) return;

    this.setData({ submitting: true });

    post('/admin/notifications/system', {
      title: this.data.title.trim(),
      content: this.data.content.trim()
    }, { showLoading: true })
      .then(() => {
        wx.showToast({
          title: '发布成功',
          icon: 'success'
        });
        this.setData({
          title: '',
          content: ''
        });
        this.loadNotices();
      })
      .catch(err => {
        console.error('发布系统消息失败:', err);
        wx.showToast({
          title: err.message || '发布失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ submitting: false });
      });
  },

  /**
   * 删除系统通知
   */
  onDeleteNotice(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;

    wx.showModal({
      title: '确认删除',
      content: '删除后该系统消息将不再展示，确定要删除吗？',
      confirmText: '删除',
      confirmColor: '#e64340',
      success: (res) => {
        if (!res.confirm) return;

        wx.showLoading({ title: '删除中...', mask: true });

        del('/admin/notifications/system/' + id, {}, { showLoading: false })
          .then(() => {
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
            // 从前端列表中移除
            const notices = this.data.notices.filter(item => item.id !== id);
            this.setData({ notices });
          })
          .catch(err => {
            console.error('删除系统通知失败:', err);
            wx.showToast({
              title: err.message || '删除失败',
              icon: 'none'
            });
          })
          .finally(() => {
            wx.hideLoading();
          });
      }
    });
  }
});


