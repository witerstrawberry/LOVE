const { get, patch } = require('../../utils/request');
const { getUserInfo } = require('../../stores/userStores');

Page({
  data: {
    activeTab: 'users', // 当前激活的管理页
    users: [],
    page: 1,
    limit: 20,
    totalPages: 1,
    loading: false,
    keyword: '',
    statusOptions: [
      { value: '', label: '全部状态' },
      { value: 'active', label: '启用' },
      { value: 'inactive', label: '停用' },
      { value: 'banned', label: '封禁' }
    ],
    currentStatus: '',
    currentStatusLabel: '全部状态'
  },

  onLoad() {
    // 简单校验：仅允许管理员访问（role_id === 5）
    const userInfo = getUserInfo();
    if (!userInfo || userInfo.role_id !== 5) {
      wx.showModal({
        title: '无权限',
        content: '仅管理员可以访问该页面',
        showCancel: false,
        success: () => {
          wx.navigateBack();
        }
      });
      return;
    }

    this.loadUsers(true);
  },

  // 管理员局部导航跳转
  goToUsers() {
    // 当前页，无需跳转
  },

  goToMerchants() {
    wx.redirectTo({
      url: '/pages/Admin/admin_merchant_list'
    });
  },

  goToNotifications() {
    wx.redirectTo({
      url: '/pages/Admin/admin_notifications'
    });
  },

  onPullDownRefresh() {
    this.loadUsers(true);
    wx.stopPullDownRefresh();
  },

  onReachBottom() {
    if (this.data.page < this.data.totalPages) {
      this.loadUsers(false);
    }
  },

  onSearchInput(e) {
    this.setData({
      keyword: e.detail.value || ''
    });
    // 简单防抖可以按需补充，这里直接刷新
    this.loadUsers(true);
  },

  onStatusChange(e) {
    const index = parseInt(e.detail.value, 10);
    const selected = this.data.statusOptions[index];
    this.setData({
      currentStatus: selected.value,
      currentStatusLabel: selected.label
    });
    this.loadUsers(true);
  },

  formatStatus(status) {
    if (status === 'active') return '启用';
    if (status === 'inactive') return '停用';
    if (status === 'banned') return '封禁';
    return status || '未知';
  },

  loadUsers(reset = false) {
    if (this.data.loading) return;

    const nextPage = reset ? 1 : this.data.page + 1;

    this.setData({ loading: true });

    const params = {
      page: nextPage,
      limit: this.data.limit
    };

    if (this.data.currentStatus) {
      params.status = this.data.currentStatus;
    }
    if (this.data.keyword) {
      // 关键字同时匹配手机号和昵称
      params.phone = this.data.keyword;
      params.nickname = this.data.keyword;
    }

    get('/admin/users', params, { showLoading: false })
      .then(res => {
        const data = res.data || {};
        const list = data.users || [];
        const totalPages = data.totalPages || 1;

        // 为每个用户计算一个可读的状态文本，方便在 WXML 中直接显示
        const mappedList = list.map(user => ({
          ...user,
          statusText: this.formatStatus(user.status)
        }));

        this.setData({
          users: reset ? mappedList : this.data.users.concat(mappedList),
          page: nextPage,
          totalPages
        });
      })
      .catch(err => {
        console.error('加载用户列表失败:', err);
        wx.showToast({
          title: err.message || '加载用户列表失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ loading: false });
      });
  },

  onSetActive(e) {
    this.changeUserStatus(e.currentTarget.dataset.id, 'active');
  },

  onSetInactive(e) {
    this.changeUserStatus(e.currentTarget.dataset.id, 'inactive');
  },

  onSetBanned(e) {
    this.changeUserStatus(e.currentTarget.dataset.id, 'banned');
  },

  changeUserStatus(userId, status) {
    if (!userId) return;

    const statusText = this.formatStatus(status);
    wx.showModal({
      title: '确认操作',
      content: `确定将该用户设置为「${statusText}」状态吗？`,
      success: (res) => {
        if (!res.confirm) return;

        patch(`/admin/users/${userId}/status`, { status }, { showLoading: true })
          .then(() => {
            wx.showToast({
              title: '操作成功',
              icon: 'success'
            });
            this.loadUsers(true);
          })
          .catch(err => {
            console.error('更新用户状态失败:', err);
            wx.showToast({
              title: err.message || '更新用户状态失败',
              icon: 'none'
            });
          });
      }
    });
  }
});


