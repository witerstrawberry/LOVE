// 帮助中心页面逻辑
Page({
  data: {
    searchKeyword: '', // 搜索关键词
    showHistory: true, // 是否显示搜索历史
    searchHistory: [], // 搜索历史记录
    selectedCategory: 'all', // 当前选中的分类
    expandedFaqs: {}, // 展开的FAQ ID集合
    loading: true, // 加载状态
    error: '', // 错误信息
    faqs: [], // 所有FAQ数据
    filteredFaqs: [] // 筛选后的FAQ数据
  },

  onLoad: function (options) {
    // 初始化页面数据
    this.initData();
    // 加载搜索历史
    this.loadSearchHistory();
  },

  // 初始化FAQ数据
  initData: function () {
    try {
      // 模拟FAQ数据
      const faqs = [
        {
          id: 1,
          category: 'account',
          question: '如何注册账号？',
          answer: '您可以通过手机号注册账号，点击注册按钮，输入手机号和验证码，设置密码即可完成注册。注册成功后，您可以选择角色并完善个人信息。'
        },
        {
          id: 2,
          category: 'account',
          question: '忘记密码怎么办？',
          answer: '在登录页面点击"忘记密码"，输入注册手机号，获取验证码，然后设置新密码即可。'
        },
        {
          id: 3,
          category: 'function',
          question: '如何下单？',
          answer: '在首页选择商品，加入购物车，然后点击购物车图标，确认订单信息，选择支付方式，完成支付即可下单。'
        },
        {
          id: 4,
          category: 'function',
          question: '如何查看订单状态？',
          answer: '在"我的"页面，点击"我的订单"，即可查看所有订单的状态，包括待支付、待配送、已完成等。'
        },
        {
          id: 5,
          category: 'payment',
          question: '支持哪些支付方式？',
          answer: '目前支持微信支付和余额支付两种方式。您可以在支付页面选择合适的支付方式。'
        },
        {
          id: 6,
          category: 'payment',
          question: '支付失败怎么办？',
          answer: '如果支付失败，您可以检查网络连接，确认支付账户余额是否充足，或者尝试更换支付方式。如果问题仍然存在，请联系客服。'
        },
        {
          id: 7,
          category: 'aftersale',
          question: '如何申请退款？',
          answer: '在"我的订单"页面，找到需要退款的订单，点击"申请退款"，填写退款原因，提交申请即可。商家会在24小时内处理您的退款申请。'
        },
        {
          id: 8,
          category: 'aftersale',
          question: '商品质量问题怎么办？',
          answer: '如果您收到的商品存在质量问题，请在24小时内联系客服，并提供相关照片和订单信息，我们会尽快为您处理。'
        },
        {
          id: 9,
          category: 'other',
          question: '如何联系客服？',
          answer: '您可以在帮助中心页面点击"联系在线客服"，或者在"我的"页面点击"客服中心"，即可与客服人员在线沟通。'
        },
        {
          id: 10,
          category: 'other',
          question: '如何修改个人信息？',
          answer: '在"我的"页面，点击头像或用户名，进入个人信息页面，即可修改昵称、头像、手机号等个人信息。'
        }
      ];

      this.setData({
        faqs: faqs,
        filteredFaqs: faqs,
        loading: false
      });
    } catch (err) {
      this.setData({
        loading: false,
        error: '加载失败，请刷新重试'
      });
      console.error('初始化FAQ数据失败:', err);
    }
  },

  // 搜索输入处理
  onSearchInput: function (e) {
    const keyword = e.detail.value;
    this.setData({
      searchKeyword: keyword
    });
    this.filterFaqs();
  },

  // 清空搜索
  clearSearch: function () {
    this.setData({
      searchKeyword: '',
      showHistory: true
    });
    this.filterFaqs();
  },

  // 筛选FAQ
  filterFaqs: function () {
    const { faqs, searchKeyword, selectedCategory } = this.data;
    let filtered = [...faqs];

    // 按分类筛选
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // 按关键词搜索
    if (searchKeyword) {
      const keyword = searchKeyword.toLowerCase();
      filtered = filtered.filter(item => 
        item.question.toLowerCase().includes(keyword) || 
        item.answer.toLowerCase().includes(keyword)
      );
      // 隐藏搜索历史
      this.setData({ showHistory: false });
      // 保存搜索历史
      this.saveSearchHistory(searchKeyword);
    } else {
      // 显示搜索历史
      this.setData({ showHistory: true });
    }

    this.setData({ filteredFaqs: filtered });
  },

  // 选择分类
  selectCategory: function (e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      selectedCategory: category
    });
    this.filterFaqs();
  },

  // 切换FAQ展开/收起状态
  toggleFaq: function (e) {
    const id = e.currentTarget.dataset.id;
    const { expandedFaqs } = this.data;
    const newExpanded = { ...expandedFaqs };
    
    // 切换状态
    if (newExpanded[id]) {
      delete newExpanded[id];
    } else {
      newExpanded[id] = true;
    }
    
    this.setData({ expandedFaqs: newExpanded });
  },

  // 联系客服
  contactCustomerService: function () {
    // 跳转到小程序内置客服会话页面
    console.log('联系客服');
  },

  // 刷新页面
  refresh: function () {
    this.setData({
      loading: true,
      error: ''
    });
    this.initData();
  },

  // 保存搜索历史
  saveSearchHistory: function (keyword) {
    if (!keyword || keyword.trim() === '') return;
    
    let history = [...this.data.searchHistory];
    
    // 移除重复项
    history = history.filter(item => item !== keyword);
    
    // 添加到历史记录开头
    history.unshift(keyword);
    
    // 限制最多10条历史记录
    if (history.length > 10) {
      history = history.slice(0, 10);
    }
    
    this.setData({ searchHistory: history });
    wx.setStorageSync('helpCenterSearchHistory', history);
  },

  // 加载搜索历史
  loadSearchHistory: function () {
    const history = wx.getStorageSync('helpCenterSearchHistory') || [];
    this.setData({ searchHistory: history });
  },

  // 清空搜索历史
  clearHistory: function () {
    this.setData({ searchHistory: [] });
    wx.removeStorageSync('helpCenterSearchHistory');
  },

  // 选择历史记录
  selectHistory: function (e) {
    const keyword = e.currentTarget.dataset.keyword;
    this.setData({
      searchKeyword: keyword,
      showHistory: false
    });
    this.filterFaqs();
  }
});