// pages/old-detail/order-detail.js   订单明细页面
const { orderAPI } = require('../../utils/api');
const { getFullImageUrl } = require('../../utils/imageUtils');
const { getResourceUrl } = require('../../utils/config');
const { formatAddressOnly, extractContactInfo } = require('../../utils/addressUtils');

Page({
  data: {
    orderInfo: null,
    deliveryStatus: '等待商家接单',
    deliveryDistance: '',
    deliveryTime: '',
    estimatedArrivalTime: '',
    orderTime: '',
    // 操作按钮图片路径
    actionImages: {
      refund: getResourceUrl('/uploads/part/申请退款.png'),
      contactVolunteer: getResourceUrl('/uploads/part/联系骑手.png'),
      contactShop: getResourceUrl('/uploads/part/联系商家.png')
    },
    volunteerInfo: {
      name: '',
      phone: '',
      avatar: '/images/rider-avatar.png',
      longitude: null,
      latitude: null
    },
    shopInfo: {
      name: '',
      phone: '',
      logo: '',
      address: '',
      longitude: null,
      latitude: null
    },
    // 地图相关数据
    longitude: null,
    latitude: null,
    markers: [],
    polyline: [],
    // 身份信息
    roleId: null,
    userId: null,
    orderNo: '',
    // 订单状态文本
    statusText: '',
    // 用户位置
    userLatitude: null,
    userLongitude: null,
    // 预计送达时间计算相关
    estimateTimer: null, // 定时器
    volunteerSpeed: 10, // 志愿者速度 10km/h
    waitTime: 5, // 商家出餐等待时间（分钟）
    volunteerAcceptTime: null, // 志愿者接单时间
    merchantToCustomerDistance: null, // 商家到顾客距离（km）
    lastVolunteerLat: null, // 志愿者上次位置纬度
    lastVolunteerLng: null // 志愿者上次位置经度
  },

  onLoad: function(options) {
    console.log('页面加载，传入的options参数:', options);
    
    // 获取身份信息
    const roleId = options.roleId || null;
    const userId = options.userId || null;
    const orderNo = options.orderNo || '';
    
    this.setData({
      roleId: roleId,
      userId: userId,
      orderNo: orderNo
    });
    
    // 从本地存储获取订单信息作为后备
    const orderInfo = wx.getStorageSync('lastOrder');
    console.log('本地存储的订单信息:', orderInfo);
    
    // 优先从options中获取订单ID（这是关键）
    let orderId = options.id || options.orderId || options.order_id;
    console.log('从options获取的orderId:', orderId);
    
    // 如果options中没有，尝试从本地存储中获取
    if (!orderId && orderInfo) {
      orderId = orderInfo.id || orderInfo.orderId || orderInfo.order_id;
      console.log('从本地存储获取的orderId:', orderId);
    }
    
    // 初始化订单信息对象
    let currentOrderInfo = orderInfo || {};
    
    // 计算商品金额（降级处理）
    if (currentOrderInfo.totalPrice) {
      currentOrderInfo.productAmount = (currentOrderInfo.totalPrice - 1.54).toFixed(2);
    } else {
      currentOrderInfo.productAmount = '0.00';
      currentOrderInfo.totalPrice = '0.00';
    }
    
    console.log('计算后的productAmount:', currentOrderInfo.productAmount);
    
    this.setData({ orderInfo: currentOrderInfo });
    
    // 无论本地存储是否有订单信息，只要有orderId就调用fetchOrderDetail
    if (orderId) {
      console.log('将使用orderId从后端获取订单详情:', orderId);
      this.fetchOrderDetail(orderId);
    } else {
      console.warn('未找到订单ID，无法从后端获取订单详情');
    }
  },
  
  /**
   * 从后端获取订单详情
   */
  fetchOrderDetail: function(orderId) {
    console.log('开始获取订单详情，订单ID:', orderId);
    
    // 使用orderAPI获取订单详情
    orderAPI.getOrderDetail(orderId)
      .then(res => {
        console.log('获取订单详情成功，结果:', res);
        
        // 检查响应是否有效
        // API返回格式: {success: true, code: 200, message: "...", data: order, timestamp: "..."}
        // 所以订单详情在 res.data 中
        if (!res || !res.success || !res.data) {
          console.error('订单详情数据格式错误:', res);
          wx.showToast({ title: '获取订单信息失败', icon: 'none' });
          return;
        }
        
        const orderDetail = res.data;
        console.log('处理前的orderDetail:', orderDetail);
        console.log('商家logo原始数据:', orderDetail.merchant_logo);
        
        // 确保orderDetail是一个对象
        if (typeof orderDetail !== 'object' || orderDetail === null) {
          console.error('订单详情数据不是有效的对象:', orderDetail);
          return;
        }
        
        // 处理total_amount，确保是数字类型并设置默认值
        let totalAmount = 0;
        if (orderDetail.total_amount !== undefined && orderDetail.total_amount !== null) {
          totalAmount = parseFloat(orderDetail.total_amount) || 0;
        }
        
        // 处理配送费
        const deliveryFee = parseFloat(orderDetail.delivery_fee || 0);
        
        // 计算商品金额（总金额减去配送费）
        let productAmount = '0.00';
        if (totalAmount > 0) {
          productAmount = (totalAmount - deliveryFee).toFixed(2);
          // 确保不会出现负数
          if (parseFloat(productAmount) < 0) {
            productAmount = '0.00';
          }
        }
        
        // 格式化金额显示
        const formattedAmount = productAmount;
        const formattedTotalAmount = totalAmount.toFixed(2);
        
        // 处理商品列表，添加图片URL
        const items = (orderDetail.items || []).map(item => ({
          ...item,
          image: item.product_image ? getFullImageUrl(item.product_image) : '/images/default-avatar.png',
          name: item.product_name,
          price: parseFloat(item.price || 0).toFixed(2),
          quantity: item.quantity || 0,
          options: item.category_name || ''
        }));
        
        // 处理商家信息
        let merchantLogoUrl = '';
        if (orderDetail.merchant_logo) {
          // 确保只使用后端返回的数据，不使用静态数据
          const logoPath = orderDetail.merchant_logo;
          
          // 如果已经是完整URL，直接使用
          if (logoPath.startsWith('http://') || logoPath.startsWith('https://')) {
            merchantLogoUrl = logoPath;
          } 
          // 如果以/uploads开头，直接拼接baseUrl
          else if (logoPath.startsWith('/uploads')) {
            const app = getApp();
            const baseUrl = app.globalData.baseUrl.replace('/api', '');
            merchantLogoUrl = baseUrl + logoPath;
          }
          // 其他情况使用getFullImageUrl处理
          else {
            merchantLogoUrl = getFullImageUrl(logoPath);
          }
          
          console.log('商家logo处理结果:', {
            原始值: orderDetail.merchant_logo,
            处理后URL: merchantLogoUrl
          });
        } else {
          console.log('商家logo为空，不显示logo');
        }
        
        const shopInfo = {
          name: orderDetail.merchant_name || '商家',
          phone: orderDetail.merchant_phone || '',
          logo: merchantLogoUrl, // 只使用后端数据，如果为空则不显示
          address: orderDetail.merchant_address || '',
          longitude: orderDetail.merchant_longitude ? parseFloat(orderDetail.merchant_longitude) : null,
          latitude: orderDetail.merchant_latitude ? parseFloat(orderDetail.merchant_latitude) : null
        };
        
        console.log('最终shopInfo:', shopInfo);
        
        // 处理志愿者信息
        const volunteerInfo = {
          name: orderDetail.volunteer?.volunteer_name || orderDetail.volunteer?.volunteer_nickname || '',
          phone: orderDetail.volunteer?.volunteer_phone || '',
          avatar: orderDetail.volunteer?.volunteer_avatar ? getFullImageUrl(orderDetail.volunteer.volunteer_avatar) : '/images/rider-avatar.png',
          longitude: null, // 志愿者位置需要实时获取，这里先设为null
          latitude: null
        };
        
        // 保存志愿者接单时间
        const volunteerAcceptTime = orderDetail.volunteer_accept_time || null;
        
        // 计算商家到顾客的距离（如果有地址信息）
        let merchantToCustomerDistance = null;
        if (orderDetail.order_type === 'takeaway' && 
            shopInfo.latitude && shopInfo.longitude && 
            orderDetail.delivery_address) {
          // 这里先设为null，后续通过地图API计算
          // 或者从后端返回的距离信息中获取
          merchantToCustomerDistance = null;
        }
        
        // 获取订单状态文本
        const statusText = this.getStatusText(orderDetail.status);
        
        // 判断是否应该显示地图（在指定状态且为外送订单）
        const shouldShowMap = orderDetail.order_type === 'takeaway' && 
                             ['customer_accepted', 'merchant_accepted', 'waiting_volunteer', 
                              'volunteer_accepted', 'arrived_restaurant', 'shipped', 'delivered'].includes(orderDetail.status);
        
        // 格式化配送地址（仅地址，不含联系人信息）
        const formattedDeliveryAddress = formatAddressOnly(orderDetail.delivery_address || '');
        const contactInfo = extractContactInfo(orderDetail.delivery_address || '');
        
        // 更新订单信息对象
        const updatedOrderInfo = {
          ...orderDetail,
          items: items,
          productAmount: formattedAmount,
          formattedTotalAmount: formattedTotalAmount,
          totalPrice: formattedTotalAmount,
          deliveryFee: deliveryFee.toFixed(2),
          order_type: orderDetail.order_type || 'takeaway',
          // 格式化后的配送地址（仅地址部分）
          delivery_address: formattedDeliveryAddress,
          // 提取的联系人信息（如果地址是JSON格式，优先使用提取的信息）
          recipient_name: contactInfo.name || orderDetail.recipient_name || '收货人',
          recipient_phone: contactInfo.phone || orderDetail.recipient_phone || '',
          // 下单人信息
          user_nickname: orderDetail.user_nickname || orderDetail.user_name || ''
        };
        
        // 更新页面数据
        this.setData({
          orderInfo: updatedOrderInfo,
          shopInfo: shopInfo,
          volunteerInfo: volunteerInfo,
          statusText: statusText,
          orderTime: orderDetail.created_at ? this.formatTime(orderDetail.created_at) : '',
          shouldShowMap: shouldShowMap,
          volunteerAcceptTime: volunteerAcceptTime,
          merchantToCustomerDistance: merchantToCustomerDistance
        });
        
        // 根据订单类型设置配送信息
        if (orderDetail.order_type === 'dine_in') {
          // 自取订单
          this.setData({
            deliveryStatus: '到店自取',
            estimatedArrivalTime: `取餐号：${orderDetail.pickup_number || '待生成'}`
          });
        } else {
          // 外送订单
          this.setData({
            deliveryStatus: this.getDeliveryStatusText(orderDetail.status)
          });
          
          // 如果订单状态需要显示预计送达时间，启动实时计算
          if (shouldShowMap && volunteerAcceptTime) {
            // 先获取用户位置，然后初始化地图和开始计算预计送达时间
            this.getUserLocation();
            // 启动预计送达时间实时计算
            this.startEstimatedTimeCalculation();
          } else {
            // 降级处理：使用固定时间
            this.setData({
              estimatedArrivalTime: this.getEstimatedArrivalTime(orderDetail.status, orderDetail.created_at)
          });
          }
        }
        
        // 如果需要显示地图，初始化地图
        if (shouldShowMap && shopInfo.latitude && shopInfo.longitude) {
          // 先获取用户位置，然后初始化地图
          this.getUserLocation();
        }
      })
      .catch(err => {
        console.error('获取订单详情失败:', err);
        wx.showToast({ title: '获取订单信息失败', icon: 'none' });
        
        // 错误情况下的降级处理，确保页面仍能正常显示
        const currentOrderInfo = this.data.orderInfo || {};
        if (!currentOrderInfo.productAmount) {
          currentOrderInfo.productAmount = '0.00';
          currentOrderInfo.totalPrice = '0.00';
          this.setData({ orderInfo: currentOrderInfo });
        }
      });
  },


  
  /**
   * 图片加载错误处理
   */
  onImageError: function(e) {
    const type = e.currentTarget.dataset.type;
    console.warn('图片加载失败:', type, e);
    
    // 根据类型设置默认图片
    if (type === 'logo') {
      this.setData({
        'shopInfo.logo': '' // 设置为空，让WXML使用默认显示
      });
    }
  },

  /**
   * 商家logo图片加载错误处理
   */
  onLogoError: function(e) {
    console.warn('商家logo图片加载失败:', e);
    // 如果图片加载失败，设置为空，显示占位符
    this.setData({
      'shopInfo.logo': ''
    });
  },

  /**
   * 格式化时间
   */
  formatTime: function(timeString) {
    if (!timeString) return '';
    
    const date = new Date(timeString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}`;
  },
  
  /**
   * 获取订单状态文本
   */
  getStatusText: function(status) {
    const statusMap = {
      'pending': '待付款',
      'paid': '已付款',
      'customer_accepted': '顾客已确认',
      'merchant_accepted': '商家已接单',
      'waiting_volunteer': '等待志愿者接单',
      'volunteer_accepted': '志愿者已接单',
      'arrived_restaurant': '已到达餐厅',
      'shipped': '配送中',
      'delivered': '已送达',
      'completed': '已完成',
      'cancelled': '已取消',
      'refunded': '已退款'
    };
    return statusMap[status] || '未知状态';
  },
  
  /**
   * 获取配送状态文本
   */
  getDeliveryStatusText: function(status) {
    const statusMap = {
      'pending': '等待商家接单',
      'paid': '等待商家接单',
      'customer_accepted': '等待商家接单',
      'merchant_accepted': '商家已接单',
      'waiting_volunteer': '等待志愿者接单',
      'volunteer_accepted': '志愿者已接单',
      'arrived_restaurant': '骑手已到达餐厅',
      'shipped': '骑手配送中',
      'delivered': '已送达',
      'completed': '订单已完成',
      'cancelled': '订单已取消',
      'refunded': '订单已退款'
    };
    return statusMap[status] || '等待处理';
  },
  
  /**
   * 获取预计送达时间（降级处理，固定时间）
   */
  getEstimatedArrivalTime: function(status, createdAt) {
    if (!createdAt) return '';
    
    const createTime = new Date(createdAt);
    const estimatedTime = new Date(createTime.getTime() + 30 * 60 * 1000); // 默认30分钟后
    
    const hours = String(estimatedTime.getHours()).padStart(2, '0');
    const minutes = String(estimatedTime.getMinutes()).padStart(2, '0');
    
    if (status === 'delivered' || status === 'completed') {
      return '已送达';
    } else if (status === 'cancelled' || status === 'refunded') {
      return '订单已取消';
    } else {
      return `预计${hours}:${minutes}送达`;
    }
  },
  
  /**
   * 计算两点之间的距离（公里）
   * 使用 Haversine 公式
   */
  calculateDistance: function(lat1, lng1, lat2, lng2) {
    if (!lat1 || !lng1 || !lat2 || !lng2) return null;
    
    const R = 6371; // 地球半径（公里）
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    
    return distance;
  },
  
  /**
   * 启动预计送达时间实时计算
   */
  startEstimatedTimeCalculation: function() {
    // 清除之前的定时器
    if (this.data.estimateTimer) {
      clearInterval(this.data.estimateTimer);
    }
    
    // 立即计算一次
    this.calculateEstimatedArrivalTime();
    
    // 每10秒更新一次
    const timer = setInterval(() => {
      this.calculateEstimatedArrivalTime();
    }, 10000); // 10秒
    
    this.setData({
      estimateTimer: timer
    });
  },
  
  /**
   * 停止预计送达时间计算
   */
  stopEstimatedTimeCalculation: function() {
    if (this.data.estimateTimer) {
      clearInterval(this.data.estimateTimer);
      this.setData({
        estimateTimer: null
      });
    }
  },
  
  /**
   * 计算预计送达时间（实时）
   */
  calculateEstimatedArrivalTime: function() {
    const { 
      orderInfo, 
      shopInfo, 
      volunteerInfo, 
      userLatitude, 
      userLongitude,
      volunteerSpeed,
      waitTime,
      volunteerAcceptTime,
      merchantToCustomerDistance
    } = this.data;
    
    // 检查必要数据
    if (!orderInfo || orderInfo.order_type !== 'takeaway') {
      return;
    }
    
    // 如果订单已完成或已取消，停止计算
    if (orderInfo.status === 'delivered' || orderInfo.status === 'completed' || 
        orderInfo.status === 'cancelled' || orderInfo.status === 'refunded') {
      this.stopEstimatedTimeCalculation();
      if (orderInfo.status === 'delivered' || orderInfo.status === 'completed') {
        this.setData({
          estimatedArrivalTime: '已送达'
        });
      } else {
        this.setData({
          estimatedArrivalTime: '订单已取消'
        });
      }
      return;
    }
    
    // 如果没有接单时间，使用降级处理
    if (!volunteerAcceptTime) {
      this.setData({
        estimatedArrivalTime: this.getEstimatedArrivalTime(orderInfo.status, orderInfo.created_at)
      });
      return;
    }
    
    // 计算商家到顾客的距离（如果还没有计算）
    let d2 = merchantToCustomerDistance;
    if (!d2 && shopInfo.latitude && shopInfo.longitude && 
        userLatitude && userLongitude) {
      d2 = this.calculateDistance(
        shopInfo.latitude, 
        shopInfo.longitude,
        userLatitude,
        userLongitude
      );
      if (d2) {
        this.setData({
          merchantToCustomerDistance: d2
        });
      }
    }
    
    // 如果没有顾客位置，无法计算
    if (!userLatitude || !userLongitude || !shopInfo.latitude || !shopInfo.longitude) {
      this.setData({
        estimatedArrivalTime: '等待定位...'
      });
      return;
    }
    
    // 计算志愿者当前位置到商家的距离（D1）
    // 注意：这里假设志愿者位置就是用户位置（实际应该从后端获取志愿者实时位置）
    // 由于无法获取志愿者实时位置，这里使用商家位置作为参考
    // 实际应用中，应该从后端API获取志愿者实时位置
    let d1 = 0;
    if (volunteerInfo.latitude && volunteerInfo.longitude) {
      d1 = this.calculateDistance(
        volunteerInfo.latitude,
        volunteerInfo.longitude,
        shopInfo.latitude,
        shopInfo.longitude
      ) || 0;
    } else {
      // 如果没有志愿者位置，假设志愿者正在前往商家
      // 这里可以根据订单状态估算
      if (orderInfo.status === 'volunteer_accepted' || orderInfo.status === 'arrived_restaurant') {
        d1 = 0; // 已到达商家
      } else {
        // 估算距离（可以根据历史数据优化）
        d1 = d2 ? d2 * 0.3 : 1; // 假设志愿者距离商家为顾客距离的30%
      }
    }
    
    // 如果没有商家到顾客的距离，使用默认值
    if (!d2) {
      d2 = 2; // 默认2公里
    }
    
    // 计算基础总耗时（小时）
    // 基础总耗时 = (D1 + D2) / V + T_wait
    const V = volunteerSpeed; // 10 km/h
    const T_wait = waitTime / 60; // 转换为小时
    const baseTime = (d1 + d2) / V + T_wait;
    
    // 计算已消耗时间（小时）
    const acceptTime = new Date(volunteerAcceptTime).getTime();
    const currentTime = new Date().getTime();
    const T_used = (currentTime - acceptTime) / (1000 * 3600); // 转换为小时
    
    // 计算剩余耗时（小时）
    let T_remain = baseTime - T_used;
    
    // 处理边界情况：剩余耗时为负数（已超时）
    if (T_remain < 0) {
      const overdueMinutes = Math.abs(T_remain * 60);
      this.setData({
        estimatedArrivalTime: `已超时${Math.round(overdueMinutes)}分钟`
      });
      return;
    }
    
    // 计算预计送达时间
    const estimatedTime = new Date(currentTime + T_remain * 3600 * 1000);
    const hours = String(estimatedTime.getHours()).padStart(2, '0');
    const minutes = String(estimatedTime.getMinutes()).padStart(2, '0');
    
    this.setData({
      estimatedArrivalTime: `预计${hours}:${minutes}送达`
    });
  },
  
  /**
   * 获取用户真实位置
   */
  getUserLocation: function() {
    const that = this;
    wx.getLocation({
      type: 'gcj02', // 坐标系
      altitude: true,
      success(res) {
        const userLatitude = res.latitude;
        const userLongitude = res.longitude;
        
        console.log('获取用户位置成功:', userLatitude, userLongitude);
        
        // 将用户位置作为目的地
        that.setData({
          userLatitude,
          userLongitude
        });
        
        // 初始化地图
        that.initMap();
        
        // 如果订单需要计算预计送达时间，重新计算
        if (that.data.orderInfo && that.data.orderInfo.order_type === 'takeaway' && 
            that.data.shouldShowMap && that.data.volunteerAcceptTime) {
          // 计算商家到顾客的距离
          const { shopInfo } = that.data;
          if (shopInfo.latitude && shopInfo.longitude) {
            const distance = that.calculateDistance(
              shopInfo.latitude,
              shopInfo.longitude,
              userLatitude,
              userLongitude
            );
            if (distance) {
              that.setData({
                merchantToCustomerDistance: distance
              });
            }
          }
          // 重新计算预计送达时间
          that.calculateEstimatedArrivalTime();
        }
      },
      fail(err) {
        console.log('获取位置失败', err);
        wx.showModal({
          title: '定位失败',
          content: '无法获取您的位置信息，请检查是否已授权位置权限。将使用默认位置显示地图。',
          showCancel: false
        });
        // 即使定位失败也使用默认位置初始化地图
        that.setData({
          userLatitude: 31.25016171,
          userLongitude: 121.49089949
        });
        that.initMap();
      }
    });
  },
  
  // 初始化地图相关数据
  initMap() {
    const { shopInfo, volunteerInfo, userLatitude, userLongitude, orderInfo } = this.data;
    
    // 如果没有商家位置，不初始化地图
    if (!shopInfo.latitude || !shopInfo.longitude) {
      console.log('商家位置信息不完整，跳过地图初始化');
      return;
    }
    
    const markers = [];
    const polyline = [];
    
    // 添加商家标记
    markers.push({
        id: 1,
        latitude: shopInfo.latitude,
        longitude: shopInfo.longitude,
        title: shopInfo.name,
        callout: {
          content: shopInfo.name,
          display: 'BYCLICK',
          fontSize: 12
        },
        width: 30,
        height: 30
    });
    
    // 如果是外送订单且有用户位置，添加用户位置标记
    if (orderInfo && orderInfo.order_type === 'takeaway' && userLatitude && userLongitude) {
      markers.push({
        id: 2,
        latitude: userLatitude,
        longitude: userLongitude,
        title: '我的位置',
        callout: {
          content: '我的位置',
          display: 'BYCLICK',
          fontSize: 12
        },
        width: 30,
        height: 30
      });
      
      // 如果有志愿者位置，添加志愿者标记和路线
      if (volunteerInfo.latitude && volunteerInfo.longitude) {
        markers.push({
          id: 3,
          latitude: volunteerInfo.latitude,
          longitude: volunteerInfo.longitude,
          title: '志愿者',
          callout: {
            content: '志愿者',
            display: 'BYCLICK',
            fontSize: 12
          },
          iconPath: volunteerInfo.avatar || '/images/rider-avatar.png',
          width: 30,
          height: 30,
          animation: true
        });
    
        // 创建配送路线
        polyline.push({
          points: [
            { latitude: shopInfo.latitude, longitude: shopInfo.longitude },
            { latitude: volunteerInfo.latitude, longitude: volunteerInfo.longitude },
            { latitude: userLatitude, longitude: userLongitude }
          ],
          color: '#07C160',
          width: 3,
          dottedLine: false
        });
      } else {
        // 只有商家和用户位置，创建简单路线
        polyline.push({
        points: [
          { latitude: shopInfo.latitude, longitude: shopInfo.longitude },
            { latitude: userLatitude, longitude: userLongitude }
        ],
        color: '#07C160',
        width: 3,
        dottedLine: false
        });
      }
    
      // 设置地图中心点（商家和用户中间点）
      const centerLat = (shopInfo.latitude + userLatitude) / 2;
      const centerLng = (shopInfo.longitude + userLongitude) / 2;
    
    this.setData({
      latitude: centerLat,
      longitude: centerLng,
      markers,
      polyline
    });
    } else {
      // 自取订单或没有用户位置，只显示商家位置
      this.setData({
        latitude: shopInfo.latitude,
        longitude: shopInfo.longitude,
        markers,
        polyline
      });
    }
  },

  /**
   * 联系志愿者
   */
  contactVolunteer: function() {
    const volunteerInfo = this.data.volunteerInfo || {};
    const phone = volunteerInfo.phone;
    
    if (!phone) {
      wx.showModal({
        title: '提示',
        content: '当前订单尚未分配志愿者，请稍后再试',
        showCancel: false,
        confirmText: '知道了'
      });
      return;
    }
    
    wx.makePhoneCall({
      phoneNumber: phone,
      success: () => {
        console.log('拨打志愿者电话成功');
      },
      fail: (err) => {
        console.log('拨打志愿者电话失败', err);
        wx.showToast({
          title: '拨打电话失败',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },

  /**
   * 联系商家
   */
  contactShop: function() {
    const shopInfo = this.data.shopInfo || {};
    const phone = shopInfo.phone;
    
    if (!phone) {
      wx.showModal({
        title: '提示',
        content: '商家电话信息暂不可用，请联系客服',
        showCancel: false,
        confirmText: '知道了'
      });
      return;
    }
    
    wx.makePhoneCall({
      phoneNumber: phone,
      success: () => {
        console.log('拨打商家电话成功');
      },
      fail: (err) => {
        console.log('拨打商家电话失败', err);
        wx.showToast({
          title: '拨打电话失败',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },

  /**
   * 申请退款
   */
  applyRefund: function() {
    const orderInfo = this.data.orderInfo;
    if (!orderInfo) {
      wx.showToast({ title: '订单信息不存在', icon: 'none' });
      return;
    }
    
    // 只有待付款或已付款状态的订单可以申请退款
    if (orderInfo.status !== 'pending' && orderInfo.status !== 'paid') {
      wx.showToast({ 
        title: '当前订单状态不支持退款', 
        icon: 'none' 
      });
      return;
    }
    
    wx.showModal({
      title: '申请退款',
      content: '确定要申请退款吗？退款将在1-3个工作日内到账。',
      success: (res) => {
        if (res.confirm) {
          // TODO: 调用退款API
          wx.showToast({ title: '退款申请已提交', icon: 'success' });
        }
      }
    });
  },

  /**
   * 联系志愿者（消息）
   */
  sendVolunteerMessage: function() {
    const volunteerInfo = this.data.volunteerInfo || {};
    const phone = volunteerInfo.phone;
    
    if (!phone) {
      wx.showModal({
        title: '提示',
        content: '当前订单尚未分配志愿者，请稍后再试',
        showCancel: false,
        confirmText: '知道了'
      });
      return;
    }
    
    // 跳转到聊天页面或直接拨打电话
    wx.makePhoneCall({
      phoneNumber: phone,
      success: () => {
        console.log('拨打志愿者电话成功');
      },
      fail: (err) => {
        console.log('拨打志愿者电话失败', err);
        wx.showToast({
          title: '拨打电话失败',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },

  /**
   * 刷新地图
   */
  refreshMap: function() {
    // 重新获取用户位置并刷新地图
    this.getUserLocation();
    
    wx.showToast({
      title: '地图已刷新',
      icon: 'success',
      duration: 1500
    });
  },
  
  /**
   * 页面卸载时清理定时器
   */
  onUnload: function() {
    this.stopEstimatedTimeCalculation();
  },
  
  /**
   * 页面隐藏时清理定时器
   */
  onHide: function() {
    this.stopEstimatedTimeCalculation();
  },
  
  /**
   * 页面显示时重新启动计算（如果需要）
   */
  onShow: function() {
    const { orderInfo, shouldShowMap, volunteerAcceptTime } = this.data;
    if (orderInfo && orderInfo.order_type === 'takeaway' && 
        shouldShowMap && volunteerAcceptTime && !this.data.estimateTimer) {
      this.startEstimatedTimeCalculation();
    }
  },
  
  /**
   * 返回上一页
   */
  navigateBack: function() {
    this.stopEstimatedTimeCalculation();
    wx.navigateBack({
      delta: 1
    });
  },
  
  /**
   * 跳转到首页
   */
  navigateToHome: function() {
    wx.switchTab({
      url: '/pages/order-index/order-index'
    });
  },
  
  /**
   * 跳转到点餐页面
   */
  navigateToFood: function() {
    wx.switchTab({
      url: '/pages/order-food/order-food'
    });
  },
  
  /**
   * 跳转到我的页面
   */
  navigateToMine: function() {
    wx.switchTab({
      url: '/pages/order-mine/order-mine'
    });
  }
});