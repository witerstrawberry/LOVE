// 空文件，避免编译错误
Page({
  onLoad: function() {
    // 重定向到新的订单确认页面
    wx.redirectTo({
      url: '/pages/old-confirm/order-confirm'
    });
  }
});