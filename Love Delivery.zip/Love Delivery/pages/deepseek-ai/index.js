// pages/deepseek-ai/index.js
const { getApiUrl } = require('../../utils/config');

Page({
  data: {
    prompt: "",
    aiReply: "",
    isLoading: false,
    history: [],
    inputPlaceholder: "请输入您的问题..."
  },

  // 输入框内容变化
  onInputChange(e) {
    this.setData({
      prompt: e.detail.value
    });
  },

  // 获取AI回复
  getAiReply() {
    const { prompt } = this.data;
    
    // 验证输入
    if (!prompt.trim()) {
      wx.showToast({
        title: '请输入问题',
        icon: 'none'
      });
      return;
    }

    // 显示加载状态
    this.setData({
      isLoading: true
    });

    // 调用后端API
    wx.request({
      url: (() => {
        const { getApiUrl } = require('../../utils/config');
        return getApiUrl('/deepseek/chat');
      })(),
      method: "POST",
      data: { 
        prompt: prompt.trim() 
      },
      success: (res) => {
        if (res.data.success) {
          // 更新回复内容
          this.setData({
            aiReply: res.data.reply,
            // 添加到历史记录
            history: [...this.data.history, {
              type: 'user',
              content: prompt.trim()
            }, {
              type: 'ai',
              content: res.data.reply
            }],
            prompt: '' // 清空输入框
          });
        } else {
          wx.showToast({
            title: res.data.error || '获取回复失败',
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        console.error('请求失败:', err);
        wx.showToast({
          title: '网络错误，请检查后端服务是否运行',
          icon: 'none'
        });
      },
      complete: () => {
        // 隐藏加载状态
        this.setData({
          isLoading: false
        });
      }
    });
  },

  // 清空历史记录
  clearHistory() {
    wx.showModal({
      title: '确认清空',
      content: '确定要清空所有对话记录吗？',
      success: (res) => {
        if (res.confirm) {
          this.setData({
            history: [],
            aiReply: ''
          });
          wx.showToast({
            title: '已清空',
            icon: 'success'
          });
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 页面加载时的初始化操作
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return {
      title: 'DeepSeek AI助手',
      path: '/pages/deepseek-ai/index'
    };
  }
});