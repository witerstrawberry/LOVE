// pages/restaurant/task.js
// 商家任务发布页 - 任务发布功能实现

const { post } = require('../../utils/request');
const { getApiUrl } = require('../../utils/config');

const DRAFT_KEY = 'merchant_task_publish_draft';

Page({
  data: {
    submitting: false,
    hasDraft: false,
    taskTypeOptions: ['公益活动-公益分拣', '配送-物资配送', '店内服务-店内协助'],
    form: {
      task_title: '',
      task_type: '',
      task_type_index: 0,
      require_num: '',
      start_time: '',
      end_time: '',
      delivery_deadline: '',
      contact_name: '',
      contact_phone: '',
      address: '',
      task_content: '',
      delivery_fee: '',
      max_delivery_distance: ''
    },
    errors: {}
  },

  onLoad() {
    wx.setNavigationBarTitle({
      title: '任务发布'
    });
    // 先恢复草稿
    this.restoreDraft();
    // 再尝试用当前商家地址作为默认任务地点（仅在地址为空时生效）
    this.prefillMerchantAddress();
  },

  // 通用输入处理
  onInputChange(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    if (!field) return;

    this.setData({
      [`form.${field}`]: value,
      [`errors.${field}`]: ''
    });
  },

  // 任务类型选择
  onTaskTypeChange(e) {
    const index = Number(e.detail.value || 0);
    const mapping = ['公益活动', '配送', '店内服务'];
    const type = mapping[index] || '';

    this.setData({
      'form.task_type_index': index,
      'form.task_type': type,
      'errors.task_type': ''
    });
  },

  // 表单校验
  validateForm() {
    const form = this.data.form;
    const errors = {};

    // 标题
    if (!form.task_title || !form.task_title.trim()) {
      errors.task_title = '任务标题不能为空';
    } else if (form.task_title.trim().length > 100) {
      errors.task_title = '任务标题不能超过100字';
    }

    // 类型
    if (!form.task_type) {
      errors.task_type = '请选择任务类型';
    }

    // 人数
    const requireNum = Number(form.require_num);
    if (!form.require_num) {
      errors.require_num = '请填写所需志愿者人数';
    } else if (!Number.isInteger(requireNum) || requireNum <= 0) {
      errors.require_num = '人数必须为大于0的正整数';
    }

    // 时间解析工具
    const parseTime = (str) => {
      if (!str) return null;
      // 兼容 "YYYY-MM-DD HH:mm" 格式
      return new Date(str.replace(/-/g, '/'));
    };

    const start = parseTime(form.start_time);
    const end = parseTime(form.end_time);
    const deadline = parseTime(form.delivery_deadline);
    const now = new Date();

    // 开始时间
    if (!form.start_time) {
      errors.start_time = '请填写任务开始时间';
    } else if (!start || isNaN(start.getTime())) {
      errors.start_time = '开始时间格式不正确';
    } else if (start.getTime() + 1 * 60 * 1000 < now.getTime()) {
      // 允许略早于当前时间，预留1分钟容错
      errors.start_time = '开始时间不能早于当前时间太多，请检查';
    }

    // 结束时间
    if (!form.end_time) {
      errors.end_time = '请填写任务结束时间';
    } else if (!end || isNaN(end.getTime())) {
      errors.end_time = '结束时间格式不正确';
    } else if (start && end <= start) {
      errors.end_time = '结束时间必须晚于开始时间';
    }

    // 配送截止时间
    if (!form.delivery_deadline) {
      errors.delivery_deadline = '请填写配送截止时间';
    } else if (!deadline || isNaN(deadline.getTime())) {
      errors.delivery_deadline = '配送截止时间格式不正确';
    } else if (end && deadline > end) {
      errors.delivery_deadline = '配送截止时间必须早于任务结束时间';
    }

    // 联系电话格式
    if (form.contact_phone && form.contact_phone.trim()) {
      const phone = form.contact_phone.trim();
      const mobileReg = /^1[3-9]\d{9}$/;
      const landlineReg = /^0\d{2,3}-?\d{7,8}$/;
      if (!mobileReg.test(phone) && !landlineReg.test(phone)) {
        errors.contact_phone = '电话格式不正确，请填写手机号或区号-座机号';
      }
    }

    // 地点
    if (!form.address || !form.address.trim()) {
      errors.address = '任务地点不能为空';
    } else if (form.address.trim().length > 200) {
      errors.address = '任务地点不能超过200字';
    }

    // 详情
    if (!form.task_content || !form.task_content.trim()) {
      errors.task_content = '任务详情描述不能为空';
    } else if (form.task_content.trim().length < 10) {
      errors.task_content = '任务详情描述至少需要10个字';
    }

    // 补贴
    if (form.delivery_fee) {
      const fee = Number(form.delivery_fee);
      if (isNaN(fee) || fee < 0) {
        errors.delivery_fee = '补贴金额必须为大于等于0的数字';
      } else if (!/^\d+(\.\d{1,2})?$/.test(form.delivery_fee)) {
        errors.delivery_fee = '补贴金额最多保留两位小数';
      }
    }

    // 最大配送距离
    if (form.max_delivery_distance) {
      const dist = Number(form.max_delivery_distance);
      if (isNaN(dist) || dist < 0) {
        errors.max_delivery_distance = '最大配送距离必须为大于等于0的数字';
      } else if (!/^\d+(\.\d{1,2})?$/.test(form.max_delivery_distance)) {
        errors.max_delivery_distance = '最大配送距离最多保留两位小数';
      }
    }

    const valid = Object.keys(errors).length === 0;
    this.setData({ errors });
    return valid;
  },

  // 获取当前商家ID（优先从缓存获取）
  getCurrentMerchantId() {
    const merchantInfo = wx.getStorageSync('merchantInfo');
    if (merchantInfo && merchantInfo.id) {
      return merchantInfo.id.toString().trim();
    }
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo && userInfo.merchant_id) {
      return userInfo.merchant_id.toString().trim();
    }
    return '';
  },

  // 使用当前商家地址预填任务地点（仅当表单中地址为空时）
  prefillMerchantAddress() {
    // 如果表单里已经有地址（例如来自草稿），就不覆盖
    if (this.data.form && this.data.form.address) {
      return;
    }

    const cachedInfo = wx.getStorageSync('merchantInfo');
    if (cachedInfo && cachedInfo.address) {
      this.setData({
        'form.address': cachedInfo.address
      });
      return;
    }

    // 没有缓存时，从后端获取一次商家信息
    wx.request({
      url: getApiUrl('/merchant/private/info'),
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'Authorization': wx.getStorageSync('token') || ''
      },
      success: (res) => {
        if (res.data && res.data.success && res.data.data) {
          const merchantData = res.data.data;
          // 缓存商家信息，后续可复用
          try {
            wx.setStorageSync('merchantInfo', merchantData);
          } catch (e) {
            console.warn('缓存商家信息失败:', e);
          }
          if (!this.data.form.address && merchantData.address) {
            this.setData({
              'form.address': merchantData.address
            });
          }
        }
      }
    });
  },

  // 提交发布
  onSubmit() {
    if (this.data.submitting) return;

    const merchantId = this.getCurrentMerchantId();
    if (!merchantId) {
      wx.showToast({
        title: '未获取到商家信息，请先完善商家资料',
        icon: 'none'
      });
      return;
    }

    if (!this.validateForm()) {
      wx.showToast({
        title: '请先修正表单中的错误',
        icon: 'none'
      });
      return;
    }

    const form = this.data.form;

    // 构造与 task 表一致的字段
    const payload = {
      merchant_id: merchantId,
      contact_name: form.contact_name ? form.contact_name.trim() : null,
      contact_phone: form.contact_phone ? form.contact_phone.trim() : null,
      task_title: form.task_title.trim(),
      task_content: form.task_content.trim(),
      task_type: form.task_type,
      require_num: Number(form.require_num),
      start_time: form.start_time.trim(),
      end_time: form.end_time.trim(),
      address: form.address.trim(),
      delivery_fee: form.delivery_fee ? Number(form.delivery_fee) : 0,
      max_delivery_distance: form.max_delivery_distance ? Number(form.max_delivery_distance) : 5,
      delivery_deadline: form.delivery_deadline.trim()
      // status / created_at / updated_at 由后端/数据库自动填充
    };

    this.setData({ submitting: true });

    // 记录草稿，防止网络错误导致数据丢失
    this.saveDraft();

    post('/tasks', payload, { showLoading: true })
      .then(res => {
        if (res && (res.success || res.code === 0)) {
          wx.showToast({
            title: '发布成功',
            icon: 'success'
          });
          // 清理草稿与表单
          this.clearDraft();
          this.resetForm();

          // 可选：1.5秒后返回商家首页/上一级
          setTimeout(() => {
            wx.navigateBack({
              fail: () => {
                wx.switchTab({
                  url: '/pages/restaurant/index'
                });
              }
            });
          }, 1500);
        } else {
          wx.showToast({
            title: res?.message || '发布失败，请稍后重试',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        console.error('发布任务失败:', err);
        wx.showToast({
          title: err?.message || '网络异常，已为您保留草稿',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({ submitting: false });
      });
  },

  // 重置表单
  resetForm() {
    this.setData({
      form: {
        task_title: '',
        task_type: '',
        task_type_index: 0,
        require_num: '',
        start_time: '',
        end_time: '',
        delivery_deadline: '',
        contact_name: '',
        contact_phone: '',
        address: '',
        task_content: '',
        delivery_fee: '',
        max_delivery_distance: ''
      },
      errors: {}
    });
  },

  onReset() {
    wx.showModal({
      title: '确认重置',
      content: '确定要清空当前填写的任务信息吗？',
      success: (res) => {
        if (res.confirm) {
          this.resetForm();
          this.clearDraft();
        }
      }
    });
  },

  // 草稿相关
  saveDraft() {
    try {
      wx.setStorageSync(DRAFT_KEY, this.data.form);
    } catch (e) {
      console.warn('保存任务草稿失败:', e);
    }
  },

  restoreDraft() {
    try {
      const draft = wx.getStorageSync(DRAFT_KEY);
      if (draft && typeof draft === 'object') {
        this.setData({
          form: { ...this.data.form, ...draft },
          hasDraft: true
        });
      }
    } catch (e) {
      console.warn('恢复任务草稿失败:', e);
    }
  },

  clearDraft() {
    try {
      wx.removeStorageSync(DRAFT_KEY);
    } catch (e) {
      console.warn('清除任务草稿失败:', e);
    }
    this.setData({ hasDraft: false });
  }
});


