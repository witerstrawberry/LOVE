// pages/restaurant/index.js - 
// 社区餐厅首页
const { merchantAPI, taskAPI } = require('../../utils/api');
const { getApiUrl } = require('../../utils/config');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showMerchantInfoForm: false, // 是否显示商家信息完善表单
    pageTitle: '商家首页',
    restaurantName: '阳光社区餐厅',
    isOpen: true, // 营业状态
    businessStatusInitialized: false, // 营业状态是否已初始化
    unreadNotifications: 3,
    todayOrders: 28,
    todayRevenue: '1,580.00',
    // 商家信息对象 - 修复数据渲染问题
    restaurantInfo: {
      name: '',
      phone: '',
      address: '',
      description: '',
      businessHours: '',
      category: '',
      logo: ''
    },

    recentOrders: [],
    weeklyRevenue: [
      { day: '周一', value: 850 },
      { day: '周二', value: 1020 },
      { day: '周三', value: 980 },
      { day: '周四', value: 1250 },
      { day: '周五', value: 1580 },
      { day: '周六', value: 1850 },
      { day: '周日', value: 1420 }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('商家首页页面加载...');
    
    // 页面加载时重置营业状态初始化标记
    this.setData({
      businessStatusInitialized: false
    });
    
    // 获取用户信息并检查商家信息完善状态
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) {
      // 如果没有用户信息，跳转到登录页面
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    
    // 页面加载逻辑
    this.calculateBarHeights();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('=== index页面 onShow ===');
    
    // 页面显示时检查商家信息是否完善
    this.checkMerchantInfoStatus();
    
    // 只有当营业状态未初始化时才获取状态，避免重复请求
    if (!this.data.businessStatusInitialized) {
      console.log('营业状态未初始化，开始获取状态...');
      this.fetchBusinessStatus();
    } else {
      console.log('营业状态已初始化，使用缓存状态:', this.data.isOpen);
    }
    
    // 页面显示时刷新数据
    this.refreshData();
    
    // 获取今日订单统计数据（从后台API获取真实数据）
    this.fetchTodayOrderStats();
    
    // 获取最近的订单数据
    this.fetchRecentOrders();
  },

  /**
   * 检查商家信息是否完善
   */
  checkMerchantInfoStatus: function() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo.id) {
      console.log('用户信息不存在');
      return;
    }

    // 调用后端API检查商家信息完善状态
    wx.request({
      url: getApiUrl('/merchant/check-status'),
      method: 'GET',
      data: {
        userId: userInfo.id
      },
      success: (res) => {
        console.log('商家信息状态检查结果:', res.data);
        if (res.data && res.data.success && !res.data.data.isComplete) {
          // 商家信息不完善，显示弹窗
          this.setData({
            showMerchantInfoForm: true
          });
        }
      },
      fail: (error) => {
        console.error('检查商家信息状态失败:', error);
        // 容错处理：如果API调用失败，暂时不显示弹窗
      }
    });
  },

  /**
   * 处理商家信息表单提交
   */
  handleMerchantInfoSubmit: function(e) {
    const merchantData = e.detail.merchantInfo;
    console.log('提交的商家信息:', merchantData);
    
    // 字段映射：将前端驼峰格式转换为后端下划线格式
    const formattedData = {
      name: merchantData.name,
      phone: merchantData.phone,
      contact_person: merchantData.contactPerson,
      business_hours: merchantData.businessHours,
      address: merchantData.address,
      category: merchantData.category,
      description: merchantData.description,
      min_order_amount: merchantData.minOrderAmount,
      delivery_fee: merchantData.deliveryFee,
      delivery_scope: merchantData.deliveryScope,
      // 新增字段映射
      credit_code: merchantData.creditCode || '',
      email: merchantData.email || '',
      website: merchantData.website || '',
      // 新增资质图片字段
      business_license_image: merchantData.businessLicenseImage,
      restaurant_image: merchantData.restaurantImage,
      kitchen_image: merchantData.kitchenImage
    };

    // 调用后端API保存商家信息
    wx.request({
      url: getApiUrl('/merchant/private/save'),
      method: 'POST',
      header: {
        'content-type': 'application/json',
        'Authorization': wx.getStorageSync('token') || ''
      },
      data: formattedData,
      success: (res) => {
        console.log('保存商家信息结果:', res.data);
        if (res.data && res.data.success) {
          wx.showToast({
            title: '信息保存成功',
            icon: 'success'
          });
          // 隐藏弹窗
          this.setData({
            showMerchantInfoForm: false
          });
          // 刷新页面数据
          this.refreshData();
        } else {
          wx.showToast({
            title: res.data.message || '保存失败',
            icon: 'none'
          });
        }
      },
      fail: (error) => {
        console.error('保存商家信息失败:', error);
        wx.showToast({
          title: '网络错误，请重试',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 取消商家信息表单
   */
  handleMerchantInfoCancel: function() {
    this.setData({
      showMerchantInfoForm: false
    });
  },

  /**
   * 刷新数据
   */
  refreshData: function() {
    console.log('刷新商家首页数据，包括商家详细信息');
    
    // 重新获取商家信息
    const that = this;
    wx.request({
      url: 'https://baichuang.online/nyxc/api/merchant/private/info',
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'Authorization': wx.getStorageSync('token') || '',
        'Cache-Control': 'no-cache', // 禁用缓存
        'If-Modified-Since': '0' // 强制刷新
      },
      success: (res) => {
        console.log('重新获取商家信息结果:', res.data);
        if (res.data && res.data.success) {
          // 更新商家信息到全局数据 - 修复字段映射
          const merchantData = res.data.data;
          console.log('商家数据字段:', Object.keys(merchantData));
          
          // 使用实际的API字段名更新数据
      if (that.data.restaurantInfo) {
        // 直接更新restaurantInfo对象中的关键字段
        const updatedInfo = {
          ...that.data.restaurantInfo,
          name: merchantData.name || '',
          phone: merchantData.phone || '',
          address: merchantData.address || '',
          description: merchantData.description || '',
          businessHours: merchantData.business_hours || '',
          category: merchantData.category || '',
          logo: merchantData.logo || '',
          credit_code: merchantData.credit_code || '' // 添加真实的社会统一代码
        };
        
        that.setData({
          restaurantInfo: updatedInfo,
          // 使用累计销售量作为临时数据（后续会被getMerchantStats覆盖）
          todayOrders: merchantData.sales_volume || 0,
          todayRevenue: (merchantData.sales_volume || 0) * 15.5 // 使用累计数据计算
        });
      } else {
        // 如果restaurantInfo不存在，创建它
        that.setData({
          restaurantInfo: {
            name: merchantData.name || '',
            phone: merchantData.phone || '',
            address: merchantData.address || '',
            description: merchantData.description || '',
            businessHours: merchantData.business_hours || '',
            category: merchantData.category || '',
            logo: merchantData.logo || '',
            credit_code: merchantData.credit_code || '' // 添加真实的社会统一代码
          },
          todayOrders: merchantData.sales_volume || 0, // 使用累计数据作为临时值
          todayRevenue: (merchantData.sales_volume || 0) * 15.5 // 使用累计数据计算
        });
      }
          
          // 更新柱状图高度
          that.calculateBarHeights();
          console.log('商家信息已刷新:', that.data.restaurantInfo);
          
          // 验证数据渲染
          console.log('验证渲染数据:');
          console.log('- 餐厅名称:', that.data.restaurantInfo.name);
          console.log('- 联系电话:', that.data.restaurantInfo.phone);
          console.log('- 地址:', that.data.restaurantInfo.address);
          console.log('- 营业时间:', that.data.restaurantInfo.businessHours);
          console.log('- 餐厅类型:', that.data.restaurantInfo.category);
          console.log('- 今日订单(累计数据):', that.data.todayOrders);
          
          // 获取真正的今日订单统计
          that.fetchTodayOrderStats();
          
          // 获取最近的订单数据
          that.fetchRecentOrders();
        } else {
          wx.showToast({
            title: '获取商家信息失败',
            icon: 'none'
          });
        }
      },
      fail: (error) => {
        console.error('获取商家信息失败:', error);
        wx.showToast({
          title: '网络错误，请重试',
          icon: 'none'
        });
      }
    });
  },
  
  /**
   * 获取今日订单统计数据
   */
  fetchTodayOrderStats: function() {
    console.log('正在获取今日订单统计数据...');
    const that = this;
    
    // 调用商家统计API
    merchantAPI.getMerchantStats()
      .then(res => {
        console.log('今日订单统计API返回:', res);
        
        if (res.success) {
          const statsData = res.data;
          const todayOrders = statsData.todayOrders || 0;
          const todayRevenue = statsData.todayRevenue || 0;
          
          console.log(`获取到今日订单数据: ${todayOrders}单, 营收: ¥${todayRevenue}`);
          
          that.setData({
            todayOrders: todayOrders,
            todayRevenue: todayRevenue.toFixed(2)
          });
          
          console.log('今日订单数据已更新:', {
            todayOrders: that.data.todayOrders,
            todayRevenue: that.data.todayRevenue
          });
        } else {
          console.warn('获取今日订单统计失败:', res.message);
          // 失败时保持现有数据不变，或使用默认值
          wx.showToast({
            title: '获取今日统计失败',
            icon: 'none',
            duration: 1500
          });
        }
      })
      .catch(error => {
        console.error('获取今日订单统计失败:', error);
        // 网络错误或API错误时，显示友好提示
        wx.showToast({
          title: '网络错误，获取统计失败',
          icon: 'none',
          duration: 1500
        });
      });
  },
  /**
   * 获取最近的订单数据
   */
  fetchRecentOrders: function() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) {
      console.log('用户信息不存在，无法获取订单数据');
      return;
    }

    // 获取当前商家信息
    const merchantId = userInfo && userInfo.merchant_id ? userInfo.merchant_id : 'MER10001';
    
    console.log('当前商家ID:', merchantId);
    
    wx.request({
      url: getApiUrl('/order/merchant/orders'),
      method: 'GET',
      data: {
        page: 1,
        limit: 3,  // 只获取最近3个订单
        merchantId: merchantId  // 添加商家ID参数
      },
      success: (res) => {
        console.log('获取订单列表结果:', res.data);
        console.log('完整响应数据:', JSON.stringify(res.data, null, 2));
        
        if (res.data && res.data.success && res.data.data) {
          const data = res.data.data;
          console.log('订单数据内容:', data);
          
          // 检查订单数据格式，处理嵌套数据结构
          if (data.orders) {
            // 处理后端返回的嵌套结构：{orders: Array, pagination: Object}
            let ordersArray = null;
            
            if (Array.isArray(data.orders)) {
              // 如果data.orders直接是数组
              ordersArray = data.orders;
            } else if (data.orders.orders && Array.isArray(data.orders.orders)) {
              // 如果data.orders是对象，且data.orders.orders是数组
              ordersArray = data.orders.orders;
            } else if (data.orders.data && Array.isArray(data.orders.data)) {
              // 如果data.orders是对象，且data.orders.data是数组
              ordersArray = data.orders.data;
            }
            
            if (ordersArray && ordersArray.length > 0) {
              // 按创建时间降序排序，确保最新的订单在前
              ordersArray.sort((a, b) => {
                const timeA = new Date(a.created_at).getTime();
                const timeB = new Date(b.created_at).getTime();
                return timeB - timeA; // 降序，最新的在前
              });
              
              // 只取前3个订单
              const top3Orders = ordersArray.slice(0, 3);
              
              // 转换数据格式，适配前端显示
              const formattedOrders = top3Orders.map(order => {
                // 转换订单状态（根据新的状态表）
                const statusMap = {
                  'pending': '待付款',
                  'cancelled': '已取消',
                  'refunded': '已退款',
                  'paid': '顾客已下单',
                  'customer_accepted': '顾客已确认',
                  'merchant_accepted': '商家已接单',
                  'waiting_volunteer': '等待志愿者接单',
                  'volunteer_accepted': '志愿者已接单',
                  'arrived_restaurant': '已到达餐厅',
                  'shipped': '配送中',
                  'delivered': '已送达',
                  'completed': '已完成'
                };
                
                // 格式化日期和时间
                const orderDate = new Date(order.created_at);
                const month = orderDate.getMonth() + 1; // getMonth() 返回 0-11，需要加1
                const day = orderDate.getDate();
                const dateStr = `${month}月${day}日`;
                const timeStr = orderDate.toLocaleTimeString('zh-CN', {
                  hour: '2-digit',
                  minute: '2-digit'
                });
                const time = `${dateStr} ${timeStr}`;

                // 获取商品信息，计算商品种类数量
                let itemsData = [];
                if (order.order_items && Array.isArray(order.order_items)) {
                  itemsData = order.order_items;
                } else if (order.items && Array.isArray(order.items)) {
                  itemsData = order.items;
                }
                
                // 计算商品种类数量（不同商品的数量）
                const itemCount = itemsData.length || 0;
                const foodsText = itemCount > 0 ? `共${itemCount}样商品` : '暂无商品';

                return {
                  id: order.order_no,
                  status: statusMap[order.status] || order.status,
                  foods: foodsText,
                  time: time,
                  amount: parseFloat(order.total_amount || 0).toFixed(2),
                  created_at: order.created_at // 保留原始时间戳用于排序
                };
              });
              
              this.setData({
                recentOrders: formattedOrders
              });
              console.log('成功处理订单数据，共', formattedOrders.length, '条（最近3个订单）');
            } else {
              console.warn('订单数组为空或未找到有效数组:', data.orders);
              this.setData({
                recentOrders: []
              });
            }
          } else {
            console.error('订单数据格式错误:', data);
            console.error('orders字段:', data.orders);
            console.error('orders类型:', typeof data.orders);
            this.setData({
              recentOrders: []
            });
          }
        } else {
          console.error('获取订单列表失败:', res.data ? res.data.message : '未知错误');
          this.setData({
            recentOrders: []
          });
        }
      },
      fail: (error) => {
        console.error('获取订单列表失败:', error);
        this.setData({
          recentOrders: []
        });
        wx.showToast({
          title: '获取订单数据失败',
          icon: 'none'
        });
      }
    });
  },
  
  /**
   * 计算柱状图高度
   */
  calculateBarHeights: function() {
    const weeklyRevenue = this.data.weeklyRevenue;
    if (!weeklyRevenue || weeklyRevenue.length === 0) return;
    
    // 获取最大值
    let maxValue = 0;
    weeklyRevenue.forEach(item => {
      if (item.value > maxValue) {
        maxValue = item.value;
      }
    });
    
    // 计算相对高度（以最大值为基准，设置最大高度为容器高度的80%）
    const chartHeight = 200; // 图表容器的80%高度，单位rpx
    const updatedRevenue = weeklyRevenue.map(item => {
      const height = (item.value / maxValue) * chartHeight;
      return {
        ...item,
        relativeHeight: Math.max(height, 20) // 最小高度为20rpx，确保数据为0时也能看到柱子
      };
    });
    
    this.setData({
      weeklyRevenue: updatedRevenue
    });
  },

  /**
   * 从后端获取营业状态
   */
  fetchBusinessStatus: function() {
    const that = this;
    
    // 显示加载状态
    wx.showLoading({
      title: '获取状态中...',
      mask: true
    });
    
    merchantAPI.getBusinessStatus()
      .then(res => {
        wx.hideLoading();
        
        console.log('营业状态API返回完整数据:', res);
        
        if (res.success) {
          const isOpen = res.data.is_open_boolean;
          console.log('获取营业状态成功:', isOpen);
          
          that.setData({
            isOpen: isOpen,
            businessStatusInitialized: true
          });
        } else {
          console.error('获取营业状态失败:', res.message);
          // 获取失败时，保持当前状态，仅标记为已初始化避免重复请求
          that.setData({
            businessStatusInitialized: true
          });
          wx.showToast({
            title: '获取状态失败',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(err => {
        wx.hideLoading();
        
        // 更健壮的错误处理
        let errorMessage = '网络错误';
        if (err) {
          if (err.message) {
            errorMessage = err.message;
          } else if (err.originalError?.errMsg) {
            errorMessage = err.originalError.errMsg;
          } else if (typeof err === 'string') {
            errorMessage = err;
          } else if (err.response?.data?.message) {
            errorMessage = err.response.data.message;
          } else if (err.statusCode) {
            errorMessage = `错误码: ${err.statusCode}`;
          }
        }
        
        console.error('获取营业状态失败:', err);
        console.error('错误详情:', errorMessage);
        
        // 错误情况下也标记为已初始化，避免重复请求
        that.setData({
          businessStatusInitialized: true
        });
        
        wx.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 2000
        });
      });
  },

  /**
   * 切换营业状态
   */
  toggleBusinessStatus: function () {
    const that = this;
    const currentStatus = this.data.isOpen;
    const newStatus = !currentStatus;
    
    // 显示操作中提示
    wx.showLoading({
      title: newStatus ? '正在开店...' : '正在打烊...',
      mask: true
    });
    
    console.log('开始切换营业状态:', { from: currentStatus, to: newStatus });
    
    merchantAPI.updateBusinessStatus(newStatus)
      .then(res => {
        wx.hideLoading();
        
        console.log('营业状态更新响应:', res);
        
        if (res && res.success) {
          console.log('更新营业状态成功:', newStatus);
          
          // 更新本地状态
          that.setData({
            isOpen: newStatus
          });
          
          // 使用统一的同步方法
          that.syncBusinessStatusToOtherPages(newStatus);
          
          // 显示成功消息
          wx.showToast({
            title: newStatus ? '已开店' : '已打烊',
            icon: 'success',
            duration: 1500
          });
        } else {
          // 获取更详细的错误信息
          const errorMsg = res?.message || res?.data?.message || '未知错误';
          const errorCode = res?.statusCode || 'N/A';
          
          console.error('更新营业状态失败:', {
            success: res?.success,
            statusCode: errorCode,
            message: errorMsg,
            fullResponse: res
          });
          
          // 显示错误信息
          wx.showToast({
            title: errorMsg || '更新状态失败',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(err => {
        wx.hideLoading();
        
        console.error('更新营业状态失败:', err);
        
        // 处理网络错误或异常
        let errorMessage = '网络错误';
        if (err.message) {
          errorMessage = err.message;
        } else if (err.originalError?.errMsg) {
          errorMessage = err.originalError.errMsg;
        } else if (typeof err === 'string') {
          errorMessage = err;
        }
        
        // 网络错误提示
        wx.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 2000
        });
      });
  },

  /**
   * 统一同步营业状态到其他页面
   */
  syncBusinessStatusToOtherPages: function(newStatus) {
    const debugInfo = [];
    const that = this;
    
    try {
      // 方法1：通过页面栈同步状态
      const pages = getCurrentPages();
      debugInfo.push(`当前页面栈深度: ${pages.length}`);
      
      pages.forEach((page, index) => {
        if (page.route === 'pages/restaurant/index' || page.route === 'pages/restaurant/res_profile') {
          debugInfo.push(`同步页面: ${page.route} (索引: ${index})`);
          
          // 更新目标页面的状态
          if (page.setData && typeof page.setData === 'function') {
            try {
              page.setData({
                isOpen: newStatus
              });
              debugInfo.push(`成功更新 ${page.route} 页面状态`);
            } catch (pageError) {
              debugInfo.push(`更新 ${page.route} 页面状态失败: ${pageError.message}`);
            }
          }
        }
      });
      
      // 方法2：使用全局数据同步
      const app = getApp();
      if (app && app.globalData) {
        app.globalData.merchantBusinessStatus = newStatus;
        debugInfo.push('已更新全局数据状态');
      }
      
      // 方法3：使用存储同步（作为备用方案）
      try {
        wx.setStorageSync('merchantBusinessStatus', {
          isOpen: newStatus,
          timestamp: Date.now()
        });
        debugInfo.push('已存储同步状态到本地');
      } catch (storageError) {
        debugInfo.push(`存储同步状态失败: ${storageError.message}`);
      }
      
      // 输出调试信息
      console.log('营业状态同步完成:', {
        newStatus,
        debug: debugInfo
      });
      
    } catch (syncError) {
      console.error('同步营业状态时发生错误:', syncError);
      
      // 即使同步失败，也不影响主流程
      wx.showToast({
        title: '状态同步异常，但操作已生效',
        icon: 'none',
        duration: 2000
      });
    }
  },

  /**
   * 查看通知
   */
  checkNotifications: function() {
    this.goToNotifications();
  },

  /**


  /**
   * 跳转到餐品管理页面
   */
  goToMenuManagement: function() {
    wx.navigateTo({
      url: '/pages/restaurant/res_menu'
    });
  },

  /**
   * 跳转到库存管理页面
   */
  goToStockManagement: function() {
    wx.showToast({
      title: '功能待开发',
      icon: 'none'
    });
    // 实际应用中应跳转到库存管理页面
  },

  /**
   * 跳转到任务发布页面（restaurant/task）
   */
  goToTaskPage: function () {
    wx.navigateTo({
      url: '/pages/restaurant/task'
    });
  },

  /**
   * 跳转到营销活动页面
   */
  goToPromotion: function() {
    wx.showToast({
      title: '营销活动功能待开发',
      icon: 'none'
    });
    // 实际应用中应跳转到营销活动页面
  },

  /**
   * 跳转到消息通知页面
   */
  goToNotifications: function() {
    wx.navigateTo({
      url: '/pages/restaurant/res_notifications'
    });
  },

  /**
   * 跳转到财务报表页面
   */
  goToFinancialReport: function() {
    wx.showToast({
      title: '财务报表功能待开发',
      icon: 'none'
    });
    // 实际应用中应跳转到财务报表页面
  },

  /**
   * 跳转到订单详情页面
   */
  goToOrderDetail: function(e) {
    const orderId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/restaurant/res_orders?orderId=${orderId}`
    });
  },

  /**
   * 跳转到退单投诉页面
   */
  goToComplaints: function() {
    wx.navigateTo({
      url: '/pages/restaurant/res_complaints'
    });
  }

});