// pages/restaurant/task_order.js
// 任务订单/详情页面：配送类任务显示订单列表，其他任务显示详情

const { get } = require('../../utils/request');

Page({
  data: {
    taskId: '',
    loading: true,
    error: '',
    taskInfo: {},
    orders: [],
    isDeliveryTask: false
  },

  onLoad(options) {
    const taskId = options.taskId;
    if (!taskId) {
      wx.showToast({ title: '缺少任务ID', icon: 'none' });
      wx.navigateBack();
      return;
    }

    wx.setNavigationBarTitle({
      title: '任务详情'
    });

    this.setData({ taskId });
    this.loadData();
  },

  // 加载任务数据和订单列表
  loadData() {
    this.setData({ loading: true, error: '' });
    
    get(`/tasks/${this.data.taskId}/orders`)
      .then(res => {
        console.log('任务订单接口返回:', res);
        if (res && res.success && res.data) {
          const { task, orders = [] } = res.data;
          
          // 判断是否为配送类任务
          const isDeliveryTask = task.task_type === '配送';
          
          // 格式化任务信息
          const taskInfo = {
            ...task,
            statusText: this.mapStatus(task.status)
          };
          
          // 格式化订单信息 - 根据后端返回的真实字段结构
          const formattedOrders = orders.map(order => {
            // 后端返回的字段：order_id, order_no, status, delivery_address, recipient_name, recipient_phone, total_amount, delivery_fee, created_at, updated_at, order_type, remark, assigned_volunteer_id, volunteer_delivery_status, accept_time, pickup_time, delivery_time, volunteer_name
            return {
              id: order.order_id, // 统一使用 id 作为订单ID，用于跳转
              order_id: order.order_id,
              order_no: order.order_no || '',
              status: order.status || '',
              statusText: this.mapOrderStatus(order.status),
              delivery_address: (() => {
                const { formatAddressOnly } = require('../../utils/addressUtils');
                return formatAddressOnly(order.delivery_address || '');
              })(),
              recipient_name: order.recipient_name || '未填写',
              recipient_phone: order.recipient_phone || '未填写',
              total_amount: order.total_amount ? parseFloat(order.total_amount).toFixed(2) : '0.00',
              delivery_fee: order.delivery_fee ? parseFloat(order.delivery_fee).toFixed(2) : '0.00',
              created_at: this.formatDateTime(order.created_at),
              updated_at: this.formatDateTime(order.updated_at),
              order_type: order.order_type || '',
              remark: order.remark || '',
              assigned_volunteer_id: order.assigned_volunteer_id || null,
              volunteer_delivery_status: order.volunteer_delivery_status || '',
              volunteer_name: order.volunteer_name || '',
              accept_time: order.accept_time ? this.formatDateTime(order.accept_time) : '',
              pickup_time: order.pickup_time ? this.formatDateTime(order.pickup_time) : '',
              delivery_time: order.delivery_time ? this.formatDateTime(order.delivery_time) : ''
            };
          });
          
          console.log('格式化后的订单数据:', formattedOrders);
          
          this.setData({
            taskInfo,
            orders: formattedOrders,
            isDeliveryTask,
            loading: false
          });
        } else {
          this.setData({
            loading: false,
            error: res?.message || '获取数据失败'
          });
        }
      })
      .catch(err => {
        console.error('加载数据失败:', err);
        this.setData({
          loading: false,
          error: err?.message || '网络错误，请稍后重试'
        });
      });
  },

  // 查看订单详情（跳转到vol_task_detail页面）
  viewOrderDetail(e) {
    const orderId = e.currentTarget.dataset.orderid;
    if (!orderId) {
      wx.showToast({ title: '缺少订单ID', icon: 'none' });
      return;
    }
    
    wx.navigateTo({
      url: `/pages/volunteer/vol_task_detail?orderId=${orderId}`
    });
  },

  // 格式化日期时间
  formatDateTime(value) {
    if (!value) return '';
    try {
      const date = new Date(value);
      if (isNaN(date.getTime())) return value;
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, '0');
      const d = String(date.getDate()).padStart(2, '0');
      const h = String(date.getHours()).padStart(2, '0');
      const min = String(date.getMinutes()).padStart(2, '0');
      return `${y}-${m}-${d} ${h}:${min}`;
    } catch (e) {
      return value;
    }
  },

  // 映射任务状态
  mapStatus(status) {
    const statusMap = {
      1: '待接取',
      2: '进行中',
      3: '已完成',
      4: '已取消'
    };
    return statusMap[status] || '未知状态';
  },

  // 映射订单状态（根据新的状态表）
  mapOrderStatus(status) {
    const statusMap = {
      'pending': '待付款',
      'cancelled': '已取消',
      'refunded': '已退款',
      'paid': '顾客已下单',
      'customer_accepted': '顾客已确认',
      'merchant_accepted': '商家已接单',
      'waiting_volunteer': '等待志愿者接单',
      'volunteer_accepted': '志愿者已接单',
      'arrived_restaurant': '已到达餐厅',
      'shipped': '配送中',
      'delivered': '已送达',
      'completed': '已完成'
    };
    return statusMap[status] || status || '未知状态';
  }
});

