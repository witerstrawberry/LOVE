const { notificationAPI } = require('../../utils/api');
const { getApiUrl } = require('../../utils/config');

Page({
  data: {
    loading: false,
    submitting: false,
    merchantMessages: [],
    systemMessages: [],
    form: {
      title: '',
      content: ''
    },
    editingId: null,
    currentMerchantId: '',
    showModal: false
  },

  onLoad() {
    this.ensureMerchantInfo().then(() => {
      this.loadNotifications();
    });
  },

  onPullDownRefresh() {
    this.loadNotifications().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  openCreateModal() {
    this.loadDraft();
    this.setData({
      showModal: true,
      editingId: null
    });
  },

  closeModal() {
    this.setData({
      showModal: false,
      editingId: null,
      form: {
        title: '',
        content: ''
      }
    });
  },

  normalizeMerchantId(id) {
    if (!id) return '';
    const str = id.toString().trim();
    return str.startsWith('MER') ? str : `MER${str}`;
  },

  async ensureMerchantInfo() {
    const cachedInfo = wx.getStorageSync('merchantInfo');
    if (cachedInfo && cachedInfo.id) {
      const normalizedId = this.normalizeMerchantId(cachedInfo.id);
      this.setData({ currentMerchantId: normalizedId });
      if (normalizedId !== cachedInfo.id) {
        wx.setStorageSync('merchantInfo', { ...cachedInfo, id: normalizedId });
      }
      return;
    }

    return new Promise((resolve) => {
      wx.request({
        url: getApiUrl('/merchant/private/info'),
        method: 'GET',
        header: {
          'content-type': 'application/json',
          'Authorization': wx.getStorageSync('token') || ''
        },
        success: (res) => {
          if (res.data && res.data.success && res.data.data && res.data.data.id) {
            const merchantData = res.data.data;
            const normalizedId = this.normalizeMerchantId(merchantData.id);
            wx.setStorageSync('merchantInfo', { ...merchantData, id: normalizedId });
            this.setData({ currentMerchantId: normalizedId });
          }
        },
        complete: () => resolve()
      });
    });
  },

  getCurrentMerchantId() {
    if (this.data.currentMerchantId) return this.data.currentMerchantId;
    const info = wx.getStorageSync('merchantInfo');
    if (info && info.id) {
      const normalizedId = this.normalizeMerchantId(info.id);
      this.setData({ currentMerchantId: normalizedId });
      if (normalizedId !== info.id) {
        wx.setStorageSync('merchantInfo', { ...info, id: normalizedId });
      }
      return normalizedId;
    }
    return '';
  },

  loadNotifications() {
    const merchantId = this.getCurrentMerchantId();
    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      return Promise.resolve();
    }
    this.setData({ loading: true });
    return notificationAPI.getNotifications({
      merchant_id: merchantId,
      include_system: true
    })
      .then(res => {
        if (res && res.success && res.data && Array.isArray(res.data.notifications)) {
          const notifications = res.data.notifications.map(item => ({
            ...item,
            displayTime: this.formatTime(item.created_at || item.createdAt)
          }));
          const merchantMessages = notifications.filter(item => item.type === 'merchant');
          const systemMessages = notifications.filter(item => item.type === 'system');
          this.setData({
            merchantMessages,
            systemMessages
          });
        } else {
          wx.showToast({ title: '获取通知失败', icon: 'none' });
        }
      })
      .catch(err => {
        console.error('获取通知失败:', err);
        wx.showToast({ title: '网络错误，获取失败', icon: 'none' });
      })
      .finally(() => {
        this.setData({ loading: false });
      });
  },

  formatTime(timeStr) {
    if (!timeStr) return '';
    const date = new Date(timeStr);
    if (isNaN(date.getTime())) return timeStr;
    const y = date.getFullYear();
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const d = date.getDate().toString().padStart(2, '0');
    const hh = date.getHours().toString().padStart(2, '0');
    const mm = date.getMinutes().toString().padStart(2, '0');
    return `${y}-${m}-${d} ${hh}:${mm}`;
  },

  onFormInput(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      form: {
        ...this.data.form,
        [field]: value
      }
    });
  },

  submitMessage() {
    const merchantId = this.getCurrentMerchantId();
    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      return;
    }

    const { title, content } = this.data.form;
    if (!title.trim()) {
      wx.showToast({ title: '请输入标题', icon: 'none' });
      return;
    }
    if (!content.trim()) {
      wx.showToast({ title: '请输入内容', icon: 'none' });
      return;
    }

    const payload = {
      title: title.trim(),
      content: content.trim(),
      merchant_id: merchantId
    };

    this.setData({ submitting: true });
    const request = this.data.editingId
      ? notificationAPI.updateNotification(this.data.editingId, payload)
      : notificationAPI.createNotification(payload);

    request
      .then(res => {
        if (res && res.success) {
          wx.showToast({ title: this.data.editingId ? '已更新' : '发布成功', icon: 'success' });
          this.clearDraft();
          this.closeModal();
          this.loadNotifications();
        } else {
          wx.showToast({ title: res?.message || '操作失败', icon: 'none' });
        }
      })
      .catch(err => {
        console.error('提交通知失败:', err);
        wx.showToast({ title: '提交失败，请检查网络', icon: 'none' });
      })
      .finally(() => {
        this.setData({ submitting: false });
      });
  },

  startEdit(e) {
    const id = Number(e.currentTarget.dataset.id);
    const target = this.data.merchantMessages.find(item => Number(item.id) === id);
    if (!target) return;
    this.setData({
      showModal: true,
      editingId: id,
      form: {
        title: target.title,
        content: target.content
      }
    });
  },

  cancelEdit() {
    this.closeModal();
  },

  deleteMessage(e) {
    const id = Number(e.currentTarget.dataset.id);
    if (!id) return;
    const merchantId = this.getCurrentMerchantId();
    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      return;
    }
    const normalizedId = this.normalizeMerchantId(merchantId);

    wx.showModal({
      title: '删除提示',
      content: '确定要删除该条通知吗？',
      success: (res) => {
        if (res.confirm) {
          notificationAPI.deleteNotification(id, { merchant_id: normalizedId })
            .then(resp => {
              if (resp && resp.success) {
                wx.showToast({ title: '已删除', icon: 'success' });
                this.loadNotifications();
              } else {
                wx.showToast({ title: resp?.message || '删除失败', icon: 'none' });
              }
            })
            .catch(err => {
              console.error('删除通知失败:', err);
              wx.showToast({ title: '删除失败，请检查网络', icon: 'none' });
            });
        }
      }
    });
  },

  saveDraft() {
    wx.setStorageSync('notificationDraft', this.data.form);
    wx.showToast({ title: '已暂存', icon: 'success' });
  },

  loadDraft() {
    const draft = wx.getStorageSync('notificationDraft');
    if (draft && draft.title !== undefined && draft.content !== undefined) {
      this.setData({ form: draft });
    } else {
      this.setData({ form: { title: '', content: '' } });
    }
  },

  clearDraft() {
    try {
      wx.removeStorageSync('notificationDraft');
    } catch (err) {
      console.warn('清除草稿失败:', err);
    }
  }
});

