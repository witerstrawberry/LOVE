// pages/restaurant/res_detail_profile.js
// 导入API工具
const { merchantAPI } = require('../../utils/api.js');
// 导入认证工具
const { getUserInfo } = require('../../utils/auth.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageTitle: '店铺信息',
    activeTab: 'other', // 默认为其他商家信息页签
    loading: true,
    userRole: 0, // 0:未登录, 1:普通用户, 2:商家
    isMerchant: false, // 是否为商家角色
    restaurantInfo: {
      name: '',
      logo: '',
      phone: '',
      address: '',
      businessLicenseImage: '',
      restaurantImage: '',
      description: '',
      openingHours: '',
      tags: [],
      rating: 0,
      sales: 0,
      // 商家详细信息字段
      merchant_name: '',
      credit_code: '',
      legal_person: '',
      legal_phone: '',
      register_address: '',
      business_address: '',
      contact_phone: '',
      email: '',
      website: '',
      industry_type: '',
      sub_industry: '',
      establish_date: '',
      operate_period: '',
      status: 1
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('店铺信息页面加载，参数：', options);
    
    // 设置页面标题
    wx.setNavigationBarTitle({
      title: this.data.pageTitle
    });
    
    // 获取用户角色信息
    this.checkUserRole();
    
    // 获取餐厅信息
    this.fetchRestaurantInfo();
  },
  
  /**
   * 检查用户角色
   */
  checkUserRole: function() {
    try {
      console.log('开始检查用户角色');
      
      // 使用auth.js中的函数获取当前登录用户的信息
      const userInfo = getUserInfo();
      console.log('当前登录用户信息:', userInfo);
      
      // 判断用户是否已登录并有角色信息
      if (userInfo) {
        // 角色信息可能在不同的字段中，需要兼容不同的返回格式
        let role = 0;
        
        // 尝试从不同位置获取角色信息
        if (userInfo.role !== undefined) {
          role = userInfo.role;
        } else if (userInfo.userRole !== undefined) {
          role = userInfo.userRole;
        } else if (userInfo.role_id !== undefined) {
          role = userInfo.role_id;
        } else if (userInfo.data && userInfo.data.role !== undefined) {
          role = userInfo.data.role;
        }
        
        console.log('获取到的用户角色:', role);
        
        this.setData({
          userRole: role,
          isMerchant: role === 2 // 角色2为商家
        });
        
        console.log('角色检查完成，是否为商家:', role === 2);
      } else {
        console.log('未获取到用户信息或用户未登录');
        this.setData({
          userRole: 0,
          isMerchant: false
        });
      }
    } catch (error) {
      console.error('获取用户角色信息出错:', error);
      this.setData({
        userRole: 0,
        isMerchant: false
      });
    }
  },

  /**
   * 切换页签
   */
  switchTab: function(e) {
    const tab = e.currentTarget.dataset.tab;
    console.log('切换页签至：', tab);
    
    this.setData({
      activeTab: tab
    });
  },
  
  /**
   * 拨打电话
   */
  makePhoneCall: function() {
    const phone = this.data.restaurantInfo.phone;
    if (phone) {
      wx.makePhoneCall({
        phoneNumber: phone
      });
    } else {
      wx.showToast({
        title: '暂无联系电话',
        icon: 'none'
      });
    }
  },
  
  /**
   * 拨打法人电话
   */
  makeLegalPhoneCall: function() {
    const phone = this.data.restaurantInfo.legal_phone;
    if (phone) {
      wx.makePhoneCall({
        phoneNumber: phone
      });
    } else {
      wx.showToast({
        title: '暂无法人联系电话',
        icon: 'none'
      });
    }
  },
  
  /**
   * 拨打商家联系电话
   */
  makeContactPhoneCall: function() {
    const phone = this.data.restaurantInfo.contact_phone;
    if (phone) {
      wx.makePhoneCall({
        phoneNumber: phone
      });
    } else {
      wx.showToast({
        title: '暂无商家联系电话',
        icon: 'none'
      });
    }
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('店铺信息页面显示');
    // 重新检查用户角色，确保最新状态
    this.checkUserRole();
    // 重新获取商家信息，确保显示最新数据
    this.fetchRestaurantInfo();
  },
  
  /**
   * 编辑基本信息
   */
  editBasicInfo: function() {
    console.log('编辑基本信息');
    // 跳转到编辑页面
    wx.navigateTo({
      url: '/pages/restaurant/edit_restaurant_info?type=basic'
    });
  },
  
  /**
   * 编辑其他商家信息
   */
  editOtherInfo: function() {
    console.log('编辑商家详细信息');
    // 跳转到编辑页面（使用merchant类型）
    wx.navigateTo({
      url: '/pages/restaurant/edit_restaurant_info?type=merchant'
    });
  },
  
  /**
   * 编辑营业资格证
   */
  editLicenseImage: function() {
    console.log('编辑营业资格证');
    // 跳转到编辑页面
    wx.navigateTo({
      url: '/pages/restaurant/edit_restaurant_info?type=license'
    });
  },
  
  /**
   * 编辑店铺实景
   */
  editRestaurantImage: function() {
    console.log('编辑店铺实景');
    // 跳转到编辑页面
    wx.navigateTo({
      url: '/pages/restaurant/edit_restaurant_info?type=restaurant'
    });
  },

  /**
   * 获取餐厅信息
   */
  fetchRestaurantInfo: function() {
    const that = this;
    
    // 调用后端API获取餐厅信息
    merchantAPI.getMerchantInfo().then(res => {
      console.log('获取餐厅信息成功:', res);
      
      if (res.success && res.data) {
        console.log('API原始数据字段:', Object.keys(res.data));
        console.log('餐厅名称:', res.data.name);
        console.log('联系电话:', res.data.phone);
        console.log('营业时间:', res.data.business_hours);
        console.log('销售量:', res.data.sales_volume);
        
        // 更新页面数据 - 使用API返回的完整数据，包括所有商家信息字段
        console.log('正在处理商家详细信息字段映射...');
        console.log('API返回的完整数据结构:', JSON.stringify(res.data, null, 2));
        
        that.setData({
          restaurantInfo: {
            // 基础餐厅信息字段
            name: res.data.name || res.data.merchant_name || '',
            logo: res.data.logo || '',
            phone: res.data.phone || res.data.contact_phone || '',
            address: res.data.address || res.data.business_address || '',
            businessLicenseImage: res.data.business_license_image || res.data.health_license || res.data.business_license || '',
            restaurantImage: res.data.restaurant_scene_image || res.data.restaurant_image || '',
            description: res.data.description || '',
            openingHours: res.data.business_hours || res.data.opening_hours || '',
            tags: res.data.tags || [],
            rating: parseFloat(res.data.rating) || 0,
            sales: res.data.sales_volume || res.data.sales || 0,
            
            // 商家详细信息字段 - 使用API返回的真实数据
            merchant_name: res.data.merchant_name || res.data.name || '',
            credit_code: res.data.credit_code || '',
            legal_person: res.data.legal_person || res.data.contact_person || '',
            legal_phone: res.data.legal_phone || res.data.phone || '',
            register_address: res.data.register_address || res.data.address || '',
            business_address: res.data.business_address || res.data.address || '',
            contact_phone: res.data.contact_phone || res.data.phone || '',
            email: res.data.email || '', 
            website: res.data.website || '',
            industry_type: res.data.industry_type || res.data.category || '',
            sub_industry: res.data.sub_industry || '',
            establish_date: res.data.establish_date || '',
            operate_period: res.data.operate_period || res.data.business_hours || '',
            status: res.data.status || res.data.is_verified || 1
          },
          loading: false
        });
        
        console.log('页面数据已更新，restaurantInfo:', that.data.restaurantInfo);
      } else {
        // 显示错误提示
        wx.showToast({
          title: res.message || '获取餐厅信息失败',
          icon: 'none'
        });
        that.setData({ loading: false });
      }
    }).catch(error => {
      console.error('获取餐厅信息失败:', error);
      wx.showToast({
        title: '网络错误，请稍后重试',
        icon: 'none'
      });
      that.setData({ loading: false });
    
    });
  }
});