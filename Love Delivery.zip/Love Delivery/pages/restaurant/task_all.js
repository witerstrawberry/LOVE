// pages/restaurant/task_all.js
// 商家任务列表/管理页：查看当前商家发布的任务并可修改状态

const { get, put } = require('../../utils/request');

Page({
  data: {
    loading: true,
    error: '',
    tasks: [],
    // 状态选项与映射
    statusOptions: ['待接取', '进行中', '已完成', '已取消'],
    statusMap: {
      1: '待接取',
      2: '进行中',
      3: '已完成',
      4: '已取消'
    }
  },

  onLoad() {
    wx.setNavigationBarTitle({
      title: '任务管理'
    });
    this.loadTasks();
  },

  onShow() {
    this.loadTasks();
  },

  // 加载当前商家发布的任务列表（scope=mine 由后端按当前登录商家过滤）
  loadTasks() {
    this.setData({ loading: true, error: '' });
    get('/tasks', { scope: 'mine' })
      .then(res => {
        if (res && res.success && res.data && Array.isArray(res.data.tasks)) {
          const tasks = res.data.tasks.map(t => {
            const status = Number(t.status || 1);
            const text = this.data.statusMap[status] || '未知状态';
            const index = Math.max(0, Math.min(3, status - 1));
            return {
              ...t,
              _statusText: text,
              _statusIndex: index
            };
          });
          this.setData({ tasks, loading: false });
        } else {
          this.setData({
            loading: false,
            error: res?.message || '获取任务失败'
          });
        }
      })
      .catch(err => {
        console.error('加载任务失败:', err);
        this.setData({
          loading: false,
          error: err?.message || '网络错误，请稍后重试'
        });
      });
  },

  // 状态选择变更
  onStatusChange(e) {
    const taskId = e.currentTarget.dataset.id;
    const index = Number(e.detail.value);
    const newStatus = index + 1; // 1-4

    const task = this.data.tasks.find(t => t.task_id === taskId);
    if (!task) return;
    if (Number(task.status) === newStatus) return;

    wx.showModal({
      title: '修改任务状态',
      content: `确认将任务【${task.task_title}】状态修改为「${this.data.statusOptions[index]}」吗？`,
      success: (res) => {
        if (!res.confirm) {
          // 取消修改，刷新列表还原选择
          this.loadTasks();
          return;
        }
        this.updateTaskStatus(taskId, newStatus);
      }
    });
  },

  // 调用后端更新任务状态
  updateTaskStatus(taskId, status) {
    wx.showLoading({ title: '更新中...', mask: true });
    put(`/tasks/${taskId}`, { status })
      .then(res => {
        if (res && res.success) {
          wx.showToast({ title: '状态已更新', icon: 'success' });
          this.loadTasks();
        } else {
          wx.showToast({ title: res?.message || '更新失败', icon: 'none' });
          this.loadTasks();
        }
      })
      .catch(err => {
        console.error('更新任务状态失败:', err);
        wx.showToast({ title: err?.message || '网络错误', icon: 'none' });
        this.loadTasks();
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  // 查看任务详情（跳转到task_order页面）
  viewTaskDetail(e) {
    const taskId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/restaurant/task_order?taskId=${taskId}`
    });
  }
});


