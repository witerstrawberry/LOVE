// pages/restaurant/res_menu.js - 商家餐品管理页面
// 商家餐品管理页面
const api = require('../../utils/api.js');
const { productAPI, merchantAPI } = api;
const { getFullImageUrl } = require('../../utils/imageUtils');
const app = getApp();

Page({
  data: {
    pageTitle: '餐品管理',
    // 当前激活的标签页
    activeTab: 'menu',
    
    // 菜单分类
    menuCategories: [], // 从后端获取分类列表
    categories: [], // 分类名称数组
    categoryList: [], // 保存完整的分类列表
    activeCategory: '', // 当前激活的分类
    selectedCategory: 'recommend',
    currentCategoryName: '',
    
    // 所有餐品数据
    allFoodList: [], // 从后端获取所有商品数据
    menuItems: [], // 餐品列表数据
    filteredMenuItems: [], // 筛选后的餐品列表
    
    // 搜索和排序
    searchQuery: '',
    
    // 分页相关
    loading: false,
    errorMessage: '',
    hasMore: true,
    currentPage: 1,
    pageSize: 20,
    dataLoaded: false,
    
    // 对话框状态
    showAddDialog: false,
    showEditDialog: false,
    newItem: { name: '', price: '', stock: '', category_id: 1, description: '' },
    editingItem: null,
    sortBy: 'default',
    currentMerchantId: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面加载开始，获取分类和餐品数据...');
    this.ensureMerchantInfo();
    this.loadCategories();
  },

  ensureMerchantInfo: function() {
    const cachedMerchant = wx.getStorageSync('merchantInfo');
    if (cachedMerchant && cachedMerchant.id) {
      const normalizedId = this.normalizeMerchantId(cachedMerchant.id);
      if (normalizedId !== cachedMerchant.id) {
        wx.setStorageSync('merchantInfo', { ...cachedMerchant, id: normalizedId });
      }
      this.setData({ currentMerchantId: normalizedId });
      return;
    }

    merchantAPI.getMerchantInfo()
      .then(res => {
        if (res && res.success && res.data && res.data.id) {
          const normalizedId = this.normalizeMerchantId(res.data.id);
          wx.setStorageSync('merchantInfo', { ...res.data, id: normalizedId });
          this.setData({ currentMerchantId: normalizedId });
        }
      })
      .catch(err => {
        console.error('获取商家信息失败:', err);
      });
  },

  normalizeMerchantId: function(id) {
    if (!id) return '';
    const str = id.toString().trim();
    return str.startsWith('MER') ? str : `MER${str}`;
  },

  getMerchantIdFromCache: function() {
    if (this.data.currentMerchantId) {
      return this.data.currentMerchantId;
    }
    const merchantInfo = wx.getStorageSync('merchantInfo');
    if (merchantInfo && merchantInfo.id) {
      const normalizedId = this.normalizeMerchantId(merchantInfo.id);
      this.setData({ currentMerchantId: normalizedId });
      if (normalizedId !== merchantInfo.id) {
        wx.setStorageSync('merchantInfo', { ...merchantInfo, id: normalizedId });
      }
      return normalizedId;
    }
    return '';
  },

  /**
   * 从API加载分类数据
   */
  loadCategories: function() {
    console.log('开始获取分类数据...');
    
    // 显示加载提示
    wx.showLoading({
      title: '加载分类...',
      mask: true
    });

    // 调用API获取分类列表
    productAPI.getCategories()
      .then(response => {
        console.log('获取分类数据响应:', response);
        console.log('response.success:', response.success);
        console.log('response.data:', response.data);
        
        try {
          console.log('分类API响应完整数据:', response);
          console.log('响应数据类型:', typeof response.data);
          // 打印响应数据的所有键
          console.log('响应数据对象结构:', Object.keys(response.data));
          
          // 尝试多种可能的数据路径
          if (response.success && response.data && response.data.categories && Array.isArray(response.data.categories)) {
            console.log('从response.data.categories获取到分类数据:', response.data.categories);
            // 转换分类数据格式，确保包含页面所需的字段
            const activeCategories = response.data.categories.map(cat => ({
              id: String(cat.id), // 确保ID是字符串
              name: cat.name,
              icon: '', // 图片路径已删除
              status: 'active' // 设置为active确保被显示
            }));
            console.log('转换后的分类数据:', activeCategories);
            
            // 确保至少有一个分类
            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              
              // 更新分类相关数据
              this.setData({
                menuCategories: activeCategories,
                categories: activeCategories.map(cat => cat.name),
                categoryList: activeCategories,
                selectedCategory: selectedCategoryId,
                activeCategory: selectedCategoryName,
                currentCategoryName: selectedCategoryName
              });
              console.log('设置分类成功，当前选中:', this.data.selectedCategory);
              
              // 加载该分类的商品数据
              this.loadProducts(selectedCategoryId, 1, false);
            } else {
              console.log('没有分类数据，使用默认分类');
              this.useDefaultCategories();
            }
          } else if (response.data && response.data.categories && Array.isArray(response.data.categories)) {
            console.log('从response.data.categories获取到分类数据:', response.data.categories);
            const activeCategories = response.data.categories;
            console.log('过滤后的分类(兼容格式):', activeCategories);
            
            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              this.setData({
                menuCategories: activeCategories,
                categories: activeCategories.map(cat => cat.name),
                categoryList: activeCategories,
                selectedCategory: selectedCategoryId,
                activeCategory: selectedCategoryName,
                currentCategoryName: selectedCategoryName
              });
              this.loadProducts(selectedCategoryId, 1, false);
            } else {
              this.useDefaultCategories();
            }
          } else {
            console.log('无法识别的响应格式，尝试直接使用response.data作为数组:', response.data);
            // 尝试直接使用response.data作为数组
            if (Array.isArray(response.data)) {
              console.log('response.data本身是数组，直接使用');
              const activeCategories = response.data;
              console.log('过滤后的分类(直接数组格式):', activeCategories);
              
              if (activeCategories.length > 0) {
                const selectedCategoryId = activeCategories[0]?.id || '1';
                const selectedCategoryName = activeCategories[0]?.name || '推荐';
                this.setData({
                  menuCategories: activeCategories,
                  categories: activeCategories.map(cat => cat.name),
                  categoryList: activeCategories,
                  selectedCategory: selectedCategoryId,
                  activeCategory: selectedCategoryName,
                  currentCategoryName: selectedCategoryName
                });
                this.loadProducts(selectedCategoryId, 1, false);
              } else {
                this.useDefaultCategories();
              }
            } else {
              console.log('响应数据格式不符合预期，尝试直接从response.data.categories获取数据，然后使用默认分类');
              console.log('强制使用默认分类');
              this.useDefaultCategories();
            }
          }
        } catch (error) {
          console.error('处理分类数据时发生异常:', error);
          this.useDefaultCategories();
        }
        
        // 隐藏加载提示
        wx.hideLoading();
        
        // 显示成功消息
        wx.showToast({
          title: '分类加载成功',
          icon: 'success',
          duration: 1500
        });
        
      })
      .catch(error => {
        console.error('获取分类失败:', error);
        
        // 隐藏加载提示
        wx.hideLoading();
        
        // 显示错误消息并使用默认分类
        wx.showToast({
          title: '加载分类失败，使用默认分类',
          icon: 'none',
          duration: 2000
        });
        
        // 使用默认分类作为fallback
        this.useDefaultCategories();
      });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('页面显示, 当前menuItems数量:', this.data.menuItems.length);
    // 如果数据已加载，更新筛选后的菜单数据
    if (this.data.dataLoaded) {
      this.updateFilteredMenuItems();
    }
  },

  /**
   * 从后端加载餐品数据（用于商家管理）
   * 这个方法是对 loadProducts 方法的补充，保证页面可以正确从后端获取数据
   */
  loadMenuItems: function(categoryId = null, page = 1, append = false) {
    console.log('商家管理页面加载餐品数据');
    // 直接调用已有的 loadProducts 方法
    return this.loadProducts(categoryId || '1', page, append);
  },

  /**
   * 使用默认分类数据
   */
  useDefaultCategories: function() {
    console.log('使用默认分类数据');
    const defaultCategories = [
      { id: '1', name: '推荐', status: 'active' },
      { id: '2', name: '软食', status: 'active' },
      { id: '3', name: '控糖', status: 'active' },
      { id: '4', name: '低盐', status: 'active' },
      { id: '5', name: '低脂', status: 'active' },
      { id: '6', name: '营养套餐', status: 'active' },
      { id: '7', name: '传统家常', status: 'active' },
      { id: '8', name: '主食', status: 'active' },
      { id: '9', name: '凉菜', status: 'active' },
      { id: '10', name: '汤类', status: 'active' },
      { id: '11', name: '小份菜', status: 'active' }
    ];
    this.setData({
      menuCategories: defaultCategories,
      categories: defaultCategories.map(cat => cat.name),
      categoryList: defaultCategories,
      selectedCategory: 1,
      activeCategory: 1, // 默认选中推荐分类
      currentCategoryName: '推荐'
    });
    console.log('设置默认分类成功, activeCategory:', this.data.activeCategory);
    // 加载默认分类的商品数据
    this.loadProducts('1', 1, false);
  },

  /**
   * 从后端加载商品数据
   */
  loadProducts: function(categoryId, page = 1, append = false) {
    if (this.data.loading) return;
    
    this.setData({ loading: true, errorMessage: '' });
    
    // 构建请求参数
    const params = {
      page,
      limit: this.data.pageSize  // 修改为 limit 以匹配后端期望的参数名
    };

    const merchantId = this.getMerchantIdFromCache();
    if (merchantId) {
      params.merchant_id = merchantId;
    }
    
    // 定义请求方法
    let apiCall;
    
    if (categoryId && categoryId !== 'recommend' && String(categoryId) !== '1') {
      // 根据分类获取商品，但跳过'recommend'和'1'(代表推荐)
      console.log(`根据分类${categoryId}获取商品`);
      apiCall = productAPI.getProductsByCategory(categoryId, params);
    } else {
      // 获取所有商品或推荐商品
      console.log('获取所有商品');
      apiCall = productAPI.getProducts(params);
    }
    
    // 发送请求
    return apiCall
      .then(res => {
        try {
          console.log('商品API响应完整数据:', res);
          
          // 处理不同的响应数据格式
          let products = [];
          // 打印更详细的响应数据结构
          console.log('res.data类型:', typeof res.data);
          console.log('res.data结构:', JSON.stringify(res.data));
          
          if (res.success && res.data) {
            // 处理格式: {success: true, code: 200, data: {...}, message: "", timestamp: ""}
            if (res.data.products) {
              products = res.data.products;
              console.log('从res.data.products获取商品数据:', products.length);
            } else if (res.data.list) {
              products = res.data.list;
              console.log('从res.data.list获取商品数据');
            } else if (res.data.items) {
              products = res.data.items;
              console.log('从res.data.items获取商品数据');
            } else if (res.data.products) {
              products = res.data.products;
              console.log('从res.data.products获取商品数据');
            } else if (Array.isArray(res.data)) {
              products = res.data;
              console.log('res.data是数组，直接使用');
            } else if (typeof res.data === 'object') {
              // 尝试将整个data对象作为一个商品处理
              console.log('res.data是对象但不包含list/items/products，尝试将其作为单个商品');
              products = [res.data];
            } else {
              console.error('data字段格式不正确');
              // 不使用模拟数据，设置空数组
              products = [];
            }
          } else if (res.data && res.data.list) {
            // 处理格式: {data: {list: [...]}}
            products = res.data.list;
          } else if (res.data && res.data.items) {
            // 处理格式: {data: {items: [...]}}
            products = res.data.items;
          } else if (res.data && res.data.products) {
            // 处理格式: {data: {products: [...]}}
            products = res.data.products;
          } else if (res.data && Array.isArray(res.data)) {
            // 处理格式: {data: [...]}
            products = res.data;
          } else if (Array.isArray(res)) {
            // 处理格式: [...] 直接返回数组
            products = res;
          } else {
            console.error('无法识别的响应格式');
            // 不使用模拟数据，设置空数组
            products = [];
          }
          
          console.log(`获取到${products.length}个商品`);
          
          // 标准化商品数据格式，确保包含页面所需的字段
          const standardizedProducts = products.map(product => {
            // 根据category_name映射到对应的categoryId
            let categoryId = 1; // 默认推荐
            const categoryMap = {
              '推荐': 1,
              '软食': 2,
              '控糖': 3,
              '低盐': 4,
              '低脂': 5,
              '营养套餐': 6,
              '传统家常': 7,
              '主食': 8,
              '凉菜': 9,
              '汤类': 10,
              '小份菜': 11
            };
            
            if (product.category_name && categoryMap[product.category_name]) {
              categoryId = categoryMap[product.category_name];
            }
            
            // 获取原始图片路径
            const originalImagePath = product.image || product.image_url;
            // 使用工具函数处理图片URL，确保返回正确的完整路径
            const processedImageUrl = originalImagePath ? getFullImageUrl(originalImagePath) : '../../images/default-avatar.png';
            
            return {
              id: product.id,
              category: categoryId,
              categoryId: categoryId,
              category_name: product.category_name || '推荐',
              name: product.name || '未命名商品',
              price: parseFloat(product.price || 0),
              originalPrice: product.original_price ? parseFloat(product.original_price) : null,
              image: processedImageUrl,
              image_url: processedImageUrl,
              tags: product.tags || product.tag || [],
              description: product.description || product.desc || '暂无描述',
              sales: product.sales || product.sales_count || product.view_count || 0,
              view_count: product.sales || product.sales_count || product.view_count || 0,
              stock: product.stock || 100, // 默认库存为100
              status: product.status || 'active' // 保存原始状态值
            };
          });
          
          // 更新商品列表
          let updatedFoodList;
          if (append) {
            updatedFoodList = [...this.data.allFoodList, ...standardizedProducts];
          } else {
            updatedFoodList = standardizedProducts;
          }
          
          // 检查是否还有更多数据
          const hasMore = standardizedProducts.length >= this.data.pageSize;
          
          console.log('更新商品列表，数量:', updatedFoodList.length);
          
          // 更新数据状态
          this.setData({
            allFoodList: updatedFoodList,
            menuItems: updatedFoodList, // 同时更新menuItems用于商家管理
            loading: false,
            hasMore: hasMore,
            dataLoaded: true, // 标记数据已加载
            errorMessage: '' // 清除错误信息
          });
          
          // 更新当前显示的餐品列表
          console.log('调用updateFilteredMenuItems方法');
          this.updateFilteredMenuItems();
          wx.stopPullDownRefresh();
        } catch (error) {
          console.error('处理商品数据时出错:', error);
          this.setData({
            loading: false,
            errorMessage: '处理商品数据失败',
            dataLoaded: true
          });
          wx.stopPullDownRefresh();
        }
      })
      .catch(error => {
        console.error('获取商品数据失败:', error);
        this.setData({
          loading: false,
          errorMessage: '获取商品数据失败，请重试',
          dataLoaded: true
        });
        
        // 显示错误提示
        wx.showToast({
          title: '获取商品数据失败',
          icon: 'none',
          duration: 2000
        });
        wx.stopPullDownRefresh();
      });
  },

  /**
   * 切换分类
   */
  switchCategory: function(e) {
    const categoryId = parseInt(e.currentTarget.dataset.categoryId);
    const categoryName = e.currentTarget.dataset.category;
    console.log('切换分类到:', categoryName, '(ID:', categoryId, ')');
    
    this.setData({ activeCategory: categoryId });
    console.log('设置activeCategory为:', categoryId);
    // 更新筛选后的菜单数据
    this.updateFilteredMenuItems();
  },

  /**
   * 搜索餐品
   */
  onSearch: function(e) {
    const searchQuery = e.detail.value || '';
    console.log('搜索关键词:', searchQuery);
    this.setData({ searchQuery });
    // 更新筛选后的菜单数据
    this.updateFilteredMenuItems();
  },

  /**
   * 切换排序方式
   */
  changeSortBy: function(e) {
    const sortBy = e.currentTarget.dataset.sortby;
    console.log('切换排序方式到:', sortBy);
    this.setData({ sortBy });
    // 更新筛选后的菜单数据
    this.updateFilteredMenuItems();
  },

  /**
   * 按价格排序
   */
  sortByPrice: function() {
    // 切换价格排序方向
    const newSortBy = this.data.sortBy === 'priceAsc' ? 'priceDesc' : 'priceAsc';
    console.log('切换价格排序到:', newSortBy);
    this.setData({ sortBy: newSortBy });
    // 更新筛选后的菜单数据
    this.updateFilteredMenuItems();
  },

  /**
   * 按库存排序
   */
  sortByStock: function() {
    console.log('切换到库存排序');
    this.setData({ sortBy: 'stockAsc' });
    // 更新筛选后的菜单数据
    this.updateFilteredMenuItems();
  },

  // 计算并更新筛选后的菜单数据
  updateFilteredMenuItems: function() {
    let items = [...this.data.menuItems];
    
    // 分类筛选 - 需要根据分类名称或ID筛选
    if (this.data.activeCategory) {
      // 获取当前分类的ID或名称
      const currentCategory = this.data.activeCategory;
      
      // 创建分类ID到名称的映射关系
      const categoryIdToName = {
        1: '推荐',
        2: '软食',
        3: '控糖',
        4: '低盐',
        5: '低脂',
        6: '营养套餐',
        7: '传统家常',
        8: '主食',
        9: '凉菜',
        10: '汤类',
        11: '小份菜'
      };
      
      // 如果 activeCategory 是数字类型（ID），直接用数字比较
      // 如果 activeCategory 是字符串类型（名称），需要转换为ID或使用名称比较
      if (typeof currentCategory === 'number') {
        items = items.filter(item => item.category === currentCategory);
      } else {
        // 查找当前分类名称对应的ID
        let categoryId = 1; // 默认推荐
        const entries = Object.entries(categoryIdToName);
        for (let i = 0; i < entries.length; i++) {
          const [id, name] = entries[i];
          if (name === currentCategory) {
            categoryId = parseInt(id);
            break;
          }
        }
        items = items.filter(item => item.category === categoryId);
      }
    }
    
    // 搜索筛选
    if (this.data.searchQuery) {
      const query = this.data.searchQuery.toLowerCase();
      items = items.filter(item => 
        item.name.toLowerCase().includes(query) || 
        (item.description && item.description.toLowerCase().includes(query))
      );
    }
    
    // 排序
    switch (this.data.sortBy) {
      case 'priceAsc':
        items.sort((a, b) => a.price - b.price);
        break;
      case 'priceDesc':
        items.sort((a, b) => b.price - a.price);
        break;
      case 'nameAsc':
        items.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'nameDesc':
        items.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'stockAsc':
        items.sort((a, b) => a.stock - b.stock);
        break;
      default: // 'default' 或其他未知值
        // 保持原始顺序
        break;
    }
    
    console.log('更新筛选后的菜单数据，数量:', items.length);
    console.log('当前激活分类:', this.data.activeCategory);
    this.setData({ filteredMenuItems: items });
  },

  // 仅用于向后兼容，保持getFilteredMenuItems方法
  getFilteredMenuItems: function() {
    return this.data.filteredMenuItems;
  },

  /**
   * 修改餐品库存
   */
  updateStock: function(e) {
    const { id, action } = e.currentTarget.dataset;
    const updatedItems = this.data.menuItems.map(item => {
      if (item.id === id) {
        let newStock = item.stock;
        if (action === 'increase') {
          newStock += 10;
        } else if (action === 'decrease' && item.stock > 0) {
          newStock = Math.max(0, item.stock - 10);
        }
        return { ...item, stock: newStock };
      }
      return item;
    });
    
    this.setData({ menuItems: updatedItems });
    wx.showToast({ title: '库存已更新', icon: 'success' });
  },

  /**
   * 下架/上架餐品
   */
  toggleStatus: function(e) {
    const id = e.currentTarget.dataset.id;
    const updatedItems = this.data.menuItems.map(item => {
      if (item.id === id) {
        const newStatus = item.status === 'active' ? 'inactive' : 'active';
        return { ...item, status: newStatus };
      }
      return item;
    });
    this.setData({ menuItems: updatedItems });
  },

  /**
   * 打开添加餐品对话框
   */
  openAddDialog: function() {
    this.setData({ 
      showAddDialog: true,
      newItem: { 
        name: '', 
        price: '', 
        stock: '', 
        category_id: 1, 
        sort_order: 0,
        image_url: '',
        status: 'active',
        description: ''
      }
    });
  },

  /**
   * 关闭添加餐品对话框
   */
  closeAddDialog: function() {
    this.setData({ showAddDialog: false });
  },

  /**
   * 输入新餐品信息
   */
  onInputChange: function(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    this.setData({
      [`newItem.${field}`]: value
    });
  },

  /**
   * 分类选择处理
   */
  onCategorySelect: function(e) {
    const { categoryId } = e.currentTarget.dataset;
    console.log('选择分类ID:', categoryId);
    this.setData({
      'newItem.category_id': categoryId
    });
  },

  /**
   * 状态选择处理（添加对话框）
   */
  onStatusSelect: function(e) {
    const { status } = e.currentTarget.dataset;
    this.setData({
      'newItem.status': status
    });
  },

  /**
   * 状态选择处理（编辑对话框）
   */
  onEditStatusSelect: function(e) {
    const { status } = e.currentTarget.dataset;
    this.setData({
      'editingItem.status': status
    });
  },

  /**
   * 编辑对话框中的分类选择处理
   */
  onEditCategorySelect: function(e) {
    const { categoryId } = e.currentTarget.dataset;
    console.log('编辑时选择分类ID:', categoryId);
    this.setData({
      'editingItem.category_id': categoryId
    });
  },

  /**
   * 打开编辑餐品对话框
   */
  openEditDialog: function(e) {
    const id = Number(e.currentTarget.dataset.id);
    const item = this.data.menuItems.find(item => Number(item.id) === id);
    
    if (item) {
      const normalizedStatus = item.status || 'active';
      const categoryId = item.category_id || item.category || 1;
      this.setData({
        showEditDialog: true,
        editingItem: { 
          ...item,
          id,
          category_id: categoryId,
          price: item.price !== undefined && item.price !== null ? String(item.price) : '',
          stock: item.stock !== undefined && item.stock !== null ? String(item.stock) : '',
          status: normalizedStatus,
          image_url: item.image_url || item.image || ''
        }
      });
    }
  },

  /**
   * 关闭编辑餐品对话框
   */
  closeEditDialog: function() {
    this.setData({ showEditDialog: false });
  },

  /**
   * 编辑餐品信息
   */
  onEditChange: function(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    this.setData({
      [`editingItem.${field}`]: value
    });
  },

  /**
   * 保存编辑后的餐品
   */
  updateMenuItem: function() {
    const editingItem = this.data.editingItem || {};
    const { id, name, price, stock, category_id, description, image_url, status, sort_order } = editingItem;

    if (!id) {
      wx.showToast({ title: '未选择餐品', icon: 'none' });
      return;
    }

    if (!name || price === '' || stock === '') {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
      return;
    }

    const numericPrice = Number(price);
    const numericStock = Number(stock);
    if (Number.isNaN(numericPrice) || Number.isNaN(numericStock)) {
      wx.showToast({ title: '价格或库存格式不正确', icon: 'none' });
      return;
    }

    const merchantId = this.getMerchantIdFromCache();
    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      this.ensureMerchantInfo();
      return;
    }

    const payload = {
      name: name.trim(),
      price: numericPrice,
      stock: numericStock,
      category_id: Number(category_id) || 1,
      description: description ? description.trim() : '',
      image_url: image_url || '',
      status: status || 'active',
      sort_order: Number(sort_order) || 0,
      merchant_id: this.normalizeMerchantId(merchantId)
    };

    wx.showLoading({ title: '保存中...', mask: true });
    productAPI.updateProduct(id, payload)
      .then(response => {
        wx.hideLoading();
        if (response && response.success) {
          const updatedItems = this.data.menuItems.map(item => {
            if (Number(item.id) === Number(id)) {
              return {
                ...item,
                ...payload,
                price: payload.price,
                stock: payload.stock,
                category_id: payload.category_id
              };
            }
            return item;
          });

          this.setData({
            menuItems: updatedItems,
            showEditDialog: false
          });
          this.updateFilteredMenuItems();
          wx.showToast({ title: '餐品已更新', icon: 'success' });
        } else {
          wx.showToast({ title: response?.message || '更新失败，请重试', icon: 'none' });
        }
      })
      .catch(error => {
        wx.hideLoading();
        console.error('更新餐品失败:', error);
        wx.showToast({ title: '更新失败，请检查网络', icon: 'none' });
      });
  },

  /**
   * 新增餐品上传图片
   */
  uploadNewItemImage: function() {
    this.handleImageUpload('newItem');
  },

  /**
   * 编辑餐品重新上传图片
   */
  uploadEditingItemImage: function() {
    if (!this.data.editingItem) {
      wx.showToast({ title: '请先选择餐品', icon: 'none' });
      return;
    }
    this.handleImageUpload('editingItem');
  },

  /**
   * 统一处理图片上传
   */
  handleImageUpload: function(targetKey) {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: (chooseRes) => {
        const tempFilePath = chooseRes.tempFilePaths[0];
        const { getBaseUrl } = require('../../utils/config');
        const baseUrl = getBaseUrl();
        const uploadUrl = `${baseUrl}/upload`;
        const token = wx.getStorageSync('token');

        wx.showLoading({ title: '上传中...', mask: true });
        wx.uploadFile({
          url: uploadUrl,
          filePath: tempFilePath,
          name: 'file',
          formData: { type: 'product' },
          header: token ? { 'Authorization': `Bearer ${token}` } : {},
          success: (uploadRes) => {
            wx.hideLoading();
            if (uploadRes.statusCode !== 200) {
              wx.showToast({ title: '上传失败，请重试', icon: 'none' });
              return;
            }
            let data = {};
            try {
              data = JSON.parse(uploadRes.data);
            } catch (error) {
              console.error('解析上传响应失败:', error);
            }
            if (data.success && data.data && data.data.url) {
              const imageUrl = data.data.url;
              const updateData = {};
              updateData[`${targetKey}.image_url`] = imageUrl;
              updateData[`${targetKey}.image`] = imageUrl;
              this.setData(updateData);
              wx.showToast({ title: '上传成功', icon: 'success' });
            } else {
              wx.showToast({ title: data.message || '上传失败', icon: 'none' });
            }
          },
          fail: (err) => {
            wx.hideLoading();
            console.error('上传图片失败:', err);
            wx.showToast({ title: '上传失败，请检查网络', icon: 'none' });
          }
        });
      },
      fail: (err) => {
        console.error('选择图片失败:', err);
      }
    });
  },

  /**
   * 删除餐品
   */
  deleteMenuItem: function(e) {
    const id = Number(e.currentTarget.dataset.id);
    const merchantId = this.getMerchantIdFromCache();

    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      this.ensureMerchantInfo();
      return;
    }
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个餐品吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '删除中...', mask: true });
          productAPI.deleteProduct(id, { merchant_id: this.normalizeMerchantId(merchantId) })
            .then(response => {
              wx.hideLoading();
              if (response && response.success) {
                const updatedItems = this.data.menuItems.filter(item => Number(item.id) !== id);
                this.setData({ menuItems: updatedItems });
                this.updateFilteredMenuItems();
                wx.showToast({ title: '餐品已删除', icon: 'success' });
              } else {
                wx.showToast({ title: response?.message || '删除失败，请重试', icon: 'none' });
              }
            })
            .catch(error => {
              wx.hideLoading();
              console.error('删除餐品失败:', error);
              wx.showToast({ title: '删除失败，请检查网络', icon: 'none' });
            });
        }
      }
    });
  },

  changeStatus: function(e) {
    const id = Number(e.currentTarget.dataset.id);
    const statusOptions = [
      { label: '上架', value: 'active' },
      { label: '下架', value: 'inactive' },
      { label: '售罄', value: 'sold_out' }
    ];

    wx.showActionSheet({
      itemList: statusOptions.map(option => option.label),
      success: (res) => {
        const selected = statusOptions[res.tapIndex];
        this.updateProductStatus(id, selected.value);
      }
    });
  },

  updateProductStatus: function(productId, status) {
    const merchantId = this.getMerchantIdFromCache();

    if (!merchantId) {
      wx.showToast({ title: '未获取到商家信息', icon: 'none' });
      this.ensureMerchantInfo();
      return;
    }

    wx.showLoading({ title: '更新中...', mask: true });
    productAPI.updateProduct(productId, {
      status,
      merchant_id: this.normalizeMerchantId(merchantId)
    })
      .then(response => {
        wx.hideLoading();
        if (response && response.success) {
          const updatedItems = this.data.menuItems.map(item => {
            if (Number(item.id) === Number(productId)) {
              return { ...item, status };
            }
            return item;
          });
          this.setData({ menuItems: updatedItems });
          this.updateFilteredMenuItems();
          wx.showToast({ title: '状态已更新', icon: 'success' });
        } else {
          wx.showToast({ title: response?.message || '更新失败，请重试', icon: 'none' });
        }
      })
      .catch(error => {
        wx.hideLoading();
        console.error('更新商品状态失败:', error);
        wx.showToast({ title: '更新失败，请检查网络', icon: 'none' });
      });
  },

  /**
   * 添加新餐品
   */
  addMenuItem: function() {
    const { name, price, stock, category_id, description, image_url, sort_order, status } = this.data.newItem;
    
    // 验证必要字段
    if (!name || !price || !stock) {
      wx.showToast({ 
        title: '请填写完整信息', 
        icon: 'none' 
      });
      return;
    }
    
    // 显示加载提示
    wx.showLoading({
      title: '正在添加餐品...',
      mask: true
    });
    
    // 获取商家ID（使用以MER开头的格式）
    let merchantId = this.getMerchantIdFromCache();
    
    if (!merchantId) {
      wx.hideLoading();
      wx.showToast({
        title: '未获取到商家信息，请先完善商家资料',
        icon: 'none'
      });
      this.ensureMerchantInfo();
      return;
    }
    
    merchantId = this.normalizeMerchantId(merchantId);
    
    // 构建餐品数据
    const productData = {
      name: name.trim(),
      price: Number(price),
      stock: Number(stock),
      category_id: Number(category_id),
      merchant_id: merchantId,
      description: description ? description.trim() : '',
      image_url: image_url ? image_url.trim() : '',
      sort_order: Number(sort_order) || 0,
      status: status || 'active'
    };
    
    console.log('准备添加餐品数据:', productData);
    
    // 调用后端API创建餐品
    productAPI.createProduct(productData)
      .then(response => {
        console.log('创建餐品响应:', response);
        wx.hideLoading();
        
        if (response.success) {
          // 重新加载餐品列表以显示新添加的餐品
          this.loadProducts(this.data.selectedCategory, 1, true);
          
          // 关闭对话框
          this.setData({ showAddDialog: false });
          
          wx.showToast({
            title: '餐品添加成功',
            icon: 'success',
            duration: 2000
          });
        } else {
          console.error('创建餐品失败:', response.message);
          wx.showToast({
            title: response.message || '添加失败，请重试',
            icon: 'none',
            duration: 3000
          });
        }
      })
      .catch(error => {
        console.error('创建餐品异常:', error);
        wx.hideLoading();
        
        wx.showToast({
          title: '网络错误，请检查后端服务',
          icon: 'none',
          duration: 3000
        });
      });
  },

  /**
   * 页面相关事件--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    console.log('触发下拉刷新');
    this.ensureMerchantInfo();
    this.setData({
      currentPage: 1,
      loading: false
    });
    const categoryId = this.data.selectedCategory || '1';
    this.loadProducts(categoryId, 1, false)
      .finally(() => {
        wx.stopPullDownRefresh();
        wx.showToast({
          title: '刷新完成',
          icon: 'success',
          duration: 1000
        });
      });
  }
});