// pages/restaurant/edit_restaurant_info.js
const { merchantAPI } = require('../../utils/api.js');
// 导入认证工具
const { getUserInfo } = require('../../utils/auth.js');
const { getApiUrl } = require('../../utils/config');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageTitle: '编辑餐厅信息',
    editType: 'basic', // basic, merchant, license, restaurant
    formData: {
      // 基本信息
      name: '',
      logo: '',
      phone: '',
      address: '',
      description: '',
      openingHours: '',
      tags: [],
      // 商家详细信息
      merchantName: '',
      creditCode: '',
      legalPerson: '',
      legalPhone: '',
      registerAddress: '',
      businessAddress: '',
      contactPhone: '',
      email: '',
      website: '',
      industryType: '',
      subIndustry: '',
      establishDate: '',
      operatePeriod: '',
      // 图片信息
      businessLicenseImage: '',
      restaurantImage: ''
    },
    loading: false,
    tagsInput: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const { getFullImageUrl } = require('../../utils/imageUtils');
    this.getFullImageUrl = getFullImageUrl;
    console.log('编辑页面加载，参数：', options);
    
    // 获取编辑类型
    const editType = options.type || 'basic';
    
    // 设置页面标题
    let title = '编辑餐厅信息';
    if (editType === 'basic') {
      title = '编辑基本信息';
    } else if (editType === 'merchant') {
      title = '编辑商家信息';
    } else if (editType === 'license') {
      title = '上传营业资格证';
    } else if (editType === 'restaurant') {
      title = '上传店铺实景';
    }
    
    wx.setNavigationBarTitle({
      title: title
    });
    
    this.setData({
      editType,
      pageTitle: title
    });
    
    // 获取餐厅信息
    this.fetchRestaurantInfo();
  },

  /**
   * 获取餐厅信息
   */
  fetchRestaurantInfo: function() {
    const that = this;
    that.setData({ loading: true });
    
    // 调用后端API获取餐厅信息
    merchantAPI.getMerchantInfo().then(res => {
      console.log('获取餐厅信息成功:', res);
      
      if (res.success && res.data) {
        // 更新表单数据
        that.setData({
          formData: {
            // 基本信息
            name: res.data.name || '',
            logo: res.data.logo || '',
            phone: res.data.phone || '',
            address: res.data.address || '',
            description: res.data.description || '',
            openingHours: res.data.opening_hours || '',
            tags: res.data.tags || [],
            // 商家详细信息
            merchantName: res.data.merchant_name || '',
            creditCode: res.data.credit_code || '',
            legalPerson: res.data.legal_person || '',
            legalPhone: res.data.legal_phone || '',
            registerAddress: res.data.register_address || '',
            businessAddress: res.data.business_address || '',
            contactPhone: res.data.contact_phone || '',
            email: res.data.email || '',
            website: res.data.website || '',
            industryType: res.data.industry_type || '',
            subIndustry: res.data.sub_industry || '',
            establishDate: res.data.establish_date || '',
            operatePeriod: res.data.operate_period || '',
            // 图片信息
            businessLicenseImage: res.data.business_license_image || '',
            restaurantImage: res.data.restaurant_image || ''
          },
          loading: false
        });
      } else {
        // 显示错误提示
        wx.showToast({
          title: res.message || '获取餐厅信息失败',
          icon: 'none'
        });
        that.setData({ loading: false });
      }
    }).catch(error => {
      console.error('获取餐厅信息失败:', error);
      wx.showToast({
        title: '网络错误，请稍后重试',
        icon: 'none'
      });
      that.setData({ loading: false });
    });
  },

  /**
   * 表单输入处理
   */
  onInputChange: function(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    
    this.setData({
      [`formData.${field}`]: value
    });
  },

  /**
   * 标签输入处理
   */
  onTagsInput: function(e) {
    this.setData({
      tagsInput: e.detail.value
    });
  },

  /**
   * 添加标签
   */
  addTag: function() {
    const { tagsInput, formData } = this.data;
    
    if (tagsInput && tagsInput.trim()) {
      const newTag = tagsInput.trim();
      if (!formData.tags.includes(newTag)) {
        const updatedTags = [...formData.tags, newTag];
        
        this.setData({
          'formData.tags': updatedTags,
          tagsInput: ''
        });
      } else {
        wx.showToast({
          title: '该标签已存在',
          icon: 'none'
        });
      }
    }
  },

  /**
   * 删除标签
   */
  removeTag: function(e) {
    const index = e.currentTarget.dataset.index;
    const { formData } = this.data;
    
    const updatedTags = formData.tags.filter((_, i) => i !== index);
    
    this.setData({
      'formData.tags': updatedTags
    });
  },

  /**
   * 上传图片
   */
  uploadImage: function(e) {
    const that = this;
    const imageType = e.currentTarget.dataset.type; // logo, license, restaurant
    
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        const tempFilePath = res.tempFilePaths[0];
        console.log('选择的图片:', tempFilePath);
        
        wx.showLoading({
          title: '上传中...',
        });
        
        // 上传图片到服务器
        wx.uploadFile({
          url: getApiUrl('/upload'),
          filePath: tempFilePath,
          name: 'file',
          formData: {
            type: imageType // 传递文件类型：logo, license, restaurant
          },
          header: {
            'Authorization': `Bearer ${wx.getStorageSync('token')}`
          },
          success: function(uploadRes) {
            try {
              const data = JSON.parse(uploadRes.data);
              if (data.success) {
                // 使用getFullImageUrl处理图片URL，确保替换localhost:3000为正确的云服务器域名
                const imageUrl = that.getFullImageUrl(data.data.url);
                // 根据类型更新对应的图片字段
                if (imageType === 'logo') {
                  that.setData({ 'formData.logo': imageUrl });
                } else if (imageType === 'license') {
                  that.setData({ 'formData.businessLicenseImage': imageUrl });
                } else if (imageType === 'restaurant') {
                  that.setData({ 'formData.restaurantImage': imageUrl });
                }
                
                wx.showToast({
                  title: '上传成功',
                  icon: 'success'
                });
              } else {
                wx.showToast({
                  title: data.message || '上传失败',
                  icon: 'none'
                });
              }
            } catch (error) {
              console.error('解析上传响应失败:', error);
              wx.showToast({
                title: '上传响应格式错误',
                icon: 'none'
              });
            }
          },
          fail: function(error) {
            console.error('上传图片失败:', error);
            wx.showToast({
              title: '上传失败，请重试',
              icon: 'none'
            });
          },
          complete: function() {
            wx.hideLoading();
          }
        });
      }
    });
  },

  /**
   * 保存修改
   */
  saveChanges: function() {
    const that = this;
    const { editType, formData } = this.data;
    
    that.setData({ loading: true });
    
    // 根据编辑类型准备提交数据
    let submitData = {};
    
    if (editType === 'basic') {
      // 验证基本信息
      if (!formData.name.trim()) {
        wx.showToast({ title: '请输入餐厅名称', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.phone.trim()) {
        wx.showToast({ title: '请输入联系电话', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.address.trim()) {
        wx.showToast({ title: '请输入餐厅地址', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      
      submitData = {
        name: formData.name,
        logo: formData.logo,
        phone: formData.phone,
        address: formData.address
      };
    } else if (editType === 'merchant') {
      // 验证商家信息
      if (!formData.merchantName.trim()) {
        wx.showToast({ title: '请输入商家全称', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.creditCode.trim()) {
        wx.showToast({ title: '请输入统一社会信用代码', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.legalPerson.trim()) {
        wx.showToast({ title: '请输入法定代表人姓名', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.registerAddress.trim()) {
        wx.showToast({ title: '请输入注册地址', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.contactPhone.trim()) {
        wx.showToast({ title: '请输入商家联系电话', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      if (!formData.industryType.trim()) {
        wx.showToast({ title: '请输入行业分类', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      
      submitData = {
        merchant_name: formData.merchantName,
        credit_code: formData.creditCode,
        legal_person: formData.legalPerson,
        legal_phone: formData.legalPhone,
        register_address: formData.registerAddress,
        business_address: formData.businessAddress,
        contact_phone: formData.contactPhone,
        email: formData.email,
        website: formData.website,
        industry_type: formData.industryType,
        sub_industry: formData.subIndustry,
        establish_date: formData.establishDate,
        operate_period: formData.operatePeriod
      };
    } else if (editType === 'license') {
      if (!formData.businessLicenseImage) {
        wx.showToast({ title: '请上传营业资格证', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      submitData = {
        business_license_image: formData.businessLicenseImage
      };
    } else if (editType === 'restaurant') {
      if (!formData.restaurantImage) {
        wx.showToast({ title: '请上传店铺实景图', icon: 'none' });
        that.setData({ loading: false });
        return;
      }
      submitData = {
        restaurant_image: formData.restaurantImage
      };
    }
    
    // 先获取当前完整的商家信息，再合并修改的字段
    merchantAPI.getMerchantInfo().then(getRes => {
      if (getRes.success && getRes.data) {
        // 合并提交数据与现有数据，保留原有必填字段
        const mergedData = {
          // 复制现有数据中的必填字段
          business_hours: getRes.data.business_hours || '',
          category: getRes.data.category || '',
          name: getRes.data.name || '',
          phone: getRes.data.phone || '',
          address: getRes.data.address || '',
          // 合并当前编辑页面的提交数据
          ...submitData
        };
        
        // 调用更新API
        return merchantAPI.updateMerchantInfo(mergedData);
      } else {
        throw new Error('获取商家信息失败');
      }
    }).then(updateRes => {
      console.log('更新餐厅信息成功:', updateRes);
      that.setData({ loading: false });
      
      if (updateRes.success) {
        wx.showToast({
          title: '保存成功',
          icon: 'success',
          duration: 1500,
          success: function() {
            // 延迟返回上一页
            setTimeout(() => {
              wx.navigateBack();
            }, 1500);
          }
        });
      } else {
        wx.showToast({
          title: updateRes.message || '保存失败',
          icon: 'none'
        });
      }
    }).catch(error => {
      console.error('更新餐厅信息失败:', error);
      wx.showToast({
        title: '网络错误，请稍后重试',
        icon: 'none'
      });
      that.setData({ loading: false });
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // 可以在这里添加刷新逻辑
  },
  
  /**
   * 取消编辑
   */
  onCancel: function() {
    wx.navigateBack();
  }
});