// pages/restaurant/res_orders.js - 商家订单管理页面
const { orderAPI, merchantAPI, authAPI } = require('../../utils/api');
const { getApiUrl } = require('../../utils/config');
const { formatAddressOnly } = require('../../utils/addressUtils');

Page({
  /**
   * 设置页面自定义tabBar
   */
  getTabBar: function () {
    return this.selectComponent('#restaurant-tab-bar');
  },

  /**
   * 页面的初始数据
   */
  data: {
    pageTitle: '订单管理',
    activeFilter: 'all',
    orders: [],
    filteredOrders: [],
    pagination: {
      page: 1,
      limit: 10,
      total: 0,
      totalPages: 0,
      isLoading: false
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面加载，开始获取订单数据');
    this.setData({
      'pagination.page': 1,
      'pagination.isLoading': false
    });
    this.refreshOrders();
  },

  /**
   * 切换订单筛选条件
   */
  switchFilter: function(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({
      activeFilter: filter
    });
    this.filterOrders();
  },
  /**
   * 根据当前筛选条件过滤订单
   */
  filterOrders: function() {
    const { orders, activeFilter } = this.data;
    console.log('筛选订单:', { totalOrders: orders.length, filter: activeFilter });
    let filteredOrders = orders;    
    if (activeFilter !== 'all') {
      // 筛选时直接使用英文状态码匹配数据库字段
      // 特殊处理：已取消/退款需要同时筛选 cancelled 和 refunded
      if (activeFilter === 'cancelled') {
        filteredOrders = orders.filter(order => {
          return order.status === 'cancelled' || order.status === 'refunded';
        });
      } else if (activeFilter === 'paid') {
        // 待处理：包含 paid, customer_accepted, merchant_accepted, waiting_volunteer
        filteredOrders = orders.filter(order => {
          return ['paid', 'customer_accepted', 'merchant_accepted', 'waiting_volunteer'].includes(order.status);
        });
      } else if (activeFilter === 'volunteer_accepted') {
        // 配送中：包含 volunteer_accepted, arrived_restaurant, shipped
        filteredOrders = orders.filter(order => {
          return ['volunteer_accepted', 'arrived_restaurant', 'shipped'].includes(order.status);
        });
      } else if (activeFilter === 'delivered') {
        // 已完成：包含 delivered, completed
        filteredOrders = orders.filter(order => {
          return ['delivered', 'completed'].includes(order.status);
        });
      } else {
        filteredOrders = orders.filter(order => {
          return order.status === activeFilter;
        });
      }
    }
    
    // 为每个订单计算商品总数
    filteredOrders = filteredOrders.map((order, index) => {
      const processedOrder = {
        ...order,
        totalItems: this.calculateTotalItems(order.items || [])
      };
      
      console.log(`筛选后的订单 ${index + 1} 的 total_amount:`, processedOrder.total_amount);
      return processedOrder;
    });
    
    console.log('筛选结果:', { filteredCount: filteredOrders.length, filteredOrders });
    
    this.setData({
      filteredOrders
    });
  },

  /**
   * 计算订单商品总数
   */
  calculateTotalItems: function(items) {
    return items.reduce((total, item) => total + item.quantity, 0);
  },

  /**
   * 获取订单总商品数量
   */
  getOrderTotalQuantity: function(items) {
    console.log('计算商品数量的items:', items, typeof items);
    
    // 安全检查 - 确保items存在且为数组
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.log('items为空或不是数组，返回0');
      return 0;
    }
    
    // 计算商品份数总和
    let totalQuantity = 0;
    
    items.forEach((item, index) => {
      // 检查item是否有效
      if (!item) {
        console.log(`商品${index + 1}无效，跳过`);
        return;
      }
      
      // 获取quantity值，处理各种可能的情况
      let quantity = 0;
      
      // 检查不同可能的字段名
      if (item.quantity !== undefined && item.quantity !== null) {
        quantity = parseInt(item.quantity) || 0;
      } else if (item.qty !== undefined && item.qty !== null) {
        console.log(`商品${index + 1}使用qty字段`);
        quantity = parseInt(item.qty) || 0;
      } else if (item.amount !== undefined && item.amount !== null) {
        console.log(`商品${index + 1}使用amount字段`);
        quantity = parseInt(item.amount) || 0;
      } else {
        // 默认值为1，确保至少有一个商品数量
        quantity = 1;
        console.log(`商品${index + 1}没有找到数量字段，默认使用1`);
      }
      
      console.log(`商品${index + 1}的最终quantity:`, quantity);
      totalQuantity += quantity;
    });
    
    console.log('计算后的总商品数量:', totalQuantity);
    return totalQuantity;
  },

  /**
   * 获取订单状态对应的样式类名
   */
  getStatusClass: function(status) {
    // 先标准化状态
    const normalizedStatus = this.normalizeStatus(status);
    const classMap = {
      '待付款': 'status-pending',
      '顾客已下单': 'status-paid',
      '顾客已确认': 'status-customer-accepted',
      '商家已接单': 'status-merchant-accepted',
      '等待志愿者接单': 'status-waiting-volunteer',
      '志愿者已接单': 'status-volunteer-accepted',
      '已到达餐厅': 'status-arrived-restaurant',
      '配送中': 'status-shipped',
      '已送达': 'status-delivered',
      '已完成': 'status-completed',
      '已取消': 'status-cancelled',
      '已退款': 'status-refunded',
      '未知状态': 'status-unknown',
      // 向后兼容旧状态
      '已下单': 'status-paid',
      '已接单': 'status-merchant-accepted'
    };
    return classMap[normalizedStatus] || 'status-unknown';
  },

  /**
   * 计算订单总金额
   */
  calculateOrderTotal: function(items) {
    if (!items || items.length === 0) return '0.00';
    const total = items.reduce((sum, item) => {
      const price = parseFloat(item.price) || 0;
      const quantity = parseInt(item.quantity) || 0;
      return sum + (price * quantity);
    }, 0);
    return total.toFixed(2);
  },

  /**
   * 格式化订单总金额显示
   */
  formatOrderTotal: function(totalAmount) {
    console.log('formatOrderTotal - 原始金额:', totalAmount, typeof totalAmount);
    if (!totalAmount && totalAmount !== 0) return '0.00';
    const amount = parseFloat(totalAmount);
    if (isNaN(amount)) return '0.00';
    const formatted = amount.toFixed(2);
    console.log('formatOrderTotal - 格式化后:', formatted);
    return formatted;
  },

  /**
   * 处理订单
   */
  handleOrder(e) {
    const orderId = e.currentTarget.dataset.id;
    const currentStatusFromBtn = e.currentTarget.dataset.status;
    let currentStatus = currentStatusFromBtn;
    if (!currentStatus) {
      const targetOrder = this.data.orders.find(order => order.id === orderId);
      currentStatus = targetOrder ? targetOrder.status : null;
    }
    
    const canAdvanceToWaiting = currentStatus === 'merchant_accepted';
    const targetStatus = canAdvanceToWaiting ? 'waiting_volunteer' : 'merchant_accepted';
    const modalContent = canAdvanceToWaiting
      ? '确定要将该订单标记为“等待志愿者接单”吗？'
      : '确定要开始处理这个订单吗？';
    
    // 检查用户信息，确保有商家ID
    const userInfo = wx.getStorageSync('userInfo') || {};
    const cachedMerchantId = userInfo.merchant_id || wx.getStorageSync('activeMerchantId') || wx.getStorageSync('merchantId');

    if (userInfo.role_id === 2 && !userInfo.merchant_id && cachedMerchantId) {
      const updatedUserInfo = { ...userInfo, merchant_id: cachedMerchantId };
      wx.setStorageSync('userInfo', updatedUserInfo);
    }
    
    if (!cachedMerchantId) {
      wx.showToast({
        title: '未找到商家信息，请重新登录',
        icon: 'none'
      });
      return;
    }
    
    wx.showModal({
      title: '确认处理',
      content: modalContent,
      success: (res) => {
        if (res.confirm) {
          // 显示加载状态
          wx.showLoading({
            title: '处理中...',
          });
          
          // 调用API更新订单状态为merchant_accepted（商家已接单）
          orderAPI.updateOrderStatus(orderId, targetStatus)
            .then(response => {
              wx.hideLoading();
              
              if (response && response.success) {
                // 更新前端订单状态
                const { orders } = this.data;
                const updatedOrders = orders.map(order => {
                  if (order.id === orderId) {
                    const updatedStatus = targetStatus;
                    return {
                      ...order,
                      status: updatedStatus,
                      statusText: this.normalizeStatus(updatedStatus)
                    };
                  }
                  return order;
                });
                this.setData({ orders: updatedOrders });
                this.filterOrders();
                
                wx.showToast({
                  title: canAdvanceToWaiting ? '已进入等待志愿者阶段' : '订单已开始处理',
                  icon: 'success'
                });
              } else {
                // 更详细的错误信息
                const errorMsg = response?.message || '更新订单状态失败';
                console.error('更新订单状态失败:', response);
                wx.showToast({
                  title: errorMsg,
                  icon: 'none'
                });
              }
            })
            .catch(error => {
              wx.hideLoading();
              console.error('更新订单状态失败:', error);
              wx.showToast({
                title: '网络错误，请重试',
                icon: 'none'
              });
            });
        }
      }
    });
  },

  /**
   * 完成订单
   */
  completeOrder(e) {
    const orderId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认完成',
      content: '确定要标记此订单为已完成吗？',
      success: (res) => {
        if (res.confirm) {
          // 更新订单状态为已完成
          const { orders } = this.data;
          const updatedOrders = orders.map(order => {
            if (order.id === orderId) {
              return {
                ...order,
                status: 'completed',
                statusText: this.normalizeStatus('completed')
              };
            }
            return order;
          });
          this.setData({ orders: updatedOrders });
          
          wx.showToast({
            title: '订单已完成',
            icon: 'success'
          });
        }
      }
    });
  },

  /**
   * 查看订单详情
   */
  viewOrderDetail(e) {
    const orderId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/restaurant/res_order_detail?orderId=${orderId}`
    });
  },

  /**
   * 联系客户
   */
  contactUser(e) {
    this.makePhoneCall(e);
  },

  /**
   * 底部按钮联系客户
   */
  callUser(e) {
    this.makePhoneCall(e);
  },

  /**
   * 根据订单ID获取手机号并拨打
   */
  makePhoneCall(e) {
    const { phone, id } = e.currentTarget.dataset || {};
    let targetPhone = phone;

    if (!targetPhone && id) {
      const order = this.data.orders.find(item => item.id === id);
      if (order) {
        targetPhone = order.phone || order.user_phone;
      }
    }

    if (!targetPhone) {
      wx.showToast({
        title: '未找到联系电话',
        icon: 'none'
      });
      return;
    }

    wx.makePhoneCall({
      phoneNumber: targetPhone,
      fail: () => {
        wx.showToast({
          title: '拨打失败',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 获取当前用户信息
   */
  getCurrentUserInfo() {
    return new Promise((resolve, reject) => {
      // 尝试从缓存获取用户信息
      const userInfo = wx.getStorageSync('userInfo');
      const token = wx.getStorageSync('token');
      
      // 优先使用缓存信息
      if (userInfo && userInfo.role === 'restaurant' && userInfo.merchant_id) {
        resolve(userInfo);
        return;
      }

      // 尝试从缓存中恢复已选择的商家ID
      const cachedMerchantId = wx.getStorageSync('activeMerchantId') || wx.getStorageSync('merchantId');
      if (cachedMerchantId) {
        const resolvedInfo = {
          ...(userInfo || {}),
          role: 'restaurant',
          merchant_id: cachedMerchantId
        };
        wx.setStorageSync('userInfo', resolvedInfo);
        resolve(resolvedInfo);
        return;
      }
      
      // 如果全局信息中已经有商家数据，也直接返回
      const app = getApp();
      if (app.globalData.userInfo && app.globalData.userInfo.role === 'restaurant' && app.globalData.userInfo.merchant_id) {
        wx.setStorageSync('userInfo', app.globalData.userInfo);
        wx.setStorageSync('activeMerchantId', app.globalData.userInfo.merchant_id);
        resolve(app.globalData.userInfo);
        return;
      }

      // 没有token无法继续调用接口
      if (!token) {
        reject(new Error('未登录，请先登录商家端'));
        return;
      }

      // 调用用户信息接口补齐商家ID
      authAPI.getProfile()
        .then(res => {
          if (!res || !res.success || !res.data) {
            throw new Error('获取用户信息失败');
          }

          const profile = res.data;
          const merchantIdFromProfile = profile.merchant_id || profile.merchantId || (profile.merchant && (profile.merchant.id || profile.merchant.merchant_id));
          
          if (merchantIdFromProfile) {
            const normalizedMerchantId = merchantIdFromProfile.toString();
            const resolvedInfo = {
              ...profile,
              role: profile.role || 'restaurant',
              merchant_id: normalizedMerchantId
            };
            wx.setStorageSync('userInfo', resolvedInfo);
            wx.setStorageSync('activeMerchantId', normalizedMerchantId);
            resolve(resolvedInfo);
            return;
          }

          // 若profile无商家ID，则尝试直接获取商家信息
          return merchantAPI.getMerchantInfo()
            .then(merchantRes => {
              if (!merchantRes || !merchantRes.success || !merchantRes.data) {
                throw new Error('未找到商家信息');
              }
              const merchantData = merchantRes.data;
              const merchantId = merchantData.id || merchantData.merchant_id;
              if (!merchantId) {
                throw new Error('未找到商家信息');
              }
              const resolvedInfo = {
                ...profile,
                role: profile.role || 'restaurant',
                merchant_id: merchantId
              };
              wx.setStorageSync('userInfo', resolvedInfo);
              wx.setStorageSync('activeMerchantId', merchantId);
              resolve(resolvedInfo);
            });
        })
        .catch(err => {
          console.error('获取商家信息失败:', err);
          reject(new Error('未找到商家信息，请重新登录'));
        });
    });
  },

  /**
   * 刷新订单列表
   */
  refreshOrders() {
    const { page, limit } = this.data.pagination;
    const { activeFilter } = this.data;
    
    wx.showLoading({
      title: '加载中...',
    });

    // 获取当前商家信息并设置参数
    this.getCurrentUserInfo()
      .then(userInfo => {
        console.log('当前商家信息:', userInfo);
        
        // 设置API调用参数，包含商家ID
        const params = {
          page: page,
          pageSize: limit,
          merchant_id: userInfo.merchant_id // 关键：传递商家ID
        };
        
        // 如果不是全部状态筛选，添加状态参数
        if (activeFilter !== 'all') {
          // 直接使用英文状态码作为API参数，与数据库保持一致
          params.status = activeFilter;
        }

        // 调用获取商家订单API
        return orderAPI.getMerchantOrders(params);
      })
      .then(res => {
        wx.hideLoading();
        
        console.log('订单API响应:', res);
        
        if (res && res.success && res.data) {
          // 统一处理各种可能的数据格式
          let ordersArray = [];
          
          if (res.data) {
            // 情况1: res.data 直接是数组
            if (Array.isArray(res.data)) {
              ordersArray = res.data;
            }
            // 情况2: res.data.orders 是数组
            else if (res.data.orders && Array.isArray(res.data.orders)) {
              ordersArray = res.data.orders;
            }
            // 情况3: res.data.orders.orders 是数组
            else if (res.data.orders && res.data.orders.orders && Array.isArray(res.data.orders.orders)) {
              ordersArray = res.data.orders.orders;
            }
            // 情况4: res.data.orders.data 是数组
            else if (res.data.orders && res.data.orders.data && Array.isArray(res.data.orders.data)) {
              ordersArray = res.data.orders.data;
            }
            // 情况5: res.data.data 是数组
            else if (res.data.data && Array.isArray(res.data.data)) {
              ordersArray = res.data.data;
            }
            // 情况6: res.data.orders 直接是数组（备用检查）
            else if (Array.isArray(res.data.orders)) {
              ordersArray = res.data.orders;
            }
          }
          
          // 获取分页信息
          let pagination = {};
          if (res.data && res.data.pagination) {
            pagination = res.data.pagination;
          } else if (res.data && res.data.orders && res.data.orders.pagination) {
            pagination = res.data.orders.pagination;
          }
          
          console.log('处理后的订单数据:', ordersArray);
          console.log('分页信息:', pagination);
          
          const currentPage = pagination.page || 1;
          
          if (ordersArray.length > 0) {
            // 先按创建时间倒序排序，保证日期越近的订单越靠前
            const sortedOrders = [...ordersArray].sort((a, b) => {
              const aTime = a.created_at ? new Date(a.created_at).getTime() : 0;
              const bTime = b.created_at ? new Date(b.created_at).getTime() : 0;
              return bTime - aTime;
            });

            // 处理订单数据，确保必要的字段存在
            const processedOrders = sortedOrders.map((order, index) => {
              console.log(`处理订单 ${index + 1}:`, order);
              // 调试订单数据结构
              console.log(`订单${index + 1}的数据结构:`, {
                hasItems: !!order.items,
                itemsType: typeof order.items,
                itemsIsArray: Array.isArray(order.items),
                hasOrderItems: !!order.order_items,
                orderItemsType: typeof order.order_items,
                orderItemsIsArray: Array.isArray(order.order_items)
              });
              
              // 检查是否有order_items字段（数据库中的字段名），如果有则使用它代替items
              let itemsData = [];
              if (order.order_items && Array.isArray(order.order_items)) {
                console.log('使用order_items字段数据:', order.order_items);
                itemsData = order.order_items;
              } else if (order.items && Array.isArray(order.items)) {
                console.log('使用items字段数据:', order.items);
                itemsData = order.items;
              }
              
              // 格式化商品项，确保每个商品都有product_name字段和quantity字段
              const formattedItems = itemsData.map((item, itemIndex) => {
                // 记录每个商品的原始数据
                console.log(`商品${itemIndex + 1}的原始数据:`, item);
                const processedItem = {
                  ...item,
                  product_name: item.product_name || item.name || '未知商品',
                  quantity: parseInt(item.quantity) || 1 // 确保quantity字段存在且为数字，默认为1
                };
                console.log(`商品${itemIndex + 1}的处理后数据:`, processedItem);
                return processedItem;
              });
              
              // 计算商品总数量（用于调试）
              const totalQuantity = formattedItems.reduce((sum, item) => sum + item.quantity, 0);
              console.log(`订单${index + 1}的商品总数量(调试):`, totalQuantity);
              console.log('格式化后的商品项:', formattedItems);
              
              // 处理顾客备注，生成截断显示用字段
              const remark = order.remark || '';
              const hasLongRemark = remark.length > 20;
              const shortRemark = hasLongRemark ? (remark.slice(0, 20) + '...') : remark;
              
              const processedOrder = {
                ...order,
                // 保持原始状态码，同时添加中文状态文本
                status: order.status, // 保持原始英文状态码用于筛选和API调用
                statusText: this.normalizeStatus(order.status), // 添加中文状态文本用于显示
                // 格式化时间
                orderTime: this.formatOrderTime(order.created_at),
                // 使用格式化后的商品项
                items: formattedItems,
                // 添加商品总数计算
                totalItems: this.calculateTotalItems(formattedItems),
                // 修复字段映射：user_nickname->userName, user_phone->phone
                userName: order.user_nickname || '未知用户',
                phone: order.user_phone || order.recipient_phone || '无电话',
                avatar: order.user_avatar || '',
                // 从后端获取配送地址和配送时间，格式化显示（仅地址，不含联系人信息）
                deliveryAddress: formatAddressOnly(order.delivery_address || ''), // 配送地址（外送订单，仅显示地址）
                scheduledDeliveryTime: order.scheduled_delivery_time || null, // 顾客选择的配送时间
                deliveryTime: this.formatScheduledDeliveryTime(order.scheduled_delivery_time), // 配送时间（格式化显示：立即配送或具体时间）
                pickupNumber: order.pickup_number || '', // 取餐号（自取订单）
                orderType: order.order_type || 'takeaway', // 订单类型：takeaway-外送，dine_in-自取
                // 向后兼容：保留旧的address字段（仅地址）
                address: formatAddressOnly(order.delivery_address || order.address || ''),
                // 确保总金额字段存在，来源于order表
                total_amount: order.total_amount || order.total_price || this.calculateOrderTotal(formattedItems),
                // 顾客备注相关字段
                remark,
                shortRemark,
                hasLongRemark,
                showFullRemark: false
              };
              
              console.log(`处理后订单 ${index + 1} 的 total_amount:`, processedOrder.total_amount);
              return processedOrder;
            });
            
            // 更新订单数据和分页信息
            this.setData({
              orders: currentPage === 1 ? processedOrders : [...this.data.orders, ...processedOrders],
              filteredOrders: currentPage === 1 ? processedOrders : [...this.data.orders, ...processedOrders],
              pagination: {
                ...this.data.pagination,
                ...pagination
              }
            });
          } else {
            this.setData({
              orders: currentPage === 1 ? [] : this.data.orders,
              filteredOrders: currentPage === 1 ? [] : this.data.filteredOrders,
              pagination: {
                ...this.data.pagination,
                ...pagination
              }
            });
            console.log('暂无订单数据');
          }
          
          // 停止下拉刷新动画
          wx.stopPullDownRefresh();
          
          wx.showToast({
            title: '加载成功',
            icon: 'success',
            duration: 1500
          });
        } else {
          throw new Error('API响应格式错误');
        }
      })
      .catch(err => {
        wx.hideLoading();
        wx.stopPullDownRefresh();
        
        console.error('获取订单数据失败:', err);
        
        wx.showModal({
          title: '加载失败',
          content: `无法获取订单数据：${err.message || '未知错误'}，请检查网络连接或稍后重试`,
          showCancel: false,
          confirmText: '确定'
        });
      });
  },

  /**
   * 切换备注展开/收起
   */
  toggleRemark(e) {
    const id = e.currentTarget.dataset.id;
    if (id === undefined || id === null) {
      return;
    }
    const updateList = (list) => {
      return (list || []).map(order => {
        // 使用 == 以兼容字符串/数字类型的id
        if (order.id == id) {
          return {
            ...order,
            showFullRemark: !order.showFullRemark
          };
        }
        return order;
      });
    };

    this.setData({
      orders: updateList(this.data.orders),
      filteredOrders: updateList(this.data.filteredOrders)
    });
  },

  /**
   * 标准化订单状态
   * 根据数据库状态映射到中文显示
   */
  normalizeStatus(status) {
    const statusMap = {
      // 数据库中的英文状态到中文的映射（根据新的状态表）
      'pending': '待付款',
      'cancelled': '已取消',
      'refunded': '已退款',
      'paid': '顾客已下单',
      'customer_accepted': '顾客已确认',
      'merchant_accepted': '商家已接单',
      'waiting_volunteer': '等待志愿者接单',
      'volunteer_accepted': '志愿者已接单',
      'arrived_restaurant': '已到达餐厅',
      'shipped': '配送中',
      'delivered': '已送达',
      'completed': '已完成',
      // 确保中文状态也能正常工作（向后兼容）
      '待付款': '待付款',
      '已取消': '已取消',
      '已退款': '已退款',
      '顾客已下单': '顾客已下单',
      '顾客已确认': '顾客已确认',
      '商家已接单': '商家已接单',
      '等待志愿者接单': '等待志愿者接单',
      '志愿者已接单': '志愿者已接单',
      '已到达餐厅': '已到达餐厅',
      '配送中': '配送中',
      '已送达': '已送达',
      '已完成': '已完成',
      // 旧状态映射（向后兼容）
      '已下单': '顾客已下单',
      '已接单': '商家已接单'
    };
    return statusMap[status] || status || '未知状态';
  },

  /**
   * 格式化订单时间
   */
  formatOrderTime(createdAt) {
    if (!createdAt) return '';
    
    const date = new Date(createdAt);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return '刚刚';
    if (diffMins < 60) return `${diffMins}分钟前`;
    if (diffHours < 24) return `${diffHours}小时前`;
    if (diffDays < 7) return `${diffDays}天前`;
    
    return date.toLocaleDateString('zh-CN');
  },

  /**
   * 格式化配送时间
   * 如果 scheduled_delivery_time 为 null，显示"立即配送"
   * 否则显示顾客选择的具体时间
   */
  formatScheduledDeliveryTime(scheduledDeliveryTime) {
    if (!scheduledDeliveryTime) {
      return '立即配送';
    }
    
    // 如果是日期时间字符串，格式化为可读格式
    try {
      const date = new Date(scheduledDeliveryTime);
      if (isNaN(date.getTime())) {
        // 如果不是有效的日期，直接返回原值（可能是时间范围字符串，如 "12:00 - 14:00"）
        return scheduledDeliveryTime;
      }
      // 格式化为：YYYY-MM-DD HH:mm
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    } catch (e) {
      // 如果解析失败，返回原值（可能是时间范围字符串）
      return scheduledDeliveryTime;
    }
  },

  /**
   * 加载更多订单
   */
  loadMoreOrders() {
    const { pagination } = this.data;
    
    // 如果已经在加载或者没有更多数据，则不执行
    if (pagination.isLoading || pagination.page >= pagination.totalPages) {
      return;
    }

    // 更新分页信息
    this.setData({
      'pagination.page': pagination.page + 1,
      'pagination.isLoading': true
    });

    // 重新加载订单
    this.refreshOrders();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    console.log('触发下拉刷新');
    
    // 重置分页信息
    this.setData({
      'pagination.page': 1,
      'pagination.isLoading': false
    });
    
    // 刷新订单数据
    this.refreshOrders();
  },

  /**
   * 页面相关事件处理函数--监听用户上拉触底
   */
  onReachBottom() {
    console.log('触发上拉加载更多');
    this.loadMoreOrders();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log('页面显示，刷新订单数据');
    this.setData({
      'pagination.page': 1,
      'pagination.isLoading': false
    });
    this.refreshOrders();
  }
});