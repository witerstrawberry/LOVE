// pages/restaurant/res_profile.js - 商家个人页面
const { merchantAPI } = require('../../utils/api');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageTitle: '商家中心',
    // 商家信息
    restaurantInfo: {
      name: '加载中...',
      logo: '',
      rating: 0,
      sales: 0,
      joinTime: '加载中...'
    },
    // 数据统计
    statistics: {
      monthlyOrders: 0,
      monthlyRevenue: 0,
      avgOrderValue: 0,
      satisfactionRate: 90
    },
    // 功能菜单
    menuItems: [
      {
        id: 'info',
        title: '店铺信息',
        icon: '🏠',
        arrow: true
      },
      {
        id: 'settings',
        title: '营业设置',
        icon: '⚙️',
        arrow: true
      },
      {
        id: 'tasks',
        title: '任务管理',
        icon: '📝',
        arrow: true
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        arrow: true
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        arrow: true
      }, {
        id: 'exit',
        title: '退出登录',
        icon: '🚪',
        arrow: true
      }
    ],
    // 是否显示营业中（默认值改为false，从后端获取真实状态）
    isOpen: false,
    // 营业状态是否已初始化
    businessStatusInitialized: false,
    // 数据加载状态
    loading: true,
    // 错误信息
    error: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('商家个人中心页面加载');
    // 页面加载时重置营业状态初始化标记
    this.setData({
      businessStatusInitialized: false
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('商家个人中心页面显示');
    // 页面显示时刷新数据
    this.refreshData();
    // 只有在首次加载或者状态未初始化时才获取营业状态
    if (!this.data.businessStatusInitialized) {
      console.log('首次获取营业状态');
      this.fetchBusinessStatus();
    } else {
      console.log('使用缓存的营业状态:', this.data.isOpen);
    }
  },

  /**
   * 刷新页面数据 - 从后端API获取
   */
  refreshData: function () {
    console.log('开始刷新商家个人页面数据...');
    this.setData({ loading: true, error: null });

    // 并行获取商家信息和统计数据
    Promise.all([
      this.fetchMerchantInfo(),
      this.fetchMerchantStats()
    ])
      .then(() => {
        console.log('数据刷新成功');
        this.setData({ loading: false });
      })
      .catch((error) => {
        console.error('数据刷新失败:', error);
        this.setData({
          loading: false,
          error: error.message || '数据加载失败，请重试'
        });

        // 显示错误提示
        wx.showToast({
          title: '数据加载失败',
          icon: 'error',
          duration: 2000
        });
      });
  },

  /**
   * 获取商家信息
   */
  fetchMerchantInfo: function () {
    console.log('正在获取商家信息...');
    return merchantAPI.getMerchantInfo()
      .then((result) => {
        console.log('商家信息API返回:', result);

        if (result.success && result.data) {
          const merchantData = result.data;
          const restaurantInfo = {
            name: merchantData.name || '未设置店名',
            logo: merchantData.logo || '',
            rating: merchantData.rating || 4.5,
            sales: merchantData.total_orders || 0,
            joinTime: merchantData.created_at ?
              new Date(merchantData.created_at).toLocaleDateString('zh-CN') :
              '未知'
          };

          this.setData({ restaurantInfo });
          console.log('商家信息设置完成:', restaurantInfo);
        } else {
          throw new Error(result.message || '获取商家信息失败');
        }
      })
      .catch((error) => {
        console.error('获取商家信息失败:', error);
        // 设置默认数据，避免页面空白
        this.setData({
          restaurantInfo: {
            name: '获取失败',
            logo: '',
            rating: 0,
            sales: 0,
            joinTime: '未知'
          }
        });
        throw error;
      });
  },

  /**
   * 从后端获取营业状态
   */
  fetchBusinessStatus: function () {
    const that = this;

    // 显示加载状态（但不覆盖页面加载状态）
    wx.showLoading({
      title: '获取状态中...',
      mask: true,
      duration: 2000 // 最多显示2秒
    });

    merchantAPI.getBusinessStatus()
      .then(res => {
        wx.hideLoading();

        console.log('营业状态API返回完整数据:', res);

        if (res.success) {
          const isOpen = res.data.is_open_boolean;
          console.log('获取营业状态成功:', isOpen);

          that.setData({
            isOpen: isOpen,
            businessStatusInitialized: true
          });
        } else {
          console.error('获取营业状态失败:', res.message);
          // 获取失败时，保持当前状态，仅标记为已初始化避免重复请求
          that.setData({
            businessStatusInitialized: true
          });
          wx.showToast({
            title: '获取状态失败',
            icon: 'none',
            duration: 1500
          });
        }
      })
      .catch(err => {
        wx.hideLoading();

        // 更健壮的错误处理
        let errorMessage = '网络错误';
        if (err) {
          if (err.message) {
            errorMessage = err.message;
          } else if (err.originalError?.errMsg) {
            errorMessage = err.originalError.errMsg;
          } else if (typeof err === 'string') {
            errorMessage = err;
          } else if (err.response?.data?.message) {
            errorMessage = err.response.data.message;
          } else if (err.statusCode) {
            errorMessage = `错误码: ${err.statusCode}`;
          }
        }

        console.error('获取营业状态失败:', err);
        console.error('错误详情:', errorMessage);

        // 错误情况下也标记为已初始化，避免重复请求
        that.setData({
          businessStatusInitialized: true
        });

        wx.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 1500
        });
      });
  },

  /**
   * 获取商家统计数据
   */
  fetchMerchantStats: function () {
    console.log('正在获取商家统计数据...');
    return merchantAPI.getMerchantStats()
      .then((result) => {
        console.log('统计数据API返回:', result);

        if (result.success && result.data) {
          const statsData = result.data;
          const monthlyOrders = Number(statsData.monthlyOrders ?? statsData.todayOrders ?? 0);
          const monthlyRevenueRaw = Number(statsData.monthlyRevenue ?? statsData.todayRevenue ?? 0);
          const avgValueRaw = statsData.avgOrderValue !== undefined && statsData.avgOrderValue !== null
            ? Number(statsData.avgOrderValue)
            : (monthlyOrders > 0 ? (monthlyRevenueRaw / monthlyOrders) : 0);

          const statistics = {
            monthlyOrders,
            monthlyRevenue: parseFloat(monthlyRevenueRaw.toFixed(2)),
            avgOrderValue: parseFloat(avgValueRaw.toFixed(2)),
            satisfactionRate: 90
          };

          this.setData({ statistics });
          console.log('统计数据设置完成:', statistics);
        } else {
          // 如果没有统计数据，使用默认值
          console.log('未获取到统计数据，使用默认值');
          this.setData({
            statistics: {
              monthlyOrders: 0,
              monthlyRevenue: 0,
              avgOrderValue: 0,
              satisfactionRate: 90
            }
          });
        }
      })
      .catch((error) => {
        console.error('获取统计数据失败:', error);
        // 设置默认统计数据
        this.setData({
          statistics: {
            monthlyOrders: 0,
            monthlyRevenue: 0,
            avgOrderValue: 0,
            satisfactionRate: 90
          }
        });
        // 统计数据失败不影响主流程
      });
  },

  /**
   * 切换营业状态
   */
  toggleBusinessStatus: function (e) {
    const that = this;
    const currentStatus = this.data.isOpen;

    // 处理 switch 组件传递的值
    let newStatus;
    if (e && e.detail && typeof e.detail.value === 'boolean') {
      newStatus = e.detail.value;
    } else {
      // 普通的点击切换
      newStatus = !currentStatus;
    }

    // 显示操作中提示
    wx.showLoading({
      title: newStatus ? '正在开店...' : '正在打烊...',
      mask: true
    });

    console.log('开始切换营业状态:', { from: currentStatus, to: newStatus });

    merchantAPI.updateBusinessStatus(newStatus)
      .then(res => {
        wx.hideLoading();

        console.log('营业状态更新响应:', res);

        if (res && res.success) {
          console.log('更新营业状态成功:', newStatus);

          // 更新本地状态
          that.setData({
            isOpen: newStatus
          });

          // 使用统一的同步方法
          that.syncBusinessStatusToOtherPages(newStatus);

          // 显示成功消息
          wx.showToast({
            title: newStatus ? '已开店' : '已打烊',
            icon: 'success',
            duration: 1500
          });
        } else {
          // 获取更详细的错误信息
          const errorMsg = res?.message || res?.data?.message || '未知错误';
          const errorCode = res?.statusCode || 'N/A';

          console.error('更新营业状态失败:', {
            success: res?.success,
            statusCode: errorCode,
            message: errorMsg,
            fullResponse: res
          });

          // 显示错误信息
          wx.showToast({
            title: errorMsg || '更新状态失败',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(err => {
        wx.hideLoading();

        console.error('更新营业状态失败:', err);

        // 处理网络错误或异常
        let errorMessage = '网络错误';
        if (err.message) {
          errorMessage = err.message;
        } else if (err.originalError?.errMsg) {
          errorMessage = err.originalError.errMsg;
        } else if (typeof err === 'string') {
          errorMessage = err;
        }

        // 网络错误提示
        wx.showToast({
          title: errorMessage,
          icon: 'none',
          duration: 2000
        });
      });
  },

  /**
   * 统一同步营业状态到其他页面
   */
  syncBusinessStatusToOtherPages: function (newStatus) {
    const debugInfo = [];
    const that = this;

    try {
      // 方法1：通过页面栈同步状态
      const pages = getCurrentPages();
      debugInfo.push(`当前页面栈深度: ${pages.length}`);

      pages.forEach((page, index) => {
        if (page.route === 'pages/restaurant/index' || page.route === 'pages/restaurant/res_profile') {
          debugInfo.push(`同步页面: ${page.route} (索引: ${index})`);

          // 更新目标页面的状态
          if (page.setData && typeof page.setData === 'function') {
            try {
              page.setData({
                isOpen: newStatus
              });
              debugInfo.push(`成功更新 ${page.route} 页面状态`);
            } catch (pageError) {
              debugInfo.push(`更新 ${page.route} 页面状态失败: ${pageError.message}`);
            }
          }
        }
      });

      // 方法2：使用全局数据同步
      const app = getApp();
      if (app && app.globalData) {
        app.globalData.merchantBusinessStatus = newStatus;
        debugInfo.push('已更新全局数据状态');
      }

      // 方法3：使用存储同步（作为备用方案）
      try {
        wx.setStorageSync('merchantBusinessStatus', {
          isOpen: newStatus,
          timestamp: Date.now()
        });
        debugInfo.push('已存储同步状态到本地');
      } catch (storageError) {
        debugInfo.push(`存储同步状态失败: ${storageError.message}`);
      }

      // 输出调试信息
      console.log('营业状态同步完成:', {
        newStatus,
        debug: debugInfo
      });

    } catch (syncError) {
      console.error('同步营业状态时发生错误:', syncError);

      // 即使同步失败，也不影响主流程
      wx.showToast({
        title: '状态同步异常，但操作已生效',
        icon: 'none',
        duration: 2000
      });
    }
  },

  /**
   * 打开功能菜单
   */
  openMenuItem: function (e) {
    const menuId = e.currentTarget.dataset.id;

    switch (menuId) {
      case 'info':
        // 跳转到店铺详细信息页面
        wx.navigateTo({
          url: '/pages/restaurant/res_detail_profile'
        });
        break;
      case 'settings':
        wx.showToast({ title: '跳转到营业设置页面', icon: 'none' });
        break;
      case 'tasks':
        // 跳转到商家任务列表/管理页面
        wx.navigateTo({
          url: '/pages/restaurant/task_all'
        });
        break;
      case 'help':
        // 跳转到帮助中心页面
        wx.navigateTo({
          url: '/pages/help-center/index'
        });
        break;
      case 'about':
        wx.showToast({ title: '跳转到关于我们页面', icon: 'none' });
        break;
    }
  },

  /**
   * 商家logo图片加载失败处理
   */
  onLogoError: function (e) {
    console.log('商家logo图片加载失败:', e);
    // 将logo设置为空，使用默认占位图
    this.setData({
      'restaurantInfo.logo': ''
    });
  },

  /**
   * 修改头像
   */
  changeLogo: function () {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        // TODO: 实际上传图片到服务器并更新商家信息
        wx.showToast({ title: '头像修改成功', icon: 'success' });

        // 可以在这里调用API更新头像
        // merchantAPI.updateMerchantInfo({ logo: newLogoUrl })
      }
    });
  },

  /**
   * 退出登录
   */
  logout: function () {
    wx.showModal({
      title: '退出登录',
      content: '确认要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除登录状态
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('token');

          // 跳转到登录页面
          wx.redirectTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 页面下拉刷新
   */
  onPullDownRefresh: function () {
    console.log('用户下拉刷新');
    this.refreshData().finally(() => {
      wx.stopPullDownRefresh();
    });
  }
});