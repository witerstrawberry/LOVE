// 老人端首页逻辑
const { aiAPI } = require('../../utils/api');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 社区信息
    communityName: '',
    // 用户信息
    userName: '张爷爷',
    // 当前显示的小贴士
    currentTip: '',
    // 是否正在加载小贴士
    isLoadingTip: false,
    // 养生文档数据
    healthDocuments: [
      {
        id: '1',
        title: '老年人春季养生注意事项',
        content: '春季气温变化大，老人要注意增减衣物，避免感冒。多吃时令蔬菜如荠菜、春笋，少吃辛辣食物。适当户外活动，呼吸新鲜空气，有助于提高免疫力。'
      },
      {
        id: '2',
        title: '适合老年人的饮食调理法',
        content: '老年人饮食宜清淡，每日盐摄入量不超过6克。多吃易消化的食物，如粥、面条等。适量食用鱼类、豆制品补充蛋白质。饭后半小时可散步促进消化。'
      }
    ],
    // 当前显示的养生文档索引
    currentDocIndex: 0,
    // 天气信息
    weatherInfo: {
      icon: '☀️',
      temperature: '24°C',
      description: '晴朗舒适'
    },
    // 页面状态
    isLoading: false,
    // 提醒相关
    mealReminders: [
      { time: '06:00', type: 'breakfast', title: '早餐提醒' },
      { time: '11:00', type: 'lunch', title: '午餐提醒' },
      { time: '17:00', type: 'dinner', title: '晚餐提醒' }
    ],
    // 今日已提醒的时间点
    todayRemindedTimes: [],
    // 是否显示餐品推荐弹窗
    showFoodRecommendationPopup: false,
    // 推荐餐品数据
    recommendedDishes: [],
    // 弹窗配置
    popupConfig: {
      peopleCount: 1,
      cutleryCount: 1,
      diningType: 'inStore', // inStore: 店内就餐, takeaway: 外卖
      remarks: '',
      dishesCount: {}
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function() {
    this.setData({ isLoading: true });
    // 模拟加载数据的延迟
    setTimeout(() => {
      this.getUserInfo();
      this.getCommunityInfo();
      this.getWeatherInfo();
      this.getAIHealthTip();
      this.setData({ isLoading: false });
    }, 500);
    
    // 初始化今日已提醒的时间点
    this.initRemindedTimes();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // 每次显示页面时刷新数据
    this.refreshPageData();
    
    // 启动定时检查
    this.startMealReminderCheck();
  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    // 清除定时器
    this.clearReminderTimer();
  },
  
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    // 清除定时器
    this.clearReminderTimer();
  },

  // 刷新页面数据
  refreshPageData: function() {
    this.getUserInfo();
    this.getWeatherInfo();
    this.getAIHealthTip();
  },
  
  // 获取AI生成的健康饮食小贴士
  getAIHealthTip: function() {
    const that = this;
    // 如果已经在加载中，则不重复请求
    if (that.data.isLoadingTip) return;
    
    that.setData({ isLoadingTip: true });
    
    // 构建请求参数，包含天气信息和当前日期
    const weatherInfo = this.data.weatherInfo || {};
    const currentDate = new Date().toISOString();
    
    // 调用AI接口获取健康小贴士
    // 使用getDishRecommendations接口，因为它会返回nutritionTip字段
    aiAPI.getDishRecommendations({
      userInfo: {},
      nutritionNeeds: ['适合老年人'],
      preferences: [],
      currentDate: currentDate,
      weatherInfo: weatherInfo
    }).then(res => {
      if (res.success && res.nutritionTip) {
        that.setData({
          currentTip: res.nutritionTip
        });
      } else {
        // 如果AI接口失败，使用默认提示语
        that.setData({
          currentTip: '保持良好的饮食习惯，对健康至关重要。'
        });
      }
    }).catch(err => {
      console.error('获取AI健康小贴士失败:', err);
      // 错误情况下使用默认提示语
      that.setData({
        currentTip: '多喝水，多吃新鲜蔬果，保持健康生活方式。'
      });
    }).finally(() => {
      that.setData({ isLoadingTip: false });
    });
  },
  
  // 显示更多小贴士
  showMoreTips: function() {
    this.getAIHealthTip();
  },
  
  // 滑动切换文章
  onDocScroll: function(e) {
    const scrollLeft = e.detail.scrollLeft;
    // 获取屏幕宽度作为滚动计算单位
    const screenWidth = wx.getSystemInfoSync().windowWidth;
    const docWidth = screenWidth * 0.9; // 因为文章宽度现在是90%
    
    // 使用更精确的计算方式，当滑动超过50%时切换到下一篇
    const currentIndex = Math.floor(scrollLeft / docWidth + 0.5);
    
    // 确保索引在有效范围内
    const validIndex = Math.min(Math.max(currentIndex, 0), this.data.healthDocuments.length - 1);
    
    // 使用延迟更新，避免频繁触发setData影响性能
    if (validIndex !== this.data.currentDocIndex) {
      if (this.scrollTimer) {
        clearTimeout(this.scrollTimer);
      }
      this.scrollTimer = setTimeout(() => {
        this.setData({
          currentDocIndex: validIndex
        });
        this.scrollTimer = null;
      }, 100);
    }
  },
  
  // 滑动结束时确保文章居中显示
  onScrollEnd: function(e) {
    const screenWidth = wx.getSystemInfoSync().windowWidth;
    const docWidth = screenWidth * 0.9; // 文章宽度是90%
    const scrollLeft = e.detail.scrollLeft;
    
    // 计算当前应该居中的文章索引，使用0.5阈值确保滑动超过一半时切换
    const targetIndex = Math.floor(scrollLeft / docWidth + 0.5);
    
    // 确保索引在有效范围内
    const validIndex = Math.min(Math.max(targetIndex, 0), this.data.healthDocuments.length - 1);
    
    // 直接计算目标滚动位置
    const targetScrollLeft = validIndex * docWidth;
    
    // 检查是否需要滚动（如果已经在正确位置附近，则不滚动）
    const tolerance = 5; // 允许的误差范围
    if (Math.abs(scrollLeft - targetScrollLeft) > tolerance) {
      // 使用scroll-view上下文直接滚动到目标位置
      const scrollViewContext = wx.createScrollViewContext('.articles-scroll-view', this);
      scrollViewContext.scrollTo({
        scrollLeft: targetScrollLeft,
        duration: 300
      });
    }
    
    // 更新当前索引
    if (validIndex !== this.data.currentDocIndex) {
      this.setData({
        currentDocIndex: validIndex
      });
    }
  },

  // 获取用户信息
  getUserInfo: function() {
    // 实际应用中应从本地存储或API获取用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo && userInfo.nickName) {
      this.setData({
        userName: userInfo.nickName
      });
    }
  },

  // 获取社区信息
  getCommunityInfo: function() {
    // 首先尝试从本地存储获取保存的社区信息
    const savedCommunity = wx.getStorageSync('selectedCommunity');
    if (savedCommunity) {
      this.setData({
        communityName: savedCommunity.name,
        currentLocation: savedCommunity
      });
    } else {
      // 如果没有保存的社区信息，则进行定位
      this.getUserLocation();
    }
  },
  
  // 获取用户位置
  getUserLocation: function() {
    const that = this;
    wx.showLoading({ title: '正在获取位置...' });
    
    // 获取位置信息
    wx.getLocation({
      type: 'gcj02',
      success: function(res) {
        const latitude = res.latitude;
        const longitude = res.longitude;
        
        // 使用腾讯地图API进行逆地理编码（需要申请地图API密钥）
        // 这里使用简化版本，实际项目中应使用真实的地图服务
        that.reverseGeocode(latitude, longitude);
      },
      fail: function(err) {
        wx.hideLoading();
        console.error('获取位置失败:', err);
        
        // 显示位置权限设置提示
        wx.showModal({
          title: '提示',
          content: '需要位置权限来获取您所在的社区信息',
          showCancel: false,
          success: function() {
            // 设置默认社区名称
            that.setData({
              communityName: '请选择社区'
            });
          }
        });
      }
    });
  },
  
  // 逆地理编码获取地址信息
  reverseGeocode: function(latitude, longitude) {
    const that = this;
    // 使用相对路径导入腾讯地图工具模块
    const tencentMap = require('../../utils/tencentMap.js');
    const { searchNearbyCommunities } = tencentMap;
    
    // 调用腾讯地图API获取周边社区信息
    searchNearbyCommunities(latitude, longitude)
      .then(communities => {
        wx.hideLoading();
        
        // 处理返回的社区数据
        let nearbyCommunities = communities;
        
        // 如果没有找到社区，提供默认社区数据作为降级方案
        if (!nearbyCommunities || nearbyCommunities.length === 0) {
          console.log('未找到周边社区');
          nearbyCommunities = [];
        }
        
        // 保存当前坐标和社区列表
        that.setData({
          currentLocation: {
            latitude: latitude,
            longitude: longitude
          },
          nearbyCommunities: nearbyCommunities
        });
        
        // 如果有社区数据
        if (nearbyCommunities && nearbyCommunities.length > 0) {
          if (nearbyCommunities.length === 1) {
            // 只有一个社区，直接使用
            that.selectCommunity(nearbyCommunities[0]);
          } else {
            // 显示社区选择弹窗
            that.showCommunitySelection();
          }
        } else {
          // 没有社区数据，显示提示
          wx.showToast({
            title: '未找到周边社区，请重新定位',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(err => {
        wx.hideLoading();
        console.error('获取周边社区失败:', err);
        
        // 检查是否是签名验证失败
        const isSignatureError = err.message && err.message.includes('签名验证失败');
        
        // 提供默认社区列表作为降级方案
        const defaultCommunities = [
          {
            id: 1,
            name: '阳光社区',
            address: '默认社区地址',
            latitude: latitude,
            longitude: longitude,
            distance: 0
          },
          {
            id: 2,
            name: '幸福家园',
            address: '默认社区地址',
            latitude: latitude,
            longitude: longitude,
            distance: 0
          },
          {
            id: 3,
            name: '和谐小区',
            address: '默认社区地址',
            latitude: latitude,
            longitude: longitude,
            distance: 0
          }
        ];
        
        // 尝试从本地存储读取之前保存的社区
        const savedCommunity = wx.getStorageSync('selectedCommunity');
        if (savedCommunity && savedCommunity.name) {
          // 如果有保存的社区，直接使用
        that.setData({
          currentLocation: {
            latitude: latitude,
            longitude: longitude
          },
            nearbyCommunities: [savedCommunity, ...defaultCommunities],
            communityName: savedCommunity.name
          });
          that.selectCommunity(savedCommunity);
          return;
        }
        
        // 显示友好的错误提示
        wx.showModal({
          title: '定位提示',
          content: isSignatureError 
            ? '地图服务暂时不可用，请手动选择社区' 
            : '无法获取周边社区信息，请手动选择社区',
          showCancel: true,
          confirmText: '选择社区',
          cancelText: '稍后',
          success: function(res) {
            if (res.confirm) {
              // 用户选择手动选择社区
              that.setData({
                currentLocation: {
                  latitude: latitude,
                  longitude: longitude
                },
                nearbyCommunities: defaultCommunities
              });
              // 显示社区选择弹窗
          setTimeout(() => {
            that.showCommunitySelection();
              }, 300);
            } else {
              // 用户选择稍后，使用默认社区
              that.setData({
                currentLocation: {
                  latitude: latitude,
                  longitude: longitude
                },
                nearbyCommunities: defaultCommunities,
                communityName: defaultCommunities[0].name
              });
              that.selectCommunity(defaultCommunities[0]);
            }
          }
        });
      });
  },
  
  // 显示社区选择弹窗
  showCommunitySelection: function() {
    const that = this;
    const communities = this.data.nearbyCommunities || [];
    
    // 创建选择列表，添加手动输入选项
    const communityOptions = communities.map(item => `${item.name} (${item.address})`);
    const actionSheetItems = ['📍 重新定位', '✏️ 手动输入社区名称', ...communityOptions];
    
    wx.showActionSheet({
      itemList: actionSheetItems,
      success: function(res) {
        if (res.tapIndex === 0) {
          // 重新定位
          that.getUserLocation();
        } else if (res.tapIndex === 1) {
          // 手动输入社区名称
          that.showInputCommunityDialog();
        } else if (res.tapIndex > 1) {
          // 选择社区
          const selectedCommunity = communities[res.tapIndex - 2];
          that.selectCommunity(selectedCommunity);
        }
      },
      fail: function(err) {
        console.error('社区选择失败:', err);
      }
    });
  },
  
  // 显示手动输入社区名称对话框
  showInputCommunityDialog: function() {
    const that = this;
    wx.showModal({
      title: '输入社区名称',
      editable: true,
      placeholderText: '请输入社区名称',
      success: function(res) {
        if (res.confirm && res.content && res.content.trim()) {
          // 创建社区对象
          const customCommunity = {
            id: Date.now(),
            name: res.content.trim(),
            address: '手动输入',
            latitude: that.data.currentLocation?.latitude || 0,
            longitude: that.data.currentLocation?.longitude || 0,
            distance: 0
          };
          // 选择该社区
          that.selectCommunity(customCommunity);
        }
      }
    });
  },
  
  // 选择社区
  selectCommunity: function(community) {
    this.setData({
      communityName: community.name,
      selectedCommunity: community
    });
    
    // 保存选择到本地存储
    wx.setStorageSync('selectedCommunity', community);
    
    wx.showToast({
      title: `已定位到${community.name}`,
      icon: 'success'
    });
  },

  // 获取天气信息
  getWeatherInfo: function() {
    // 这里可以从天气API获取实时天气信息
    // 现在使用模拟数据
    // 根据时间模拟不同天气
    const hour = new Date().getHours();
    let weatherInfo = {};
    
    if (hour >= 6 && hour < 12) {
      weatherInfo = {
        icon: '☀️',
        temperature: '22°C',
        description: '早晨好，阳光明媚'
      };
    } else if (hour >= 12 && hour < 18) {
      weatherInfo = {
        icon: '🌤️',
        temperature: '26°C',
        description: '午后温暖舒适'
      };
    } else if (hour >= 18 && hour < 22) {
      weatherInfo = {
        icon: '🌙',
        temperature: '20°C',
        description: '傍晚凉爽宜人'
      };
    } else {
      weatherInfo = {
        icon: '🌙',
        temperature: '18°C',
        description: '夜深了，注意保暖'
      };
    }
    
    this.setData({
      weatherInfo: weatherInfo
    });
  },

  // 一键呼叫商家
  callMerchant: function() {
    wx.showModal({
      title: '确认呼叫',
      content: '是否拨打商家电话？',
      success: (res) => {
        if (res.confirm) {
          // 实际应用中应调用微信的拨打电话API
          wx.makePhoneCall({
            phoneNumber: '400-123-4567',
            fail: () => {
              wx.showToast({
                title: '呼叫失败，请稍后重试',
                icon: 'none'
              });
            }
          });
        }
      }
    });
  },

  // 跳转到今日推荐食品
  gotoTodayRecommend: function() {
    wx.navigateTo({
      url: '../old-recommend/today-recommend',
      fail: () => {
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  // 跳转到我的订单
  gotoMyOrders: function() {
    wx.navigateTo({
      url: '../orders/orders',
      fail: () => {
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  // 扫码付（为过审，此功能暂时关闭）
  scanQRCode: function() {
    wx.showModal({
      title: '提示',
      content: '为过审，此功能暂时关闭',
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#409eff'
    });
  },

  // 跳转到扫码付（保留原方法，以防其他地方调用）
  gotoScanPay: function() {
    // 为过审，此功能暂时关闭
    wx.showModal({
      title: '提示',
      content: '为过审，此功能暂时关闭',
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#409eff'
    });
  },

  // 执行扫码
  doScanCode: function() {
    // 调用微信扫码API
    wx.scanCode({
      success: (res) => {
        console.log('扫码结果：', res);
        wx.showToast({
          title: '扫码成功',
          icon: 'success'
        });
        // 实际应用中应处理扫码结果并跳转到付款页面
      },
      fail: () => {
        wx.showToast({
          title: '扫码失败，请重试',
          icon: 'none'
        });
      }
    });
  },

  // 跳转到家属联系人
  gotoFamilyContact: function() {
    wx.navigateTo({
      url: '../old-contacts/family-contacts',
      fail: () => {
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  // 跳转到家属代点
  gotoFamilyOrder: function() {
    wx.navigateTo({
      url: '../family-order/family-order',
      fail: () => {
        wx.showToast({
          title: "功能开发中",
          icon: 'none'
        });
      }
    });
  },

  // 初始化今日已提醒的时间点
  initRemindedTimes: function() {
    const today = new Date().toDateString();
    const remindedTimes = wx.getStorageSync('mealRemindedTimes') || {};
    
    // 如果不是今天的记录，重置为空
    if (remindedTimes.date !== today) {
      remindedTimes.date = today;
      remindedTimes.times = [];
      wx.setStorageSync('mealRemindedTimes', remindedTimes);
    }
    
    this.setData({
      todayRemindedTimes: remindedTimes.times || []
    });
  },
  
  // 启动定时检查
  startMealReminderCheck: function() {
    // 先清除可能存在的定时器
    this.clearReminderTimer();
    
    // 立即检查一次
    this.checkMealReminder();
    
    // 每分钟检查一次
    this.reminderTimer = setInterval(() => {
      this.checkMealReminder();
    }, 60000); // 60秒
  },
  
  // 清除定时器
  clearReminderTimer: function() {
    if (this.reminderTimer) {
      clearInterval(this.reminderTimer);
      this.reminderTimer = null;
    }
  },
  
  // 检查是否需要提醒
  checkMealReminder: function() {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    // 使用传统字符串拼接替代模板字符串
    const hourStr = currentHour.toString();
    const minuteStr = currentMinute.toString();
    const currentTimeString = (hourStr.length === 1 ? '0' + hourStr : hourStr) + ':' + (minuteStr.length === 1 ? '0' + minuteStr : minuteStr);
    
    const { mealReminders, todayRemindedTimes } = this.data;
    
    // 使用传统for循环替代for...of循环，避免babel运行时依赖
    for (let i = 0; i < mealReminders.length; i++) {
      const reminder = mealReminders[i];
      // 检查时间是否匹配且今天尚未提醒
      if (currentTimeString === reminder.time && todayRemindedTimes.indexOf(reminder.time) === -1) {
        this.showMealReminder(reminder);
        this.addRemindedTime(reminder.time);
        break;
      }
    }
  },
  
  // 显示餐食提醒
  showMealReminder: function(reminder) {
    wx.showModal({
      title: reminder.title,
      content: `该吃${reminder.type === 'breakfast' ? '早餐' : reminder.type === 'lunch' ? '午餐' : '晚餐'}了，是否查看今日推荐餐品？`,
      success: (res) => {
        if (res.confirm) {
          this.getRecommendedDishes(reminder.type);
        }
      }
    });
  },
  
  // 添加已提醒时间
  addRemindedTime: function(time) {
    const remindedTimes = wx.getStorageSync('mealRemindedTimes') || {};
    remindedTimes.times.push(time);
    wx.setStorageSync('mealRemindedTimes', remindedTimes);
    
    this.setData({
      todayRemindedTimes: remindedTimes.times
    });
  },
  
  // 获取推荐餐品
  getRecommendedDishes: function(mealType) {
    const request = require('../../utils/request');
    
    // 构建请求参数
    const params = {
      userInfo: {
        name: this.data.userName,
        age: 65, // 假设年龄，实际应从用户信息获取
        gender: 'male' // 假设性别，实际应从用户信息获取
      },
      nutritionNeeds: ['易消化', '营养均衡', '适合老年人'],
      preferences: [],
      currentDate: new Date().toISOString(),
      mealType: mealType
    };
    
    // 调用AI推荐接口 - 设置更长的超时时间（20秒）并提供自定义错误消息
    request.post('/ai/dish-recommendations', params, {
      showLoading: true,
      timeout: 20000, // AI接口可能需要更长时间处理
      customErrorMsg: '获取推荐餐品超时，请稍后重试',
      showError: false // 避免重复显示错误提示
    })
      .then(res => {
        if (res.success && res.dishes) {
          this.setData({
            recommendedDishes: res.dishes,
            showFoodRecommendationPopup: true
          });
        } else {
          // 处理接口返回成功但数据不符合预期的情况
          console.warn('获取推荐餐品数据不完整:', res);
          wx.showToast({
            title: '暂无推荐餐品',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        console.error('获取推荐餐品失败:', err);
        // 不直接显示错误，而是提供一个友好的提示
        wx.showModal({
          title: '提示',
          content: '暂时无法获取推荐餐品，是否查看今日推荐页面？',
          showCancel: true,
          cancelText: '取消',
          confirmText: '去查看',
          success: (res) => {
            if (res.confirm) {
              // 跳转到今日推荐页面
              wx.navigateTo({
                url: '/pages/old-recommend/today-recommend'
              });
            }
          }
        });
      });
  },
  
  // 关闭推荐弹窗
  closeRecommendationPopup: function() {
    this.setData({
      showFoodRecommendationPopup: false
    });
  },

  // 模拟触发弹窗（用于测试）
  simulatePopup: function() {
    wx.showModal({
      title: '选择测试时间点',
      content: '请选择要模拟的就餐提醒时间点',
      showCancel: true,
      cancelText: '取消',
      confirmText: '确认',
      success: (res) => {
        if (res.confirm) {
          // 调用获取推荐餐品函数并显示弹窗
          this.getRecommendedDishes('lunch'); // 测试午餐时间
        }
      }
    });
  },
  
  // 选择用餐人数
  selectPeopleCount: function(e) {
    const count = parseInt(e.currentTarget.dataset.count);
    this.setData({
      'popupConfig.peopleCount': count
    });
  },
  
  // 选择就餐方式
  selectDiningType: function(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      'popupConfig.diningType': type
    });
  },
  
  // 选择餐具数量
  selectCutleryCount: function(e) {
    const count = parseInt(e.currentTarget.dataset.count);
    this.setData({
      'popupConfig.cutleryCount': count
    });
  },
  
  // 增加菜品数量
  increaseDishCount: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const currentCount = this.data.popupConfig.dishesCount[dishId] || 1;
    const newCount = currentCount + 1;
    
    const updateObj = {};
    updateObj['popupConfig.dishesCount.' + dishId] = newCount;
    this.setData(updateObj);
  },
  
  // 减少菜品数量
  decreaseDishCount: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const currentCount = this.data.popupConfig.dishesCount[dishId] || 1;
    
    if (currentCount > 1) {
      const newCount = currentCount - 1;
      const updateObj = {};
      updateObj['popupConfig.dishesCount.' + dishId] = newCount;
      this.setData(updateObj);
    }
  },
  
  // 输入备注
  onRemarksInput: function(e) {
    this.setData({
      'popupConfig.remarks': e.detail.value
    });
  },
  
  // 确认点餐
  confirmOrder: function() {
    const { recommendedDishes, popupConfig } = this.data;
    
    // 计算总价格并构建订单明细
    let totalPrice = 0;
    const items = [];
    
    for (let i = 0; i < recommendedDishes.length; i++) {
      const dish = recommendedDishes[i];
      const quantity = popupConfig.dishesCount[dish.id] || 1;
      const itemPrice = dish.price * quantity;
      totalPrice += itemPrice;
      
      items.push({
        product_id: dish.id,
        product_name: dish.name,
        price: dish.price,
        quantity: quantity,
        subtotal: itemPrice
      });
    }
    
    // 构建完整订单数据
    const orderData = {
      items: items,
      total_amount: totalPrice,
      peopleCount: popupConfig.peopleCount,
      cutleryCount: popupConfig.cutleryCount,
      diningType: popupConfig.diningType,
      remarks: popupConfig.remarks,
      orderTime: new Date().toISOString()
    };
    
    console.log('提交订单数据:', orderData);
    
    // 调用下单接口 - 使用正确的路径
    wx.showLoading({ title: '正在提交订单...' });
    
    const request = require('../../utils/request');
    request.post('/order', orderData, { showLoading: false })
      .then(res => {
        wx.hideLoading();
        
        if (res.success) {
          wx.showToast({
            title: '点餐成功！',
            icon: 'success'
          });
          
          // 关闭弹窗
          this.closeRecommendationPopup();
          
          // 跳转到订单页面
          setTimeout(() => {
            wx.navigateTo({ url: '../orders/orders' });
          }, 1500);
        } else {
          wx.showToast({
            title: '点餐失败，请重试',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        wx.hideLoading();
        console.error('提交订单失败:', err);
        wx.showToast({
          title: '网络错误，请重试',
          icon: 'none'
        });
      });
  },
  
  // 下拉刷新处理
  onPullDownRefresh: function() {
    this.refreshPageData();
    wx.stopPullDownRefresh();
  }
});
