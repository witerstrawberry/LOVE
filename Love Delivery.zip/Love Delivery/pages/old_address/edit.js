// 地址编辑页面
const app = getApp();

// 导入API工具
const { addressAPI } = require('../../utils/api.js');

Page({
  data: {
    id: '', // 地址ID，为空表示新增
    address: {
      name: '',
      phone: '',
      province: '',
      city: '',
      district: '',
      detail: '',
      is_default: false
    },
    loading: false,
    error: ''
  },

  onLoad: function(options) {
    // 获取地址ID，如果存在则表示编辑模式
    if (options.id) {
      this.setData({
        id: options.id
      });
      this.fetchAddressDetail();
    }
  },

  // 获取地址详情
  fetchAddressDetail: function() {
    this.setData({
      loading: true,
      error: ''
    });

    addressAPI.getAddressById(this.data.id)
      .then(res => {
        if (res && (res.success || res.code === 200 || res.code === 0)) {
          let addressData = res.data || res;
          
          // 处理返回数据结构的差异
          if (addressData.data) {
            addressData = addressData.data;
          }
          
          this.setData({
            address: addressData
          });
        } else {
          throw new Error(res.message || res.msg || '获取地址详情失败');
        }
      })
      .catch(error => {
        console.error('获取地址详情失败:', error);
        this.setData({
          error: error.message || '网络错误，请稍后重试'
        });
        wx.showToast({
          title: error.message || '获取地址详情失败',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({
          loading: false
        });
      });
  },

  // 输入框内容变化时的处理函数
  onInputChange: function(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    
    this.setData({
      [`address.${field}`]: value
    });
  },

  // 切换默认地址
  toggleDefault: function(e) {
    const { value } = e.detail;
    
    this.setData({
      'address.is_default': value
    });
  },

  // 验证表单
  validateForm: function() {
    const { address } = this.data;
    
    if (!address.name.trim()) {
      wx.showToast({ title: '请输入收货人姓名', icon: 'none' });
      return false;
    }
    
    // 简单的手机号验证
    const phoneReg = /^1[3-9]\d{9}$/;
    if (!address.phone.trim() || !phoneReg.test(address.phone)) {
      wx.showToast({ title: '请输入正确的手机号码', icon: 'none' });
      return false;
    }
    
    if (!address.province.trim()) {
      wx.showToast({ title: '请输入省份', icon: 'none' });
      return false;
    }
    
    if (!address.city.trim()) {
      wx.showToast({ title: '请输入城市', icon: 'none' });
      return false;
    }
    
    if (!address.district.trim()) {
      wx.showToast({ title: '请输入区/县', icon: 'none' });
      return false;
    }
    
    if (!address.detail.trim()) {
      wx.showToast({ title: '请输入详细地址', icon: 'none' });
      return false;
    }
    
    return true;
  },

  // 保存地址
  saveAddress: function() {
    if (!this.validateForm()) {
      return;
    }
    
    this.setData({
      loading: true,
      error: ''
    });
    
    const { id, address } = this.data;
    
    // 准备提交的数据
    const submitData = {
      name: address.name.trim(),
      phone: address.phone.trim(),
      province: address.province,
      city: address.city,
      district: address.district,
      detail: address.detail.trim(),
      is_default: address.is_default
    };

    // 获取当前用户ID（直接从存储中获取，不进行登录验证）
    let userInfo = wx.getStorageSync('userInfo');
    
    // 尝试解析用户信息
    try {
      if (typeof userInfo === 'string') {
        userInfo = JSON.parse(userInfo);
      }
    } catch (e) {
      console.error('解析用户信息失败:', e);
      userInfo = app.globalData.userInfo;
    }
    
    // 使用全局用户信息作为后备
    userInfo = userInfo || app.globalData.userInfo;
    // 直接获取用户ID，不进行登录验证
    const userId = userInfo && userInfo.id ? userInfo.id : '';
    
    // 如果有userId，添加到提交数据中
    if (userId) {
      submitData.userId = userId;
    }
    
    // 根据是否有ID判断是新增还是更新
    const promise = id 
      ? addressAPI.updateAddress(id, submitData) 
      : addressAPI.addAddress(submitData);
    
    promise
      .then(res => {
        if (res && (res.success || res.code === 200 || res.code === 0)) {
          wx.showToast({
            title: id ? '更新成功' : '添加成功',
            icon: 'success'
          });
          
          // 延迟返回上一页，让用户看到成功提示
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        } else {
          throw new Error(res.message || res.msg || (id ? '更新失败' : '添加失败'));
        }
      })
      .catch(error => {
        console.error(id ? '更新地址失败:' : '添加地址失败:', error);
        wx.showToast({
          title: error.message || (id ? '更新失败，请稍后重试' : '添加失败，请稍后重试'),
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({
          loading: false
        });
      });
  },


  
  // 返回上一页
  navigateBack: function() {
    // 尝试返回上一页，如果失败则跳转到地址列表页
    try {
      const pages = getCurrentPages();
      if (pages.length > 1) {
        wx.navigateBack();
      } else {
        wx.switchTab({ url: '/pages/old_address/addresses' });
      }
    } catch (error) {
      // 如果出现错误，直接跳转到地址列表页
      wx.switchTab({ url: '/pages/old_address/addresses' });
    }
  }
});