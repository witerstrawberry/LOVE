// 地址管理页面
const app = getApp();

// 导入API工具
const { addressAPI } = require('../../utils/api.js');

Page({
  data: {
    addressList: [], // 地址列表
    loading: false,  // 加载状态
    error: '',       // 错误信息
    hasMore: true,   // 是否有更多数据
    pageNum: 1,      // 当前页码
    pageSize: 10     // 每页条数
  },
  
  // 阻止事件冒泡
  stopPropagation: function(e) {
    e.stopPropagation();
  },

  onLoad: function(options) {
    // 保存URL参数中的userId
    this.setData({
      userId: options.userId || ''
    });
    // 直接获取地址列表，不进行登录验证
    this.fetchAddressList();
  },

  onShow: function() {
    // 每次页面显示时重新获取地址列表
    this.setData({
      addressList: [],
      pageNum: 1,
      hasMore: true
    });
    this.fetchAddressList();
  },

  // 获取地址列表
  fetchAddressList: function() {
    // 如果已经没有更多数据或者正在加载中，则不再请求
    if (!this.data.hasMore || this.data.loading) {
      return;
    }

    this.setData({
      loading: true,
      error: ''
    });

    // 优先使用页面data中的userId（从URL参数中获取）
    let userId = this.data.userId;
    
    // 如果URL参数中没有userId，则从本地存储获取
    if (!userId) {
      // 获取当前用户ID（直接从存储中获取，不进行登录验证）
      let userInfo = wx.getStorageSync('userInfo');
      
      // 尝试解析用户信息
      try {
        if (typeof userInfo === 'string') {
          userInfo = JSON.parse(userInfo);
        }
      } catch (e) {
        console.error('解析用户信息失败:', e);
        userInfo = app.globalData.userInfo;
      }
      
      // 使用全局用户信息作为后备
      userInfo = userInfo || app.globalData.userInfo;
      // 直接获取用户ID，不进行登录验证
      userId = userInfo && userInfo.id ? userInfo.id : '';
    }
    
    // 构建请求参数
    const params = {
      page: this.data.pageNum,
      pageSize: this.data.pageSize,
      userId: userId
    };

    // 调用API获取地址列表
    addressAPI.getAddressList(params)
      .then(res => {
        // 兼容不同的返回格式
        let newAddresses = [];
        let total = 0;

        if (res && (res.success || res.code === 200 || res.code === 0)) {
          // 处理数据
          if (res.data && Array.isArray(res.data)) {
            newAddresses = res.data;
          } else if (res.data && res.data.list) {
            newAddresses = res.data.list;
            total = res.data.total || 0;
          } else if (Array.isArray(res)) {
            newAddresses = res;
          }

          // 合并地址列表
          const updatedList = this.data.addressList.concat(newAddresses);

          // 判断是否还有更多数据
          const hasMore = total > 0 ? updatedList.length < total : newAddresses.length >= this.data.pageSize;

          this.setData({
            addressList: updatedList,
            pageNum: this.data.pageNum + 1,
            hasMore: hasMore
          });
        } else {
          throw new Error(res.message || res.msg || '获取地址列表失败');
        }
      })
      .catch(error => {
        console.error('获取地址列表失败:', error);
        // 不显示登录相关错误提示，只显示一般性错误
        this.setData({
          error: '获取地址列表失败，请稍后重试',
          addressList: []
        });
      })
      .finally(() => {
        this.setData({
          loading: false
        });
      });
  },
  // 添加新地址
  addNewAddress: function() {
    wx.navigateTo({
      url: '/pages/old_address/edit' 
    });
  },

  // 编辑地址
  editAddress: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/old_address/edit?id=${id}`
    });
  },

  // 删除地址
  deleteAddress: function(e) {
    const id = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个收货地址吗？',
      success: (res) => {
        if (res.confirm) {
          this.setData({
            loading: true
          });
          
          // 优先使用页面data中的userId
          let userId = this.data.userId;
          
          // 如果URL参数中没有userId，则从本地存储获取
          if (!userId) {
            // 获取当前用户ID
            let userInfo = wx.getStorageSync('userInfo');
            try {
              if (typeof userInfo === 'string') {
                userInfo = JSON.parse(userInfo);
              }
            } catch (e) {
              console.error('解析用户信息失败:', e);
              userInfo = app.globalData.userInfo;
            }
            userInfo = userInfo || app.globalData.userInfo;
            userId = userInfo && userInfo.id ? userInfo.id : '';
          }
          
          // 调用API删除地址，传递userId参数
          addressAPI.deleteAddress(id, userId)
            .then(result => {
              if (result && (result.success || result.code === 200 || result.code === 0)) {
                // 删除成功后，重新获取地址列表
                this.setData({
                  addressList: [],
                  pageNum: 1,
                  hasMore: true
                });
                this.fetchAddressList();
                wx.showToast({
                  title: '删除成功',
                  icon: 'success'
                });
              } else {
                throw new Error(result.message || result.msg || '删除失败');
              }
            })
            .catch(error => {
              console.error('删除地址失败:', error);
              wx.showToast({
                title: error.message || '删除失败，请稍后重试',
                icon: 'none'
              });
            })
            .finally(() => {
              this.setData({
                loading: false
              });
            });
        }
      }
    });
  },

  // 设置默认地址
  setDefaultAddress: function(e) {
    const id = e.currentTarget.dataset.id;
    
    this.setData({
      loading: true
    });
    
    // 优先使用页面data中的userId
    let userId = this.data.userId;
    
    // 如果URL参数中没有userId，则从本地存储获取
    if (!userId) {
      // 获取当前用户ID
      let userInfo = wx.getStorageSync('userInfo');
      try {
        if (typeof userInfo === 'string') {
          userInfo = JSON.parse(userInfo);
        }
      } catch (e) {
        console.error('解析用户信息失败:', e);
        userInfo = app.globalData.userInfo;
      }
      userInfo = userInfo || app.globalData.userInfo;
      userId = userInfo && userInfo.id ? userInfo.id : '';
    }
    
    // 调用API设置默认地址，传递userId参数
    addressAPI.setDefaultAddress(id, userId)
      .then(result => {
        if (result && (result.success || result.code === 200 || result.code === 0)) {
          // 更新地址列表中的默认地址状态
          const updatedList = this.data.addressList.map(item => ({
            ...item,
            is_default: item.id === id
          }));
          
          this.setData({
            addressList: updatedList
          });
          
          wx.showToast({
            title: '设置成功',
            icon: 'success'
          });
        } else {
          throw new Error(result.message || result.msg || '设置失败');
        }
      })
      .catch(error => {
        console.error('设置默认地址失败:', error);
        wx.showToast({
          title: error.message || '设置失败，请稍后重试',
          icon: 'none'
        });
      })
      .finally(() => {
        this.setData({
          loading: false
        });
      });
  },

  // 选择地址
  selectAddress: function(e) {
    const addressId = e.currentTarget.dataset.id;
    const address = this.data.addressList.find(item => item.id === addressId);
    
    if (address) {
      // 从URL参数中获取来源页面
      const pages = getCurrentPages();
      const currentPage = pages[pages.length - 1];
      const from = currentPage.options.from || '';
      
      console.log('选择地址:', address, '来源页面:', from);
      
      // 如果是从点餐页面或订单确认页面跳转过来的，将选中的地址存储到本地存储
      if (from === 'order-food' || from === 'order-confirm') {
        wx.setStorageSync('selectedAddressForOrder', address);
      } else {
        // 否则，将选中的地址存储到全局变量或本地存储，供其他页面使用
        app.globalData.selectedAddress = address;
        wx.setStorageSync('selectedAddress', address);
      }
      
      // 返回上一页
      wx.navigateBack();
    }
  },
  
  // 上拉加载更多
  onReachBottom: function() {
    this.fetchAddressList();
  }
});