// 家属联系人页面逻辑
const { contactsAPI } = require('../../utils/api');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    contacts: [], // 联系人列表
    isLoading: true, // 加载状态
    errorMessage: '' // 错误信息
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.setData({ isLoading: true });
    // 页面加载时获取联系人列表
    this.fetchContacts();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 每次页面显示时刷新联系人列表，确保数据最新
    this.fetchContacts();
  },
  /**
   * 从后端获取联系人列表
   */
  fetchContacts: async function () {
    try {
      this.setData({ isLoading: true, errorMessage: '' });
      console.log('开始获取联系人列表...');
      // 调用API获取联系人列表
      const response = await contactsAPI.getContacts();
      console.log('联系人列表响应:', response);
      // 检查API返回格式
      if (response && response.success) {
        // 处理联系人数据 - 兼容各种返回格式
        let contactsList = [];
        // 详细的数据检查和处理
        if (response.data) {
          // 判断data是否为数组
          if (Array.isArray(response.data)) {
            console.log('后端返回数组格式，长度:', response.data.length);
            contactsList = response.data;
          } else if (typeof response.data === 'object') {
            // 如果是单个对象，转换为包含该对象的数组
            console.log('后端返回对象格式，转换为数组');
            contactsList = [response.data];
          } else {
            console.warn('后端返回的data类型异常:', typeof response.data);
            contactsList = [];
          }

          // 详细日志记录每个联系人的数据
          console.log('原始联系人列表详情:', JSON.stringify(contactsList, null, 2));

          // 确保联系人昵称正确显示
          contactsList = contactsList.map((contact, index) => {
            console.log(`联系人${index}原始数据:`, contact);
            // 尝试获取昵称的多种方式
            const nickname = contact.contact_name ||
              contact.contact_user_nickname ||
              (contact.contact_user_details && contact.contact_user_details.nickname) ||
              '未设置昵称';
            console.log(`联系人${index}最终昵称:`, nickname);

            return {
              ...contact,
              contact_name: nickname,
              // 增加备用属性，确保前端有多种方式获取昵称
              nickname: nickname
            };
          });
        }

        console.log('处理后的联系人列表:', contactsList);

        this.setData({
          contacts: contactsList,
          isLoading: false
        });

        // 如果有联系人，显示第一个联系人的详细信息用于调试
        if (contactsList.length > 0) {
          console.log('第一个联系人详细信息:', JSON.stringify(contactsList[0], null, 2));
        }
      } else {
        // API返回失败
        console.error('API返回失败:', response);
        this.handleError(response?.message || '获取联系人列表失败');
      }
    } catch (error) {
      console.error('获取联系人列表时发生错误:', error);
      this.handleError(error?.message || '网络错误，请稍后重试');
    }
  },

  /**
   * 处理错误
   * @param {string} message 错误信息
   */
  handleError: function (message) {
    this.setData({
      errorMessage: message,
      isLoading: false,
      contacts: [] // 清空联系人列表
    });

    // 显示错误提示
    wx.showToast({
      title: message,
      icon: 'none',
      duration: 3000
    });
  },

  /**
   * 返回上一页
   */
  goBack: function () {
    wx.navigateBack({
      delta: 1
    });
  },

  /**
   * 显示联系人详情 - 优化老年人视觉体验
   * @param {Object} e 事件对象
   */
  showContactDetail: function (e) {
    const contactId = e.currentTarget.dataset.id;
    console.log('查看联系人详情:', contactId);

    // 查找对应的联系人
    const contact = this.data.contacts.find(item => item.id === contactId);
    if (contact) {
      console.log('联系人详情数据:', contact);

      // 构建更清晰的详情文本，增大行间距，突出重要信息
      const name = contact.nickname || contact.contact_name || '未设置昵称';
      const relationship = contact.relationship || '未设置';
      const phone = contact.contact_phone || '未设置电话';
      const role = contact.contact_role_name || '未设置角色';
      const isPrimary = contact.is_primary ? '是' : '否';

      // 构建格式化的详情内容，使用更大的行间距
      const detailContent =
        `📋 关系：${relationship}\n\n` +
        `📞 电话：${phone}\n\n` +
        `👤 角色：${role}\n\n` +
        `⭐ 主要联系人：${isPrimary}`;

      // 显示优化后的联系人详情模态框
      wx.showModal({
        title: `👤 ${name}`, // 添加头像图标增强视觉识别
        content: detailContent,
        showCancel: false, // 简化操作，只保留确定按钮
        confirmText: '知道了', // 更友好的按钮文字
        confirmColor: '#4CAF50', // 使用更醒目的按钮颜色
        success: function (res) {
          if (res.confirm) {
            console.log('用户查看详情完毕');
          }
        }
      });

      // 如果有电话号码，可以提供快速拨打选项
      if (phone && phone !== '未设置电话') {
        setTimeout(() => {
          wx.showActionSheet({
            itemList: ['拨打电话'],
            success: function (res) {
              if (res.tapIndex === 0) {
                wx.makePhoneCall({
                  phoneNumber: phone,
                  fail: function (err) {
                    console.error('拨打电话失败:', err);
                  }
                });
              }
            }
          });
        }, 500); // 延迟显示，让用户先看到详情
      }
    } else {
      console.warn('未找到联系人:', contactId);
      wx.showToast({
        title: '未找到联系人信息',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    }
  },

  /**
   * 下拉刷新处理
   */
  onPullDownRefresh: function () {
    console.log('下拉刷新');
    this.fetchContacts().finally(() => {
      // 停止下拉刷新
      wx.stopPullDownRefresh();
    });
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    // 如果有分页功能，可以在这里实现加载更多
    console.log('上拉触底');
  }
});