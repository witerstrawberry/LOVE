// pages/pay_success/pay_success.js
Page({
  data: {
    orderId: '',
    orderNo: '',
    totalAmount: 0,
    deliveryMethod: '外送'
  },

  onLoad(options) {
    console.log('支付成功页面参数:', options);
    
    this.setData({
      orderId: options.orderId || '',
      orderNo: options.orderNo || '',
      totalAmount: parseFloat(options.totalAmount) || 0,
      deliveryMethod: options.deliveryMethod || '外送'
    });
  },

  // 查看订单列表
  viewOrderDetail() {
    // 跳转到订单列表页面
    wx.navigateTo({
      url: '/pages/order_list/order_list'
    });
  },

  // 返回首页 - 根据用户角色ID跳转到对应的首页
  goHome() {
    try {
      // 获取用户信息
      const userInfo = wx.getStorageSync('userInfo');
      const roleId = userInfo?.role_id || userInfo?.roleId || null;
      
      console.log('用户信息:', userInfo);
      console.log('角色ID:', roleId);
      
      // 根据角色ID确定跳转页面
      let targetPage = '/pages/old-index/order-index'; // 默认：老人端首页
      
      if (roleId === 1) {
        // 老人角色
        targetPage = '/pages/old-index/order-index';
      } else if (roleId === 2) {
        // 商家角色
        targetPage = '/pages/restaurant/index';
      } else if (roleId === 3) {
        // 志愿者角色
        targetPage = '/pages/volunteer/index';
      } else if (roleId === 4) {
        // 子女角色
        targetPage = '/pages/family/family_index';
      } else {
        // 如果没有角色信息，尝试从selectedRole获取
        const selectedRole = wx.getStorageSync('selectedRole');
        if (selectedRole && selectedRole.id) {
          const roleIdStr = selectedRole.id;
          if (roleIdStr === 'elder') {
            targetPage = '/pages/old-index/order-index';
          } else if (roleIdStr === 'restaurant') {
            targetPage = '/pages/restaurant/index';
          } else if (roleIdStr === 'volunteer') {
            targetPage = '/pages/volunteer/index';
          } else if (roleIdStr === 'family') {
            targetPage = '/pages/family/family_index';
          }
        }
      }
      
      console.log('跳转到首页:', targetPage);
      
      // 使用 reLaunch 关闭所有页面并跳转到首页
      wx.reLaunch({
        url: targetPage
      });
    } catch (error) {
      console.error('返回首页失败:', error);
      // 如果出错，默认跳转到老人端首页
      wx.reLaunch({
        url: '/pages/old-index/order-index'
      });
    }
  },

  // 继续购物
  continueShopping() {
    wx.navigateBack({
      delta: 2
    });
  }
});

