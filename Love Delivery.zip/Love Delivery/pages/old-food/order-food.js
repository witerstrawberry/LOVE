// 点餐页面 - 老人端
const { productAPI, merchantAPI, cartAPI } = require('../../utils/api');
const { getFullImageUrl } = require('../../utils/imageUtils');

// 定义完整的模拟商家数据，作为API调用失败时的备用
const completeMockMerchant = {
  name: '排骨焖花卷砂锅（第七档口店）',
  image: '/images/restaurant.png',
  logo: '/images/restaurant.png',
  rating: 4.3,
  monthlySales: '2000+',
  deliveryTime: '上午10:00-14:00下午16:00-21:00可以送到财经大学宿舍楼下.其余时间送门口，雨天会延迟一些',
  address: '学校第七档口',
  phone: '13800138000',
  businessHours: '10:00-21:00',
  hasAddress: true
};


Page({
  data: {
    // 从family_index页面传递的亲属ID
    relativeId: '',
    // 餐厅信息
    restaurant: {
      name: '排骨焖花卷砂锅（第七档口店）',
      image: '/images/restaurant.png',
      rating: 4.3,
      monthlySales: '2000+',
      deliveryTime: '上午10:00-14:00下午16:00-21:00可以送到财经大学宿舍楼下.其余时间送门口，雨天会延迟一些',
    },
    
    // 当前激活的标签页
    activeTab: 'menu',
    
    // 菜单分类
    menuCategories: [], // 从后端获取分类列表
    
    // 选中的分类
    selectedCategory: 'recommend',
    
    // 所有餐品数据
    allFoodList: [], // 从后端获取所有商品数据
    
    // 加载状态
    loading: false,
    
    // 错误信息
    errorMessage: '',
    
    // 是否还有更多数据
    hasMore: true,
    
    // 当前页码
    currentPage: 1,
    
    // 每页数量
    pageSize: 20,
    
    // 当前显示的餐品列表
    currentFoodList: [],
    
    // 购物车数据
    cartItems: [],
    
    // 购物车商品总数
    cartCount: 0,
    
    // 购物车总价
    totalPrice: 0,
    
    // 显示购物车
    showCart: false
  },

  // 阻止事件冒泡
  stopPropagation: function(e) {
    // 在微信小程序中，使用e.stopPropagation()或e.stopImmediatePropagation()
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    } else if (e && typeof e.stopImmediatePropagation === 'function') {
      e.stopImmediatePropagation();
    }
  },

  onLoad(options) {
    // 从URL参数获取merchantId（从其他页面跳转时传递）
    let merchantId = '';
    if (options && options.merchantId) {
      merchantId = options.merchantId;
      // 保存到本地存储，供loadMerchantInfo使用
      wx.setStorageSync('activeMerchantId', merchantId);
      console.log('从URL参数获取的商家ID:', merchantId);
    } else {
      // 如果没有从URL获取，尝试从本地存储获取
      merchantId = wx.getStorageSync('activeMerchantId') || '';
      if (merchantId) {
        console.log('从本地存储获取的商家ID:', merchantId);
      }
    }
    
    // 从本地存储获取relativeId
    const relativeId = wx.getStorageSync('selectedRelativeId');
    if (relativeId) {
      this.setData({
        relativeId: relativeId
      });
      // 可以在这里根据relativeId加载相关数据
      console.log('从子女首页选择的亲属ID:', relativeId);
    }
    
    // 从后端加载商家信息
    this.loadMerchantInfo();
    
    // 从后端加载分类列表和商品数据
    this.loadCategories();
    this.loadProducts();
    
    // 从后端加载购物车数据
    this.loadCartFromBackend();
  },
  
  // 从后端加载商家信息
  loadMerchantInfo() {
    console.log('开始获取商家信息...');
    const merchantId = wx.getStorageSync('activeMerchantId');
    const params = merchantId ? { merchantId } : {};

    // 从后端获取商家信息（公开接口）
    merchantAPI.getPublicMerchantInfo(params)
      .then(res => {
        console.log('商家信息API响应完整数据:', res);
        
        try {
          // 检查响应的基本结构
          console.log('响应success字段:', res.success);
          console.log('响应data字段类型:', typeof res.data);
          console.log('响应data字段内容:', JSON.stringify(res.data));
          
          // 处理不同的响应数据格式
          let merchantData = null;
          
          // 更健壮的响应数据提取逻辑
          if (res && typeof res === 'object') {
            if (res.success && res.data) {
              console.log('使用res.success && res.data路径');
              merchantData = res.data;
            } else if (res.data && res.data.merchant) {
              console.log('使用res.data.merchant路径');
              merchantData = res.data.merchant;
            } else if (res.data) {
              console.log('使用res.data路径');
              merchantData = res.data;
            } else if (res.merchant) {
              console.log('使用res.merchant路径');
              merchantData = res.merchant;
            }
          }
          
          if (merchantData && typeof merchantData === 'object') {
            console.log('获取到商家数据:', JSON.stringify(merchantData));
            console.log('商家数据包含的字段:', Object.keys(merchantData));
            
            // 从商家数据中提取商家ID并保存到本地存储
            const extractedMerchantId = merchantData.merchant_id || merchantData.id || merchantData.merchantId || '';
            if (extractedMerchantId) {
              wx.setStorageSync('activeMerchantId', extractedMerchantId);
              console.log('已保存商家ID到本地存储:', extractedMerchantId);
            } else {
              console.warn('商家数据中未找到商家ID字段');
            }
            
            // 标准化商家数据格式，优先使用后端数据，缺失时使用模拟数据
            const standardizedMerchant = {
              name: merchantData.name || merchantData.merchant_name || completeMockMerchant.name,
              image: merchantData.logo ? getFullImageUrl(merchantData.logo) : completeMockMerchant.image,
              logo: merchantData.logo ? getFullImageUrl(merchantData.logo) : completeMockMerchant.image, // 同时设置logo属性
              rating: merchantData.rating || merchantData.score || completeMockMerchant.rating,
              monthlySales: merchantData.monthly_sales || merchantData.sales || completeMockMerchant.monthlySales,
              deliveryTime: merchantData.delivery_time || merchantData.business_hours || completeMockMerchant.deliveryTime,
              address: merchantData.address || merchantData.business_address || completeMockMerchant.address,
              phone: merchantData.phone || merchantData.contact_phone || completeMockMerchant.phone,
              businessHours: merchantData.business_hours || completeMockMerchant.businessHours,
              hasAddress: !!(merchantData.address || merchantData.business_address || completeMockMerchant.address)
            };
            
            console.log('标准化后的商家数据:', JSON.stringify(standardizedMerchant));
            console.log('hasAddress标志:', standardizedMerchant.hasAddress);
            
            this.setData({
              restaurant: standardizedMerchant
            });
            console.log('商家信息更新成功，当前this.data.restaurant:', JSON.stringify(this.data.restaurant));
          } else {
            console.log('未获取到有效的商家数据，使用完整模拟数据');
            
            this.setData({
              restaurant: completeMockMerchant
            });
            console.log('模拟数据设置成功:', JSON.stringify(completeMockMerchant));
          }
        } catch (error) {
          console.error('处理商家数据时出错:', error);
          console.error('错误堆栈:', error.stack);
          
          // 错误情况下使用完整的模拟数据，确保包含所有必要信息
          console.log('错误情况下使用完整模拟数据');
          this.setData({
            restaurant: completeMockMerchant
          });
          console.log('错误情况下模拟数据设置成功:', JSON.stringify(completeMockMerchant));
        }
      })
      .catch(error => {
        console.error('获取商家信息失败:', error);
        if (error && error.stack) {
          console.error('错误堆栈:', error.stack);
        }
        
        // API调用失败时使用完整的模拟数据
        console.log('API调用失败时使用完整模拟数据');
        this.setData({
          restaurant: completeMockMerchant
        });
        console.log('API调用失败时模拟数据设置成功:', JSON.stringify(completeMockMerchant));
      });
  },
  
  // 从后端加载商品数据
  loadProducts(categoryId, page = 1, append = false) {
    if (this.data.loading) return;
    
    this.setData({ loading: true, errorMessage: '' });
    
    // 构建请求参数
    const params = {
      page,
      pageSize: this.data.pageSize
    };
    
    // 定义请求方法
    let apiCall;
    
    if (categoryId && categoryId !== 'recommend' && String(categoryId) !== '1') {
      // 根据分类获取商品，但跳过'recommend'和'1'(代表推荐)
      console.log(`根据分类${categoryId}获取商品`);
      apiCall = productAPI.getProductsByCategory(categoryId, params);
    } else {
      // 获取所有商品或推荐商品
      console.log('获取所有商品');
      apiCall = productAPI.getProducts(params);
    }
    
    // 发送请求
    apiCall
      .then(res => {
        try {
          console.log('商品API响应完整数据:', res);
          
          // 处理不同的响应数据格式
          let products = [];
          // 打印更详细的响应数据结构
          console.log('res.data类型:', typeof res.data);
          console.log('res.data结构:', JSON.stringify(res.data));
          
          if (res.success && res.data) {
            // 处理格式: {success: true, code: 200, data: {...}, message: "", timestamp: ""}
            if (res.data.list) {
              products = res.data.list;
              console.log('从res.data.list获取商品数据');
            } else if (res.data.items) {
              products = res.data.items;
              console.log('从res.data.items获取商品数据');
            } else if (res.data.products) {
              products = res.data.products;
              console.log('从res.data.products获取商品数据');
            } else if (Array.isArray(res.data)) {
              products = res.data;
              console.log('res.data是数组，直接使用');
            } else if (typeof res.data === 'object') {
              // 尝试将整个data对象作为一个商品处理
              console.log('res.data是对象但不包含list/items/products，尝试将其作为单个商品');
              products = [res.data];
            } else {
              console.error('data字段格式不正确');
              // 使用模拟数据作为降级方案
              this.useMockData();
              return;
            }
          } else if (res.data && res.data.list) {
            // 处理格式: {data: {list: [...]}}
            products = res.data.list;
          } else if (res.data && res.data.items) {
            // 处理格式: {data: {items: [...]}}
            products = res.data.items;
          } else if (res.data && Array.isArray(res.data)) {
            // 处理格式: {data: [...]}
            products = res.data;
          } else if (Array.isArray(res)) {
            // 处理格式: [...] 直接返回数组
            products = res;
          } else {
            console.error('无法识别的响应格式');
            // 使用模拟数据作为降级方案
            this.useMockData();
            return;
          }
          
          console.log(`获取到${products.length}个商品`);
          
          // 标准化商品数据格式，确保包含页面所需的字段
          const standardizedProducts = products.map(product => {
            // 根据category_name映射到对应的categoryId
            let categoryId = 1; // 默认推荐
            const categoryMap = {
              '推荐': 1,
              '软食': 2,
              '控糖': 3,
              '低盐': 4,
              '低脂': 5,
              '营养套餐': 6,
              '传统家常': 7,
              '主食': 8,
              '凉菜': 9,
              '汤类': 10,
              '小份菜': 11
            };
            
            if (product.category_name && categoryMap[product.category_name]) {
              categoryId = categoryMap[product.category_name];
            }
            
            // 获取原始图片路径
            const originalImagePath = product.image || product.image_url;
            // 使用工具函数处理图片URL，确保返回正确的完整路径
            const processedImageUrl = originalImagePath ? getFullImageUrl(originalImagePath) : '../../images/default-avatar.png';
            
            return {
              id: product.id,
              category: categoryId,
              categoryId: categoryId,
              category_name: product.category_name || '推荐',
              name: product.name || '未命名商品',
              price: parseFloat(product.price || 0),
              originalPrice: product.original_price ? parseFloat(product.original_price) : null,
              image: processedImageUrl,
              image_url: processedImageUrl,
              tags: product.tags || product.tag || [],
              description: product.description || product.desc || '暂无描述',
              sales: product.sales || product.sales_count || product.view_count || 0,
              view_count: product.sales || product.sales_count || product.view_count || 0
            };
          });
          
          // 更新商品列表
          let updatedFoodList;
          if (append) {
            updatedFoodList = [...this.data.allFoodList, ...standardizedProducts];
          } else {
            updatedFoodList = standardizedProducts;
          }
          
          // 检查是否还有更多数据
          const hasMore = standardizedProducts.length >= this.data.pageSize;
          
          // 更新数据状态
          this.setData({
            allFoodList: updatedFoodList,
            loading: false,
            hasMore: hasMore
          });
          
          // 更新当前显示的餐品列表
          this.setCurrentFoodList(categoryId);
        } catch (error) {
          console.error('处理商品数据时出错:', error);
          this.setData({
            loading: false,
            errorMessage: '处理商品数据失败'
          });
          
          // 发生异常时使用模拟数据
          this.useMockData();
        }
      })
      .catch(error => {
        console.error('获取商品数据失败:', error);
        this.setData({
          loading: false,
          errorMessage: '获取商品数据失败，请重试'
        });
        
        // 无论是否是加载更多，都使用模拟数据作为降级方案
        this.useMockData();
      });
  },
  
  // 重新加载数据
  retry() {
    console.log('重新加载数据');
    this.setData({
      errorMessage: '',
      hasMore: true,
      currentPage: 1
    });
    this.loadCategories();
    this.loadProducts(null, 1, false);
  },
  
  // 加载更多商品
  loadMore() {
    if (!this.data.hasMore || this.data.loading) return;
    
    const nextPage = this.data.currentPage + 1;
    this.setData({ currentPage: nextPage });
    
    // 从后端加载更多数据
    this.loadProducts(this.data.selectedCategory, nextPage, true);
  },
  
  // 从后端加载分类列表
  loadCategories() {
    console.log('开始获取分类数据...');
    productAPI.getCategories()
      .then(res => {
        try {
          console.log('分类API响应完整数据:', res);
          console.log('响应数据类型:', typeof res.data);
          // 打印响应数据的所有键
          console.log('响应数据对象结构:', Object.keys(res.data));
        
        // 尝试多种可能的数据路径
        if (res.data && res.data.categories && Array.isArray(res.data.categories)) {
            console.log('从res.data.categories获取到分类数据:', res.data.categories);
            // 转换分类数据格式，确保包含页面所需的字段
            const activeCategories = res.data.categories.map(cat => ({
              id: String(cat.id), // 确保ID是字符串
              name: cat.name,
              icon: '', // 图片路径已删除
              status: 'active' // 设置为active确保被显示
            }));
            console.log('转换后的分类数据:', activeCategories);
            
            // 确保至少有一个分类
            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              this.setData({
                menuCategories: activeCategories,
                selectedCategory: selectedCategoryId,
                currentCategoryName: selectedCategoryName
              });
              console.log('设置分类成功，当前选中:', this.data.selectedCategory);
              this.setCurrentFoodList(this.data.selectedCategory);
            } else {
              console.log('没有分类数据，使用默认分类');
              this.useDefaultCategories();
            }
        } else if (res.data && res.data.data && Array.isArray(res.data.data)) {
          console.log('从res.data.data获取到分类数据:', res.data.data);
          const activeCategories = res.data.data;
          console.log('过滤后的分类(兼容格式):', activeCategories);
          
          if (activeCategories.length > 0) {
            const selectedCategoryId = activeCategories[0]?.id || '1';
            const selectedCategoryName = activeCategories[0]?.name || '推荐';
            this.setData({
              menuCategories: activeCategories,
              selectedCategory: selectedCategoryId,
              currentCategoryName: selectedCategoryName
            });
            this.setCurrentFoodList(this.data.selectedCategory);
          } else {
            this.useDefaultCategories();
          }
        } else {
          console.log('无法识别的响应格式，尝试直接使用res.data作为数组:', res.data);
          // 尝试直接使用res.data作为数组
          if (Array.isArray(res.data)) {
            console.log('res.data本身是数组，直接使用');
            const activeCategories = res.data;
            console.log('过滤后的分类(直接数组格式):', activeCategories);
            
            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              this.setData({
                menuCategories: activeCategories,
                selectedCategory: selectedCategoryId,
                currentCategoryName: selectedCategoryName
              });
              this.setCurrentFoodList(this.data.selectedCategory);
            } else {
              this.useDefaultCategories();
            }
          } else {
            console.log('响应数据格式不符合预期，但尝试直接从res.data.categories获取数据，然后使用默认分类');
            console.log('强制使用默认分类');
            this.useDefaultCategories();
          }
        }
        } catch (error) {
          console.error('处理分类数据时发生异常:', error);
          this.useDefaultCategories();
        }
      })
      .catch(err => {
        console.error('获取分类失败:', err);
        this.useDefaultCategories();
      });
  },
  
  // 使用默认分类数据
  useDefaultCategories() {
    console.log('使用默认分类数据');
    const defaultCategories = [
      { id: '1', name: '推荐', status: 'active' },
      { id: '2', name: '软食', status: 'active' },
      { id: '3', name: '控糖', status: 'active' },
      { id: '4', name: '低盐', status: 'active' },
      { id: '5', name: '低脂', status: 'active' },
      { id: '6', name: '营养套餐', status: 'active' },
      { id: '7', name: '传统家常', status: 'active' },
      { id: '8', name: '主食', status: 'active' },
      { id: '9', name: '凉菜', status: 'active' },
      { id: '10', name: '汤类', status: 'active' },
      { id: '11', name: '小份菜', status: 'active' }
    ];
    this.setData({
      menuCategories: defaultCategories,
      selectedCategory: '1',
      currentCategoryName: '推荐'
    });
    console.log('设置默认分类成功');
    this.setCurrentFoodList('1');
  },
  
  // 选择分类
  selectCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    console.log('选择分类:', categoryId);
    const categoryName = this.data.menuCategories.find(cat => cat.id === categoryId)?.name || '';
    
    this.setData({
      selectedCategory: categoryId,
      currentCategoryName: categoryName,
      hasMore: true,
      currentPage: 1
    });
    
    // 从后端加载该分类的商品数据
    this.loadProducts(categoryId, 1, false);
  },
  
  // 根据分类筛选餐品
  setCurrentFoodList(categoryId) {
    // 使用已从后端获取的商品列表进行筛选
    console.log('根据分类筛选商品:', categoryId);
    let currentFoodList = [];
    // 转换为字符串以便比较
    const categoryIdStr = String(categoryId);
    
    // 确保使用allFoodList，完全不依赖模拟数据
    if (this.data.allFoodList && this.data.allFoodList.length > 0) {
      // 处理推荐分类
      if (categoryIdStr === '1' || categoryIdStr === 'recommend') {
        // 推荐分类显示所有商品
        currentFoodList = [...this.data.allFoodList];
      } else {
        // 根据分类ID筛选商品
        currentFoodList = this.data.allFoodList.filter(item => 
          String(item.category) === categoryIdStr || 
          String(item.categoryId) === categoryIdStr
        );
        
        // 如果没有找到匹配项，尝试根据category_name筛选
        if (currentFoodList.length === 0) {
          console.log('未找到匹配ID的食品，尝试根据分类名称筛选');
          // 反向映射：根据数字ID找到对应的分类名称
          const idToCategoryMap = {
            '2': '软食',
            '3': '控糖',
            '4': '低盐',
            '5': '低脂',
            '6': '营养套餐',
            '7': '传统家常',
            '8': '主食',
            '9': '凉菜',
            '10': '汤类',
            '11': '小份菜'
          };
          const categoryName = idToCategoryMap[categoryIdStr];
          
          if (categoryName) {
            currentFoodList = this.data.allFoodList.filter(item => 
              item.category_name === categoryName
            );
          }
          
          // 如果仍然没有找到匹配项，返回所有食品
          if (currentFoodList.length === 0) {
            console.log('未找到匹配的食品，返回所有食品');
            currentFoodList = [...this.data.allFoodList];
          }
        }
      }
    }
    
    // 为每个餐品添加quantity属性（初始为0）
    currentFoodList = currentFoodList.map(item => {
      const cartItem = this.data.cartItems.find(cart => cart.id === item.id);
      return {
        ...item,
        quantity: cartItem ? cartItem.quantity : 0
      };
    });
    
    console.log('设置的食品列表数量:', currentFoodList.length);
    this.setData({
      currentFoodList: currentFoodList
    });
  },
  
  // 获取模拟食品数据
  getMockFoodList(categoryId) {
    console.log('获取模拟食品数据，分类ID:', categoryId);
    const mockFoods = [
      { id: 1, name: '红烧肉', price: 28, description: '经典红烧肉，肥而不腻', image: '/images/food1.jpg', sales: 120, tags: ['招牌', '热销'], category: 1, quantity: 0 },
      { id: 2, name: '宫保鸡丁', price: 22, description: '麻辣鲜香，回味无穷', image: '/images/food2.jpg', sales: 98, tags: ['辣'], category: 2, quantity: 0 },
      { id: 3, name: '鱼香肉丝', price: 20, description: '酸甜可口，下饭神器', image: '/images/food3.jpg', sales: 88, tags: ['酸甜'], category: 3, quantity: 0 },
      { id: 4, name: '西红柿鸡蛋', price: 18, description: '家常口味，营养健康', image: '/images/food4.jpg', sales: 76, tags: ['清淡'], category: 2, quantity: 0 },
      { id: 5, name: '麻婆豆腐', price: 16, description: '麻辣鲜香，豆腐嫩滑', image: '/images/food5.jpg', sales: 68, tags: ['辣', '招牌'], category: 3, quantity: 0 }
    ];
    return mockFoods;
  },

  // 返回上一页
  navigateBack() {
    wx.navigateBack();
  },
  
  // 切换标签页
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
    
    // 根据不同标签页可以添加不同的逻辑
    if (tab === 'menu') {
      // 确保菜品列表正确显示
      this.setCurrentFoodList(this.data.selectedCategory);
    }
  },

  // 选择分类
  selectCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    console.log('选择分类:', categoryId);
    
    this.setData({
      selectedCategory: categoryId,
      hasMore: true,
      currentPage: 1
    });
    
    // 从后端加载该分类的商品数据
    this.loadProducts(categoryId, 1, false);
  },

  // 添加商品到购物车
  addToCart(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('添加商品到购物车:', foodId);
    
    // 从当前餐品列表中查找商品
    const food = this.data.currentFoodList.find(item => item.id === foodId);
    if (!food) return;
    
    // 检查是否有足够库存
    const cartItem = this.data.cartItems.find(item => item.id === foodId);
    if (food.stock !== undefined && (cartItem ? cartItem.quantity >= food.stock : false)) {
      wx.showToast({ title: '已达库存上限', icon: 'none' });
      return;
    }
    
    // 更新购物车
    const newCartItems = [...this.data.cartItems];
    const existingItem = newCartItems.find(item => item.id === foodId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      newCartItems.push({ ...food, quantity: 1 });
    }
    
    // 更新购物车并重新计算总数和总价
    this.updateCart(newCartItems);
    
    // 更新当前显示列表中的数量
    const updatedQuantity = newCartItems.find(item => item.id === foodId).quantity;
    this.updateCurrentFoodQuantity(foodId, updatedQuantity);
    
    // 显示添加成功提示
    wx.showToast({ title: '已添加', icon: 'success', duration: 1000 });
  },
  
  // 增加商品数量
  increaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('增加商品数量:', foodId);
    
    // 从当前餐品列表中查找商品
    const food = this.data.currentFoodList.find(item => item.id === foodId);
    if (!food) return;
    
    // 检查是否有足够库存
    const cartItem = this.data.cartItems.find(item => item.id === foodId);
    if (food.stock !== undefined && (cartItem ? cartItem.quantity >= food.stock : false)) {
      wx.showToast({ title: '已达库存上限', icon: 'none' });
      return;
    }
    
    // 更新购物车
    const newCartItems = [...this.data.cartItems];
    const existingItem = newCartItems.find(item => item.id === foodId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      newCartItems.push({ ...food, quantity: 1 });
    }
    
    // 更新购物车并重新计算总数和总价
    this.updateCart(newCartItems);
    
    // 更新当前显示列表中的数量
    const updatedQuantity = newCartItems.find(item => item.id === foodId).quantity;
    this.updateCurrentFoodQuantity(foodId, updatedQuantity);
    
    // 同步到后端
    this.syncCartItemToBackend(foodId, updatedQuantity);
    
    // 显示添加成功提示
    wx.showToast({ title: '已添加', icon: 'success', duration: 1000 });
  },
  
  // 减少商品数量
  decreaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('减少商品数量:', foodId);
    
    // 更新购物车
    let newCartItems = [...this.data.cartItems];
    const existingItemIndex = newCartItems.findIndex(item => item.id === foodId);
    
    if (existingItemIndex !== -1) {
      newCartItems[existingItemIndex].quantity -= 1;
      
      // 如果数量为0，从购物车中移除
      if (newCartItems[existingItemIndex].quantity <= 0) {
        newCartItems = newCartItems.filter(item => item.id !== foodId);
        // 同步到后端：删除商品
        this.removeCartItemFromBackend(foodId);
      } else {
        // 同步到后端：更新数量
        const updatedQuantity = newCartItems[existingItemIndex].quantity;
        this.syncCartItemToBackend(foodId, updatedQuantity);
      }
      
      // 更新购物车并重新计算总数和总价
      this.updateCart(newCartItems);
      
      // 更新当前显示列表中的数量
      const updatedQuantity = newCartItems.find(item => item.id === foodId)?.quantity || 0;
      this.updateCurrentFoodQuantity(foodId, updatedQuantity);
    }
  },
  
  // 更新当前食品列表中的数量
  updateCurrentFoodQuantity(foodId, quantity) {
    const updatedFoodList = this.data.currentFoodList.map(item => {
      if (item.id === foodId) {
        return { ...item, quantity: quantity };
      }
      return item;
    });
    
    this.setData({
      currentFoodList: updatedFoodList
    });
  },
  
  // 更新购物车数据
  updateCart(cartItems) {
    const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    this.setData({
      cartItems: cartItems,
      cartCount: cartCount,
      totalPrice: totalPrice.toFixed(2)
    });
  },

  /**
   * 同步单个商品到后端购物车
   * @param {number} productId 商品ID
   * @param {number} quantity 商品数量
   */
  async syncCartItemToBackend(productId, quantity) {
    try {
      // 获取用户信息
      const userInfo = wx.getStorageSync('userInfo');
      if (!userInfo || !userInfo.id) {
        console.log('未登录用户，跳过购物车同步');
        return;
      }

      if (quantity > 0) {
        // 尝试更新购物车商品数量
        try {
          await cartAPI.updateCartItem(productId, quantity);
          console.log(`同步商品 ${productId} 到购物车，数量: ${quantity}`);
        } catch (error) {
          console.error(`更新商品 ${productId} 失败，尝试添加:`, error);
          // 如果更新失败（可能是商品不存在），尝试添加
          try {
            await cartAPI.addToCart(productId, quantity);
            console.log(`添加商品 ${productId} 到购物车，数量: ${quantity}`);
          } catch (addError) {
            console.error(`添加商品 ${productId} 失败:`, addError);
          }
        }
      }
    } catch (error) {
      console.error('同步购物车到后端失败:', error);
      // 不显示错误提示，避免影响用户体验
    }
  },

  /**
   * 从后端删除购物车商品
   * @param {number} productId 商品ID
   */
  async removeCartItemFromBackend(productId) {
    try {
      // 获取用户信息
      const userInfo = wx.getStorageSync('userInfo');
      if (!userInfo || !userInfo.id) {
        console.log('未登录用户，跳过购物车删除');
        return;
      }

      await cartAPI.removeCartItem(productId);
      console.log(`从后端删除商品 ${productId}`);
    } catch (error) {
      console.error(`删除商品 ${productId} 失败:`, error);
      // 不显示错误提示，避免影响用户体验
    }
  },

  /**
   * 从后端加载购物车数据
   */
  async loadCartFromBackend() {
    try {
      // 获取用户信息
      const userInfo = wx.getStorageSync('userInfo');
      if (!userInfo || !userInfo.id) {
        console.log('未登录用户，跳过购物车加载');
        return;
      }

      const res = await cartAPI.getCartItems();
      console.log('从后端获取购物车数据:', res);

      if (res && res.success && res.data && res.data.items) {
        const cartItems = res.data.items;
        
        // 将后端数据转换为前端格式
        const formattedCartItems = cartItems.map(item => ({
          id: item.product_id || item.id,
          name: item.product_name || item.name,
          price: parseFloat(item.price || 0),
          quantity: parseInt(item.quantity || 0),
          image: item.image || item.image_url || '',
          description: item.description || ''
        }));

        // 更新购物车数据
        this.updateCart(formattedCartItems);

        // 更新当前商品列表中的数量
        const updatedFoodList = this.data.currentFoodList.map(food => {
          const cartItem = formattedCartItems.find(item => item.id === food.id);
          return {
            ...food,
            quantity: cartItem ? cartItem.quantity : 0
          };
        });
        this.setData({
          currentFoodList: updatedFoodList
        });

        console.log('购物车数据加载成功');
      }
    } catch (error) {
      console.error('从后端加载购物车失败:', error);
      // 不显示错误提示，避免影响用户体验
    }
  },
  


  // 打开购物车
  openCart() {
    this.setData({ showCart: true });
  },

  // 关闭购物车
  closeCart() {
    this.setData({ showCart: false });
  },

  // 结算
  checkout(e) {
    // 检查是否有事件对象，如果有则阻止冒泡
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    }
    
    if (this.data.cartItems.length > 0) {
      // 获取商家ID
      const merchantId = wx.getStorageSync('activeMerchantId') || '';
      
      // 验证商家ID是否存在
      if (!merchantId) {
        wx.showToast({
          title: '商家信息缺失，请重新选择商家',
          icon: 'none',
          duration: 3000
        });
        return;
      }
      
      // 保存购物车数据到本地存储，便于结算页面使用
      wx.setStorageSync('currentCart', this.data.cartItems);
      wx.setStorageSync('totalPrice', this.data.totalPrice);
      
      // 构建跳转URL，包含商家ID
      const url = `/pages/old-confirm/order-confirm?merchantId=${merchantId}`;
      
      // 跳转到结算页面
      wx.navigateTo({
        url: url
      });
    } else {
      wx.showToast({
        title: '购物车为空',
        icon: 'none'
      });
    }
  }
});