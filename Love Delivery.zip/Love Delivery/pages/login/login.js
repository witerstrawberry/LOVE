// pages/login/login.js
const { authAPI } = require('../../utils/api');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    account: '',          // 账号
    password: '',         // 密码
    showPassword: false   // 是否显示密码
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 清除可能存在的旧登录状态
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
    wx.removeStorageSync('selectedRole');

    // 只显示上次使用的账号（如果有），但不自动填充密码
    const lastAccount = wx.getStorageSync('lastAccount');
    if (lastAccount) {
      this.setData({
        account: lastAccount
      });
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() { },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() { },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() { },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 页面卸载时的清理工作
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    wx.stopPullDownRefresh();
  },
  /**
   * 账号输入处理
   */
  onAccountInput(e) {
    this.setData({ account: e.detail.value });
  },

  /**
   * 密码输入处理
   */
  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  /**
   * 切换密码可见性
   */
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    });
  },

  /**
   * 忘记密码
   */
  forgotPassword() {
    wx.navigateTo({
      url: '/pages/login/forget-password'
    });
  },

  /**
   * 登录处理
   */
  async login() {
    const { account, password } = this.data;
    // 输入验证
    if (!account || account.trim().length === 0) {
      wx.showToast({ title: '请输入账号', icon: 'none' });
      return;
    }
    if (!password || password.length < 6) {
      wx.showToast({ title: '密码不能少于6位', icon: 'none' });
      return;
    }
    // 保存账号到本地存储
    wx.setStorageSync('lastAccount', account);
    // 显示加载提示
    wx.showLoading({ title: '登录中...' });
    try {
      // 调用后端登录API
      const response = await authAPI.login(account, password);
      wx.hideLoading();
      // 严格检查响应状态和数据完整性
      if (response && response.code === 200 && response.data && response.data.token && response.data.user) {
        // 登录成功，先检查账户状态
        const { token, user } = response.data;
        // 统一从 user.status 读取账户状态：active / inactive / banned
        const status = user && user.status;
        if (status === 'inactive') {
          wx.showModal({
            title: '账户已停用',
            content: '您的账户已被管理员停用，如有疑问请联系管理员。',
            showCancel: false
          });
          // 确保不保存任何登录状态
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('selectedRole');
          return;
        }
        if (status === 'banned') {
          wx.showModal({
            title: '账户已封禁',
            content: '您的账户已被管理员封禁，如有疑问请联系管理员。',
            showCancel: false
          });
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('selectedRole');
          return;
        }

        // 账户状态正常，保存token和用户信息到本地存储
        wx.setStorageSync('token', token);
        wx.setStorageSync('userInfo', {
          ...user,
          isLogin: true,
          loginTime: new Date().getTime()
        });

        // 保存用户角色信息（包括管理员）
        if (user.role_id) {
          let roleId;
          switch (user.role_id) {
            case 1: // 老人
              roleId = 'elder';
              break;
            case 2: // 商家
              roleId = 'restaurant';
              break;
            case 3: // 志愿者
              roleId = 'volunteer';
              break;
            case 4: // 子女
              roleId = 'family';
              break;
            case 5: // 管理员
              roleId = 'admin';
              break;
            default:
              roleId = '';
          }
          wx.setStorageSync('selectedRole', { id: roleId });
        }

        // 显示登录成功提示
        wx.showToast({ title: '登录成功', icon: 'success' });

        // 延迟跳转到首页
        setTimeout(() => {
          // 根据用户角色跳转到不同页面（优先使用后端role_id）
          let targetPage = '/pages/old-index/order-index'; // 默认老人端

          if (user.role_id === 5) {
            // 管理员进入后台
            targetPage = '/pages/Admin/admin_user_list';
          } else if (user.role_id === 2) {
            targetPage = '/pages/restaurant/index';
          } else if (user.role_id === 3) {
            targetPage = '/pages/volunteer/index';
          } else if (user.role_id === 4) {
            targetPage = '/pages/family/family_index';
          } else if (user.role_id === 1) {
            targetPage = '/pages/old-index/order-index';
          } else {
            const selectedRole = wx.getStorageSync('selectedRole');
            const roleId = selectedRole ? selectedRole.id : '';
            if (roleId === 'restaurant') {
              targetPage = '/pages/restaurant/index';
            } else if (roleId === 'volunteer') {
              targetPage = '/pages/volunteer/index';
            } else if (roleId === 'elder') {
              targetPage = '/pages/old-index/order-index';
            } else if (roleId === 'family') {
              targetPage = '/pages/family/family_index';
            }
          }

          // 使用reLaunch替代switchTab，确保可以正确跳转
          wx.reLaunch({ url: targetPage });
        }, 1500);
      } else {
        // 登录失败，显示错误信息
        const errorMsg = response && response.message ? response.message : '登录失败，请检查账号密码';
        wx.showToast({
          title: errorMsg,
          icon: 'none',
          duration: 2000
        });
        // 清除可能的残留登录状态
        wx.removeStorageSync('token');
        wx.removeStorageSync('userInfo');
        wx.removeStorageSync('selectedRole');
      }
    } catch (error) {
      wx.hideLoading();
      console.error('登录API调用失败:', error);
      // 优先展示后端返回的具体错误信息（例如“账户已被禁用，请联系客服”）
      const errorMsg = (error && (error.message || error.response?.message))
        || '认证失败，请检查网络或联系管理员';
      wx.showToast({
        title: errorMsg,
        icon: 'none',
        duration: 2000
      });
      // 确保清除所有登录相关的本地存储
      wx.removeStorageSync('token');
      wx.removeStorageSync('userInfo');
      wx.removeStorageSync('selectedRole');
    }
  },

  /**
   * 查看用户协议
   */
  viewAgreement() {
    wx.showToast({ title: '查看用户协议', icon: 'none' });
    // 实际项目中可以跳转到协议页面
  },

  /**
   * 查看隐私政策
   */
  viewPrivacy() {
    wx.showToast({ title: '查看隐私政策', icon: 'none' });
    // 实际项目中可以跳转到隐私政策页面
  },

  /**
   * 跳转到注册页面
   */
  goToRegister() {
    wx.navigateTo({
      url: '/pages/register/register'
    });
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() { }
});