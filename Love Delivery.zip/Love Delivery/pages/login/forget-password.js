// pages/login/forget-password.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',              // 手机号
    verificationCode: '',   // 验证码
    newPassword: '',        // 新密码
    confirmPassword: '',    // 确认密码
    showPassword: false,    // 是否显示密码
    showPassword1: false,    // 是否显示密码
    countdown: 0,           // 倒计时
    canSubmit: false,       // 是否可以提交
    errorMsg: '',           // 错误提示
    successMsg: '',         // 成功提示
    isSubmitting: false     // 提交状态
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 页面加载时的初始化逻辑
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 检查表单是否可提交
    this.checkCanSubmit();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 清除定时器
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer);
    }
  },

  /**
   * 手机号输入处理
   */
  onPhoneInput(e) {
    const phone = e.detail.value;
    this.setData({ 
      phone,
      errorMsg: ''  // 清除错误提示
    });
    this.checkCanSubmit();
  },

  /**
   * 验证码输入处理
   */
  onVerificationCodeInput(e) {
    const verificationCode = e.detail.value;
    this.setData({ 
      verificationCode,
      errorMsg: ''  // 清除错误提示
    });
    this.checkCanSubmit();
  },

  /**
   * 新密码输入处理
   */
  onNewPasswordInput(e) {
    const newPassword = e.detail.value;
    this.setData({ 
      newPassword,
      errorMsg: ''  // 清除错误提示
    });
    this.checkCanSubmit();
  },

  /**
   * 确认密码输入处理
   */
  onConfirmPasswordInput(e) {
    const confirmPassword = e.detail.value;
    this.setData({ 
      confirmPassword,
      errorMsg: ''  // 清除错误提示
    });
    this.checkCanSubmit();
  },

  /**
   * 切换密码可见性
   */
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    });
  },
  togglePasswordVisibility1() {
    this.setData({
      showPassword1: !this.data.showPassword1
    });
  },

  /**
   * 发送验证码
   */
  sendVerificationCode() {
    const { phone } = this.data;
    
    // 手机号格式验证
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      this.setData({
        errorMsg: '请输入正确的手机号码',
        successMsg: ''
      });
      return;
    }

    // 清除错误提示
    this.setData({
      errorMsg: '',
      successMsg: '验证码已发送'
    });

    // 开始倒计时
    this.startCountdown();

    // 模拟发送验证码请求
    console.log('发送验证码到手机号:', phone);
    
    // 实际应用中，这里应该调用发送验证码的API
    // wx.request({
    //   url: 'your-api-url',
    //   method: 'POST',
    //   data: { phone },
    //   success: (res) => {
    //     console.log('发送验证码成功', res);
    //   },
    //   fail: (err) => {
    //     console.error('发送验证码失败', err);
    //     this.setData({
    //       errorMsg: '发送验证码失败，请稍后重试',
    //       successMsg: ''
    //     });
    //   }
    // });
  },

  /**
   * 开始倒计时
   */
  startCountdown() {
    let seconds = 60;
    this.setData({ countdown: seconds });

    this.countdownTimer = setInterval(() => {
      seconds--;
      if (seconds <= 0) {
        clearInterval(this.countdownTimer);
        this.setData({ countdown: 0 });
      } else {
        this.setData({ countdown: seconds });
      }
    }, 1000);
  },

  /**
   * 检查是否可以提交表单
   */
  checkCanSubmit() {
    const { phone, verificationCode, newPassword, confirmPassword } = this.data;
    const isPhoneValid = /^1[3-9]\d{9}$/.test(phone);
    const isCodeValid = verificationCode.length === 6;
    const isPasswordValid = /^[a-zA-Z0-9]{6,20}$/.test(newPassword);
    const isConfirmValid = confirmPassword === newPassword && confirmPassword.length > 0;

    this.setData({
      canSubmit: isPhoneValid && isCodeValid && isPasswordValid && isConfirmValid
    });
  },

  /**
   * 重置密码
   */
  resetPassword() {
    const { phone, verificationCode, newPassword } = this.data;

    // 表单验证
    if (!this.data.canSubmit) {
      return;
    }

    // 设置提交状态
    this.setData({ isSubmitting: true });

    // 模拟重置密码请求
    setTimeout(() => {
      // 重置提交状态
      this.setData({ isSubmitting: false });
      
      console.log('重置密码:', { phone, verificationCode, newPassword });
      
      // 实际应用中，这里应该调用重置密码的API
      // wx.request({
      //   url: 'your-api-url',
      //   method: 'POST',
      //   data: { phone, verificationCode, newPassword },
      //   success: (res) => {
      //     this.setData({ isSubmitting: false });
      //     if (res.data.success) {
      //       wx.showToast({
      //         title: '密码重置成功',
      //         icon: 'success',
      //         duration: 2000,
      //         success: () => {
      //           setTimeout(() => {
      //             wx.navigateBack();
      //           }, 2000);
      //         }
      //       });
      //     } else {
      //       this.setData({
      //         errorMsg: res.data.message || '密码重置失败',
      //         successMsg: ''
      //       });
      //     }
      //   },
      //   fail: (err) => {
      //     this.setData({ isSubmitting: false });
      //     console.error('重置密码失败', err);
      //     this.setData({
      //       errorMsg: '网络错误，请稍后重试',
      //       successMsg: ''
      //     });
      //   }
      // });

      // 模拟成功响应
      wx.showToast({
        title: '密码重置成功',
        icon: 'success',
        duration: 2000,
        success: () => {
          setTimeout(() => {
            wx.navigateBack();
          }, 2000);
        }
      });
    }, 1500);
  },

  /**
   * 返回上一页
   */
  goBack() {
    wx.navigateBack();
  }
});