// pages/role-select/role-select.js - 身份选择页面逻辑
Page({
    data: {
      // 角色数据，包含ID、名称和图标文字
      roles: [
        { id: 'restaurant', name: '社区餐厅', iconText: '🍽️' },
        { id: 'elder', name: '老人', iconText: '👴' },
        { id: 'volunteer', name: '志愿者', iconText: '🤝' },
        { id: 'family', name: '子女', iconText: '👧' }
      ],
      selectedRole: null // 当前选中的角色
    },

    // 选择角色
    selectRole(e) {
      const roleId = e.currentTarget.dataset.id;
      const selectedRole = this.data.roles.find(role => role.id === roleId);
      
      this.setData({ selectedRole });
    },

    // 确认身份选择
    onConfirm: function() {
      if (!this.data.selectedRole) {
        wx.showToast({ title: '请选择身份', icon: 'none' });
        return;
      }
      
      const role = this.data.selectedRole;
      
      // 保存选择的角色到本地存储
      wx.setStorageSync('selectedRole', role);
      
      // 所有角色都跳转到登录页面
      wx.reLaunch({
        url: '/pages/login/login'
      });
    },
    
    // 跳转到注册页面
    goToRegister: function() {
      wx.navigateTo({
        url: '/pages/register/register'
      });
    },

    // 页面加载时检查是否已登录
    onLoad: function() {
      const token = wx.getStorageSync('authToken');
      const userRole = wx.getStorageSync('userRole');
      
      if (token && userRole) {
        // 已登录，获取对应的角色ID
        const roleId = this.getRoleIdByName(userRole);
        if (roleId) {
          // 根据角色跳转到对应的首页
          let targetPage = '/pages/old-index/order-index'; // 默认老人端首页
          if (roleId === 'restaurant') {
            targetPage = '/pages/restaurant/index';
          } else if (roleId === 'volunteer') {
            targetPage = '/pages/volunteer/index';
          } else if (roleId === 'family') {
            targetPage = '/pages/family/family_index';
          }
          
          wx.reLaunch({ url: targetPage });
        }
      }
    },
    
    // 根据角色名称获取角色ID
    getRoleIdByName(roleName) {
      const roleMap = {
        '社区餐厅': 'restaurant',
        '老人': 'elder',
        '志愿者': 'volunteer',
        '子女':'family'
      };
      return roleMap[roleName] || null;
    }
  });
  