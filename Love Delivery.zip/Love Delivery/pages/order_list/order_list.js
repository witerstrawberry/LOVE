// pages/order_list/order_list.js
const { orderAPI } = require('../../utils/api');
const { getFullImageUrl } = require('../../utils/imageUtils');

Page({
  data: {
    orders: [],
    allOrders: [], // 保存所有订单，用于筛选
    loading: false,
    errorMessage: '',
    userInfo: null,
    roleId: null,
    filterType: 'all' // 筛选类型：all, pending, completed, cancelled
  },

  onLoad(options) {
    console.log('订单列表页面加载，参数:', options);
    
    // 获取筛选类型
    const filterType = options.type || 'all';
    
    // 获取用户信息和角色ID
    const userInfo = wx.getStorageSync('userInfo') || {};
    const roleId = userInfo.role_id || userInfo.roleId || null;
    
    this.setData({
      userInfo: userInfo,
      roleId: roleId,
      filterType: filterType
    });
    
    // 加载订单列表
    this.loadOrderList();
  },

  onShow() {
    // 页面显示时，如果有已保存的订单数据，直接应用筛选
    // 否则重新加载订单列表
    if (this.data.allOrders && this.data.allOrders.length > 0) {
      this.filterOrdersByType(this.data.allOrders);
    } else {
      this.loadOrderList();
    }
  },

  onPullDownRefresh() {
    this.loadOrderList();
  },

  // 加载订单列表
  loadOrderList() {
    if (this.data.loading) return;

    this.setData({
      loading: true,
      errorMessage: ''
    });

    // 构建请求参数 - 获取所有订单，按日期倒序
    const params = {
      page: 1,
      pageSize: 100 // 后端限制最大为100
    };
    
    console.log('请求订单列表，参数:', params);
    
    orderAPI.getUserOrders(params)
      .then(response => {
        console.log('订单列表响应:', response);

        if (response && response.data && response.data.orders) {
          // 格式化订单数据
          const formattedOrders = response.data.orders.map(order => {
            // 解析商品列表
            let items = [];
            if (order.items) {
              if (typeof order.items === 'string') {
                try {
                  items = JSON.parse(order.items);
                } catch (e) {
                  items = [];
                }
              } else if (Array.isArray(order.items)) {
                items = order.items;
              }
            }
            
            // 处理商品数据，确保包含图片和规格信息
            items = items.map(item => {
              // 处理图片URL
              const imageUrl = item.image_url ? getFullImageUrl(item.image_url) : '/images/default-avatar.png';
              
              return {
                ...item,
                image_url: imageUrl,
                specification: item.specification || item.category_name || '',
                color: item.specification || item.category_name || ''
              };
            });
            
            // 计算商品总数
            const totalItems = items.reduce((sum, item) => sum + (item.quantity || 0), 0);
            
            // 判断订单是否由子女代点（当前用户是老人，但订单的user_id不是当前用户）
            const isOrderedByChild = this.data.roleId === 1 && 
                                     order.user_id && 
                                     order.user_id !== this.data.userInfo?.id;
            
            return {
              ...order,
              id: order.id || order.order_id,
              statusText: this.getStatusText(order.status),
              statusClass: this.getStatusClass(order.status),
              formattedAmount: parseFloat(order.total_amount || 0).toFixed(2),
              formattedTime: this.formatTime(order.created_at),
              items: items,
              totalItems: totalItems,
              merchantName: order.merchant_name || '商家',
              merchantLogo: order.merchant_logo ? getFullImageUrl(order.merchant_logo) : '',
              deliveryFee: parseFloat(order.delivery_fee || 0).toFixed(2),
              // 添加下单人信息
              orderedBy: order.user_nickname || order.user_name || '未知',
              isOrderedByChild: isOrderedByChild
            };
          });

          // 按日期倒序排列（最新的在前）
          formattedOrders.sort((a, b) => {
            const dateA = new Date(a.created_at || 0);
            const dateB = new Date(b.created_at || 0);
            return dateB - dateA;
          });

          // 保存所有订单
          this.setData({
            allOrders: formattedOrders
          });
          
          // 根据筛选类型过滤订单
          this.filterOrdersByType(formattedOrders);
        } else {
          this.setData({
            orders: [],
            loading: false,
            errorMessage: '暂无订单数据'
          });
        }
      })
      .catch(error => {
        console.error('获取订单列表失败:', error);
        this.setData({
          loading: false,
          errorMessage: '获取订单列表失败，请重试'
        });

        wx.showToast({
          title: '获取订单列表失败',
          icon: 'none',
          duration: 2000
        });
      })
      .finally(() => {
        wx.stopPullDownRefresh();
      });
  },

  // 查看订单详情
  viewOrderDetail(e) {
    const orderId = e.currentTarget.dataset.id;
    const order = this.data.orders.find(o => (o.id || o.order_id) == orderId);
    
    if (!orderId) {
      wx.showToast({
        title: '订单ID不存在',
        icon: 'none'
      });
      return;
    }
    
    // 携带身份信息和订单信息跳转到订单详情页面
    const params = {
      id: orderId,
      roleId: this.data.roleId || '',
      userId: this.data.userInfo?.id || '',
      orderNo: order?.order_no || ''
    };
    
    const queryString = Object.keys(params)
      .map(key => `${key}=${encodeURIComponent(params[key])}`)
      .join('&');
    
    wx.navigateTo({
      url: `/pages/old-detail/order-detail?${queryString}`
    });
  },

  // 取消订单
  cancelOrder(e) {
    const orderId = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个订单吗？',
      success: (res) => {
        if (res.confirm) {
          this.executeCancelOrder(orderId);
        }
      }
    });
  },

  // 执行取消订单
  executeCancelOrder(orderId) {
    wx.showLoading({
      title: '取消中...'
    });

    orderAPI.cancelOrder(orderId)
      .then(response => {
        wx.hideLoading();
        wx.showToast({
          title: '订单已取消',
          icon: 'success'
        });
        this.loadOrderList();
      })
      .catch(error => {
        wx.hideLoading();
        console.error('取消订单失败:', error);
        wx.showToast({
          title: '取消失败，请重试',
          icon: 'none'
        });
      });
  },

  // 删除订单
  deleteOrder(e) {
    const orderId = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个订单吗？删除后无法恢复。',
      success: (res) => {
        if (res.confirm) {
          this.executeDeleteOrder(orderId);
        }
      }
    });
  },

  // 执行删除订单
  executeDeleteOrder(orderId) {
    wx.showLoading({
      title: '删除中...'
    });

    orderAPI.deleteOrder(orderId)
      .then(response => {
        wx.hideLoading();
        wx.showToast({
          title: '订单已删除',
          icon: 'success'
        });
        this.loadOrderList();
      })
      .catch(error => {
        wx.hideLoading();
        console.error('删除订单失败:', error);
        wx.showToast({
          title: '删除失败，请重试',
          icon: 'none'
        });
      });
  },

  // 查看物流
  viewLogistics(e) {
    const orderId = e.currentTarget.dataset.id;
    // 跳转到物流详情页面（如果存在）
    wx.navigateTo({
      url: `/pages/old-detail/order-detail?id=${orderId}`
    });
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      'pending': '待付款',
      'paid': '顾客已下单',
      'customer_accepted': '顾客已确认',
      'merchant_accepted': '商家已接单',
      'waiting_volunteer': '等待志愿者接单',
      'volunteer_accepted': '志愿者已接单',
      'arrived_restaurant': '已到达餐厅',
      'shipped': '配送中',
      'delivered': '已送达',
      'completed': '已完成',
      'cancelled': '已取消',
      'refunded': '已退款'
    };
    return statusMap[status] || status || '未知状态';
  },

  // 获取状态样式类
  getStatusClass(status) {
    const classMap = {
      'pending': 'status-pending',
      'paid': 'status-paid',
      'customer_accepted': 'status-paid',
      'merchant_accepted': 'status-shipping',
      'waiting_volunteer': 'status-shipping',
      'volunteer_accepted': 'status-shipping',
      'arrived_restaurant': 'status-shipping',
      'shipped': 'status-shipping',
      'delivered': 'status-delivered',
      'completed': 'status-delivered',
      'cancelled': 'status-cancelled',
      'refunded': 'status-cancelled'
    };
    return classMap[status] || 'status-default';
  },

  // 格式化时间
  formatTime(timeStr) {
    if (!timeStr) return '';
    const date = new Date(timeStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hour = String(date.getHours()).padStart(2, '0');
    const minute = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}`;
  },

  // 重试加载
  onRetry() {
    this.loadOrderList();
  },

  // 根据类型筛选订单
  filterOrdersByType(orders) {
    const { filterType } = this.data;
    let filteredOrders = orders;
    
    console.log('筛选订单，类型:', filterType, '总订单数:', orders.length);
    
    if (filterType === 'pending') {
      // 待配送：包含状态 'merchant_accepted','waiting_volunteer','volunteer_accepted','arrived_restaurant','shipped','delivered'
      const pendingStatuses = ['merchant_accepted', 'waiting_volunteer', 'volunteer_accepted', 'arrived_restaurant', 'shipped', 'delivered'];
      filteredOrders = orders.filter(order => pendingStatuses.includes(order.status));
      console.log('待配送订单数量:', filteredOrders.length);
    } else if (filterType === 'completed') {
      // 已完成：包含状态 'completed'
      filteredOrders = orders.filter(order => order.status === 'completed');
      console.log('已完成订单数量:', filteredOrders.length);
    } else if (filterType === 'cancelled') {
      // 已取消：包含状态 'cancelled','refunded'
      filteredOrders = orders.filter(order => order.status === 'cancelled' || order.status === 'refunded');
      console.log('已取消订单数量:', filteredOrders.length);
    } else {
      // all: 显示所有订单
      filteredOrders = orders;
      console.log('显示所有订单数量:', filteredOrders.length);
    }
    
    this.setData({
      orders: filteredOrders,
      loading: false
    });
  }
});

