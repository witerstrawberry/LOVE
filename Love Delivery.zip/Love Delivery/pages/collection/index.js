// pages/collection/index.js
import { favoriteAPI } from '../../utils/api';
import { getFullImageUrl } from '../../utils/imageUtils';
const { getResourceUrl } = require('../../utils/config');

// 时间格式化函数：将ISO时间字符串转换为年月日时分格式
function formatDateTime(dateString) {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return '';
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}`;
}

Page({
  data: {
    favorites: [], // 收藏列表数据
    isEmpty: false, // 是否为空状态
    errorMsg: '', // 错误信息
    isLoading: false, // 是否正在加载
    hasMore: true, // 是否有更多数据
    page: 1, // 当前页码
    limit: 10, // 每页数量
    lastRefreshTime: 0, // 上次刷新时间
    // 取消收藏按钮图片路径
    cancelIcon: getResourceUrl('/uploads/part/取消.png')
  },

  onLoad() {
    // 页面加载时重置数据并调用获取收藏列表方法
    this.setData({
      favorites: [],
      page: 1,
      hasMore: true,
      isEmpty: false,
      errorMsg: '',
      isLoading: false,
      lastRefreshTime: 0
    });
    this.loadFavorites();
  },

  onShow() {
    // 页面显示时刷新数据，确保显示最新数据
    // 如果距离上次刷新超过3秒，或者没有数据，则刷新
    const timeSinceLastRefresh = Date.now() - this.data.lastRefreshTime;
    if (timeSinceLastRefresh > 3000 || this.data.favorites.length === 0) {
      this.refreshFavorites();
    }
  },

  onReachBottom() {
    // 上拉加载更多
    if (!this.data.isLoading && this.data.hasMore) {
      this.loadFavorites();
    }
  },
  
  // 下拉刷新
  onPullDownRefresh() {
    console.log('执行下拉刷新');
    this.refreshFavorites().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 刷新收藏列表（重置分页并重新加载）
  refreshFavorites() {
    console.log('刷新收藏列表');
    this.setData({
      favorites: [],
      page: 1,
      hasMore: true,
      isEmpty: false,
      errorMsg: '',
      lastRefreshTime: 0
    });
    return this.loadFavorites();
  },

  // 加载收藏列表
  loadFavorites() {
    return new Promise((resolve, reject) => {
      // 如果正在加载中，则不重复请求
      if (this.data.isLoading) {
        console.log('正在加载中，请勿重复请求');
        resolve();
        return;
      }

      // 记录请求条件
      const { page, limit } = this.data;
      console.log(`请求收藏列表：page=${page}, limit=${limit}`);

      // 设置加载状态
      this.setData({
        isLoading: true
      });

      // 检查是否有登录令牌
      const token = wx.getStorageSync('token');
      console.log('登录状态检查：', token ? '已登录' : '未登录');

      // 只在开发调试模式下使用测试token，生产环境不使用
      const isDevMode = wx.getStorageSync('useDevMockData') || false;
      if (!token && isDevMode) {
        console.warn('开发模式：未找到登录token，使用测试token进行请求');
        const testToken = 'test-token-for-coupon-restore'; // 后端允许的测试token
        wx.setStorageSync('token', testToken);
      } else if (!token) {
        console.warn('未找到登录token，请先登录');
        this.setData({
          errorMsg: '请先登录',
          isLoading: false,
          favorites: []
        });
        reject(new Error('未登录'));
        return;
      }

      // 调用API获取收藏列表，注意：这里需要传递参数对象
      favoriteAPI.getUserFavorites({ page, limit })
        .then(res => {
          console.log('API返回结果：', res);

          // 检查响应数据格式
          if (res && res.data && Array.isArray(res.data.favorites)) {
            console.log('数据格式正确，包含favorites数组');
            
            const newFavorites = res.data.favorites;
            // 为每个收藏项添加默认字段处理，并处理图片URL
            const processedFavorites = newFavorites.map(item => ({
              ...item,
              // 商家基本信息
              name: item.name || '商家名称',
              logo: item.logo ? getFullImageUrl(item.logo) : '',
              image_url: item.logo ? getFullImageUrl(item.logo) : (item.image_url ? getFullImageUrl(item.image_url) : ''),
              rating: item.rating || 0,
              address: item.address || '',
              is_open: item.is_open !== undefined ? item.is_open : true,
              // ID相关字段
              favorite_id: item.favorite_id || item.id || '',
              merchant_id: item.merchant_id || item.merchantId || '',
              // 收藏时间
              favorite_time: formatDateTime(item.favorite_time || item.created_at || '')
            }));
            
            const favorites = page === 1 ? processedFavorites : [...this.data.favorites, ...processedFavorites];
            
            this.setData({
              favorites: favorites,
              isEmpty: favorites.length === 0,
              hasMore: res.data.page < res.data.totalPages,
              page: res.data.page + 1,
              isLoading: false,
              lastRefreshTime: Date.now()
            });
          } else {
            console.error('数据格式错误，期望包含favorites数组的对象');
            // 设置默认空数据
            this.setData({
              favorites: [],
              isEmpty: true,
              isLoading: false
            });
          }
          resolve();
        })
        .catch(err => {
          console.error('获取收藏列表失败：', err);
          
          // 根据不同的错误类型显示不同的错误信息
          let errorMsg = '获取收藏列表失败，请重试';
          if (err.statusCode === 401) {
            errorMsg = '请先登录';
            // 清除无效的token
            wx.removeStorageSync('token');
          } else if (err.statusCode === 400) {
            errorMsg = '请求参数错误';
          } else if (err.statusCode === 500) {
            errorMsg = '服务器内部错误';
          }
          
          this.setData({
            errorMsg: errorMsg,
            isLoading: false,
            favorites: [] // 确保favorites始终是数组
          });
          reject(err);
        });
    });
  },

  // 取消收藏
  cancelFavorite(e) {
    const { id } = e.currentTarget.dataset;
    console.log('取消收藏：', id);

    // 验证ID是否存在
    if (!id) {
      console.error('取消收藏失败：未获取到商家ID');
      wx.showToast({
        title: '取消收藏失败：缺少商家ID',
        icon: 'none',
        duration: 2000
      });
      return;
    }

    // 确保ID是字符串格式（后端要求）
    const merchantId = String(id);
    console.log('取消收藏商家ID（字符串格式）：', merchantId);

    // 显示加载提示
    wx.showLoading({
      title: '取消收藏中...',
    });

    favoriteAPI.removeFavorite(merchantId)
      .then(result => {
        console.log('取消收藏结果：', result);
        
        // 检查结果是否成功
        if (result && result.success) {
          // 更新收藏列表
          const updatedFavorites = this.data.favorites.filter(item => {
            // 兼容多种ID格式，优先使用merchant_id匹配
            return item.merchant_id !== merchantId && 
                   item.merchantId !== merchantId &&
                   item.id !== merchantId && 
                   item.product_id !== merchantId && 
                   item.favorite_id !== merchantId;
          });
          
          this.setData({
            favorites: updatedFavorites,
            isEmpty: updatedFavorites.length === 0,
            // 如果列表为空，重置分页状态
            hasMore: updatedFavorites.length > 0 ? this.data.hasMore : false,
            page: updatedFavorites.length > 0 ? this.data.page : 1
          });
          
          wx.showToast({
            title: '取消收藏成功',
            icon: 'success',
            duration: 2000
          });
        } else {
          console.error('取消收藏失败：返回结果不正确');
          wx.showToast({
            title: '取消收藏失败',
            icon: 'none',
            duration: 2000
          });
          throw new Error('取消收藏失败：返回结果不正确');
        }
      })
      .catch(err => {
        console.error('取消收藏异常：', err);
        wx.showToast({
          title: '取消收藏失败，请重试',
          icon: 'none',
          duration: 2000
        });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  // 跳转到商家详情页
  goToMerchantDetail(e) {
    const { id } = e.currentTarget.dataset;
    console.log('跳转到商家详情页，ID:', id);
    if (!id) {
      wx.showToast({
        title: '商家ID不存在',
        icon: 'none',
        duration: 2000
      });
      return;
    }
    // 跳转到商家点餐页面
    wx.navigateTo({
      url: `/pages/family/order-food?merchantId=${id}`
    });
  },

  // 跳转到首页
  goToHome() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  }
});