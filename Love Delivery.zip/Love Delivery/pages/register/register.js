// pages/register/register.js
const { authAPI } = require('../../utils/api.js');
const { getFullImageUrl } = require('../../utils/imageUtils.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    phone: '',        // 手机号
    nickname: '',     // 昵称
    password: '',     // 密码
    showPassword: false, // 是否显示密码
    roles: [
      { id: 'elder', name: '老人', roleId: 1 },
      { id: 'volunteer', name: '志愿者', roleId: 3 },
      { id: 'restaurant', name: '商家', roleId: 2 },
      { id: 'child', name: '子女', roleId: 4 }
    ],
    selectedRole: '',  // 选中的角色ID
    selectedRoleId: null, // 角色对应的数字ID
    avatarUrl: '',     // 头像临时文件路径
    avatarFile: null   // 头像文件对象
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 页面卸载时的清理工作
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    wx.stopPullDownRefresh();
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  /**
   * 手机号输入处理
   */
  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  /**
   * 昵称输入处理
   */
  onNicknameInput(e) {
    this.setData({ nickname: e.detail.value });
  },

  /**
   * 角色选择处理
   */
  onRoleChange(e) {
    const role = this.data.roles[e.detail.value];
    this.setData({
      selectedRole: role.id,
      selectedRoleId: role.roleId
    });
  },

  /**
   * 密码输入处理
   */
  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  /**
   * 切换密码可见性
   */
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    });
  },

  /**
   * 选择头像
   */
  chooseAvatar() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      sizeType: ['compressed'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        this.setData({
          avatarUrl: tempFilePath,
          avatarFile: res.tempFiles[0]
        });
      },
      fail: (err) => {
        console.error('选择头像失败:', err);
        wx.showToast({
          title: '选择头像失败',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 上传头像
   * @returns {Promise} 返回上传后的图片URL
   */
  uploadAvatar() {
    return new Promise((resolve, reject) => {
      if (!this.data.avatarFile) {
        resolve('');
        return;
      }

      wx.showLoading({
        title: '上传头像中...',
      });

      wx.uploadFile({
        url: getApp().globalData.baseUrl + '/upload/avatar',
        filePath: this.data.avatarFile.tempFilePath,
        name: 'avatar',
        formData: {
          'user': 'register'
        },
        success: (res) => {
          wx.hideLoading();
          try {
            const data = JSON.parse(res.data);
            if (data.success) {
              // 使用getFullImageUrl处理头像URL，确保替换localhost:3000为正确的云服务器域名
              const processedUrl = getFullImageUrl(data.data.url);
              resolve(processedUrl);
            } else {
              wx.showToast({ title: '上传失败', icon: 'none' });
              reject(new Error('上传失败'));
            }
          } catch (e) {
            console.error('解析响应失败:', e);
            wx.showToast({ title: '上传失败，请重试', icon: 'none' });
            reject(new Error('解析响应失败'));
          }
        },
        fail: (err) => {
          wx.hideLoading();
          console.error('上传头像失败:', err);
          wx.showToast({ title: '网络错误，请稍后重试', icon: 'none' });
          reject(err);
        }
      });

      /* 实际项目中应该使用以下代码上传头像
      wx.uploadFile({
        url: getApp().globalData.baseUrl + '/upload/avatar',
        filePath: this.data.avatarFile.tempFilePath,
        name: 'avatar',
        formData: {
          'user': 'test'
        },
        success: (res) => {
          wx.hideLoading();
          const data = JSON.parse(res.data);
          if (data.success) {
            resolve(data.data.url);
          } else {
            wx.showToast({
              title: '上传失败',
              icon: 'none'
            });
            reject(new Error('上传失败'));
          }
        },
        fail: (err) => {
          wx.hideLoading();
          console.error('上传头像失败:', err);
          wx.showToast({
            title: '上传失败',
            icon: 'none'
          });
          reject(err);
        }
      });
      */
    });
  },

  // 移除了验证码相关方法

  /**
   * 注册处理
   */
  register() {
    const { phone, nickname, password, selectedRole, selectedRoleId } = this.data;

    // 输入验证
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
      return;
    }

    if (!nickname || nickname.trim().length < 2) {
      wx.showToast({ title: '昵称不能少于2位', icon: 'none' });
      return;
    }

    if (!password || password.length < 6) {
      wx.showToast({ title: '密码不能少于6位', icon: 'none' });
      return;
    }

    if (!selectedRole) {
      wx.showToast({ title: '请选择您的身份', icon: 'none' });
      return;
    }

    // 显示加载提示
    wx.showLoading({ title: '注册中...' });

    // 先上传头像，再进行注册
    this.uploadAvatar().then((avatarUrl) => {
      // 准备注册数据
      const registerData = {
        phone: phone,
        nickname: nickname.trim(),
        password: password,
        avatar: avatarUrl || '',
        role_id: selectedRoleId
      };

      console.log('注册数据:', registerData);
      console.log('调用注册API，数据格式检查:');
      console.log('- phone类型:', typeof registerData.phone);
      console.log('- nickname类型:', typeof registerData.nickname);
      console.log('- password类型:', typeof registerData.password);
      console.log('- avatar类型:', typeof registerData.avatar);
      console.log('- role_id类型:', typeof registerData.role_id, '值:', registerData.role_id);

      // 调用后端注册API
      authAPI.register(registerData)
        .then(res => {
          wx.hideLoading();
          console.log('注册API返回:', JSON.stringify(res));

          if (res.success || res.data && res.data.success) {
            // 注册成功，保存用户信息和角色到本地存储
            wx.setStorageSync('userInfo', {
              phone: phone,
              nickname: nickname.trim(),
              avatar: avatarUrl || '',
              registerTime: new Date().getTime()
            });

            // 保存用户选择的角色
            wx.setStorageSync('selectedRole', {
              id: selectedRole,
              name: this.data.roles.find(r => r.id === selectedRole).name
            });

            // 显示注册成功提示
            wx.showToast({ title: '注册成功', icon: 'success' });

            // 延迟跳转到登录页面
            setTimeout(() => {
              wx.navigateTo({ url: '/pages/login/login' });
            }, 1500);
          } else {
            wx.showToast({
              title: res.message || res.data?.message || '注册失败，请重试',
              icon: 'none'
            });
          }
        })
        .catch(error => {
          wx.hideLoading();
          console.error('注册失败:', error);
          console.error('错误详情:', JSON.stringify(error));
          wx.showToast({
            title: '网络错误，请稍后重试',
            icon: 'none'
          });
        });
    }).catch((error) => {
      wx.hideLoading();
      console.error('注册失败:', error);
      wx.showToast({
        title: '注册失败，请重试',
        icon: 'none'
      });
    });

    // 实际项目中这里应该调用后端API进行注册
    // wx.request({
    //   url: 'https://api.example.com/register',
    //   method: 'POST',
    //   data: { phone, code, password },
    //   success: (res) => {
    //     wx.hideLoading();
    //     if (res.data.success) {
    //       // 保存登录信息
    //       wx.setStorageSync('authToken', res.data.token);
    //       wx.setStorageSync('userInfo', res.data.userInfo);
    //       
    //       wx.showToast({
    //         title: '注册成功',
    //         icon: 'success',
    //         duration: 1500,
    //         success: () => {
    //           // 延迟跳转到首页
    //           setTimeout(() => {
    //             wx.switchTab({ url: '/pages/index/index' });
    //           }, 1500);
    //         }
    //       });
    //     } else {
    //       wx.showToast({ title: res.data.message || '注册失败', icon: 'none' });
    //     }
    //   },
    //   fail: () => {
    //     wx.hideLoading();
    //     wx.showToast({ title: '网络错误，请稍后重试', icon: 'none' });
    //   }
    // });
  },

  /**
   * 跳转到登录页面
   */
  goToLogin() {
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  /**
   * 查看用户协议
   */
  viewAgreement() {
    wx.showToast({ title: '查看用户协议', icon: 'none' });
    // 实际项目中可以跳转到协议页面
  },

  /**
   * 查看隐私政策
   */
  viewPrivacy() {
    wx.showToast({ title: '查看隐私政策', icon: 'none' });
    // 实际项目中可以跳转到隐私政策页面
  }
});