// pages/family/merchant-list.js - 商家列表页面
const { get } = require('../../utils/request');
const productAPI = require('../../utils/api').productAPI;
const { getFullImageUrl } = require('../../utils/imageUtils');

Page({
  data: {
    loading: true,
    errorMessage: '',
    merchants: [],
    filteredMerchants: [],
    searchQuery: ''
  },

  onLoad(options) {
    wx.setNavigationBarTitle({
      title: '选择商家'
    });
    this.loadMerchants();
  },

  onShow() {
    // 页面显示时刷新数据
    this.loadMerchants();
  },

  /**
   * 从后端获取商家列表
   */
  loadMerchants() {
    this.setData({
      loading: true,
      errorMessage: ''
    });

    // 调用后端API获取商家列表
    // 注意：如果后端没有这个接口，需要先添加
    get('/merchant/list')
      .then(res => {
        console.log('商家列表API返回:', res);
        if (res && res.success && res.data) {
          const merchants = Array.isArray(res.data) ? res.data : (res.data.merchants || []);
          
          // 格式化商家数据
          const formattedMerchants = merchants.map(merchant => {
            // 处理商家logo图片路径
            const logoPath = merchant.logo || '';
            const fullLogoUrl = logoPath ? getFullImageUrl(logoPath) : '';
            
            return {
              id: merchant.id || merchant.merchant_id,
              name: merchant.name || '未知商家',
              category: merchant.category || '',
              address: merchant.address || '',
              phone: merchant.phone || '',
              business_hours: merchant.business_hours || '',
              description: merchant.description || '',
              rating: merchant.rating || 0,
              is_open: merchant.is_open !== undefined ? merchant.is_open : true,
              logo: fullLogoUrl,
              min_order_amount: merchant.min_order_amount || 0,
              delivery_fee: merchant.delivery_fee || 0,
              delivery_time: merchant.delivery_time || merchant.estimated_delivery_time || '60分钟', // 配送时间，默认60分钟
              products: [], // 产品列表，稍后加载
              productsLoading: false
            };
          });

          this.setData({
            merchants: formattedMerchants,
            filteredMerchants: formattedMerchants,
            loading: false
          });

          // 为每个商家加载产品列表
          this.loadProductsForMerchants(formattedMerchants);
        } else {
          throw new Error(res?.message || '获取商家列表失败');
        }
      })
      .catch(err => {
        console.error('获取商家列表失败:', err);
        this.setData({
          loading: false,
          errorMessage: err?.message || '网络错误，请稍后重试'
        });
      });
  },

  /**
   * 搜索输入处理
   */
  onSearchInput(e) {
    const query = e.detail.value.trim();
    this.setData({
      searchQuery: query
    });
    this.filterMerchants(query);
  },

  /**
   * 过滤商家列表
   */
  filterMerchants(query = '') {
    const { merchants } = this.data;
    
    if (!query) {
      this.setData({
        filteredMerchants: merchants
      });
      return;
    }

    const filtered = merchants.filter(merchant => {
      const name = (merchant.name || '').toLowerCase();
      const category = (merchant.category || '').toLowerCase();
      const address = (merchant.address || '').toLowerCase();
      const searchLower = query.toLowerCase();
      
      return name.includes(searchLower) || 
             category.includes(searchLower) || 
             address.includes(searchLower);
    });

    this.setData({
      filteredMerchants: filtered
    });
  },

  /**
   * 点击进店按钮
   */
  enterStore(e) {
    // 安全地阻止事件冒泡
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    }
    const merchantId = e.currentTarget.dataset.merchantId;
    this.selectMerchant({ currentTarget: { dataset: { merchantId } } });
  },

  /**
   * 商家logo图片加载失败处理
   */
  onMerchantLogoError(e) {
    const index = e.currentTarget.dataset.index;
    console.log('商家logo图片加载失败:', index, e);
    
    // 将logo设置为空，触发显示占位符
    const updateData = {};
    updateData[`merchants[${index}].logo`] = '';
    updateData[`filteredMerchants[${index}].logo`] = '';
    this.setData(updateData);
  },

  /**
   * 产品图片加载失败处理
   */
  onProductImageError(e) {
    console.log('产品图片加载失败:', e);
    // 图片加载失败时，可以设置默认占位图
    // 这里只是记录错误，实际显示由WXML中的占位符处理
  },

  /**
   * 为所有商家加载产品列表
   */
  loadProductsForMerchants(merchants) {
    merchants.forEach((merchant, index) => {
      this.loadMerchantProducts(merchant.id, index);
    });
  },

  /**
   * 为单个商家加载产品列表
   */
  loadMerchantProducts(merchantId, merchantIndex) {
    // 更新该商家的加载状态
    const updateKey = `merchants[${merchantIndex}].productsLoading`;
    this.setData({
      [updateKey]: true
    });

    // 获取该商家的前4个产品（用于展示）
    productAPI.getProducts({
      merchant_id: merchantId,
      page: 1,
      limit: 4
    })
      .then(res => {
        if (res && res.success && res.data) {
          // 后端返回的数据结构: { products: [...], total, page, limit, totalPages }
          const products = res.data.products || (Array.isArray(res.data) ? res.data : []);
          
          // 格式化产品数据
          const formattedProducts = products.map(product => {
            // 处理图片URL，确保是完整路径
            const originalImagePath = product.image_url || product.image || '';
            const fullImageUrl = originalImagePath ? getFullImageUrl(originalImagePath) : '';
            
            // 调试日志
            if (originalImagePath) {
              console.log(`产品 ${product.name} 图片路径处理:`, {
                原始路径: originalImagePath,
                完整URL: fullImageUrl
              });
            }
            
            return {
              id: product.id || product.product_id,
              name: product.name || '未知商品',
              price: product.price || 0,
              image: fullImageUrl,
              original_price: product.original_price || null
            };
          });

          // 更新该商家的产品列表（同时更新merchants和filteredMerchants）
          const updateData = {};
          updateData[`merchants[${merchantIndex}].products`] = formattedProducts;
          updateData[`merchants[${merchantIndex}].productsLoading`] = false;

          // 查找并更新filteredMerchants中对应的商家
          const filteredMerchants = this.data.filteredMerchants;
          for (let i = 0; i < filteredMerchants.length; i++) {
            if (filteredMerchants[i].id === merchantId) {
              updateData[`filteredMerchants[${i}].products`] = formattedProducts;
              updateData[`filteredMerchants[${i}].productsLoading`] = false;
              break;
            }
          }

          this.setData(updateData);
        } else {
          throw new Error(res?.message || '获取产品列表失败');
        }
      })
      .catch(err => {
        console.error(`获取商家 ${merchantId} 的产品列表失败:`, err);
        // 即使失败也设置空数组，避免显示错误
        const updateData = {};
        updateData[`merchants[${merchantIndex}].products`] = [];
        updateData[`merchants[${merchantIndex}].productsLoading`] = false;

        // 同时更新filteredMerchants
        const filteredMerchants = this.data.filteredMerchants;
        for (let i = 0; i < filteredMerchants.length; i++) {
          if (filteredMerchants[i].id === merchantId) {
            updateData[`filteredMerchants[${i}].products`] = [];
            updateData[`filteredMerchants[${i}].productsLoading`] = false;
            break;
          }
        }

        this.setData(updateData);
      });
  },

  /**
   * 选择商家，跳转到点餐页面
   */
  selectMerchant(e) {
    const merchantId = e.currentTarget.dataset.merchantId;
    if (!merchantId) {
      wx.showToast({
        title: '商家ID无效',
        icon: 'none'
      });
      return;
    }

    const url = `/pages/family/order-food?merchantId=${merchantId}`;
    
    // 获取当前页面栈
    const pages = getCurrentPages();
    const pageStackLength = pages.length;
    
    // 如果页面栈接近或达到上限（10层），使用 redirectTo 替代 navigateTo
    // 这样可以避免 "webview count limit exceed" 错误
    if (pageStackLength >= 9) {
      // 使用 redirectTo 替换当前页面，避免超出页面栈限制
      wx.redirectTo({
        url: url,
        fail: (err) => {
          console.error('跳转失败:', err);
          // 如果 redirectTo 也失败，尝试使用 reLaunch
          wx.reLaunch({
            url: url,
            fail: (err2) => {
              console.error('reLaunch 也失败:', err2);
              wx.showToast({
                title: '跳转失败，请重试',
                icon: 'none',
                duration: 2000
              });
            }
          });
        }
      });
    } else {
      // 页面栈未满，正常使用 navigateTo
      wx.navigateTo({
        url: url,
        fail: (err) => {
          console.error('跳转失败:', err);
          // 如果 navigateTo 失败且是因为页面栈限制，尝试使用 redirectTo
          if (err.errMsg && err.errMsg.includes('webview count limit')) {
            wx.redirectTo({
              url: url,
              fail: (err2) => {
                console.error('redirectTo 也失败:', err2);
                wx.showToast({
                  title: '跳转失败，请重试',
                  icon: 'none',
                  duration: 2000
                });
              }
            });
          } else {
            wx.showToast({
              title: '跳转失败',
              icon: 'none'
            });
          }
        }
      });
    }
  }
});

