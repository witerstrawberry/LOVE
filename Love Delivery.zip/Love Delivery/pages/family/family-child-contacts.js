// 子女联系人页面逻辑
const { elderlyInfoAPI } = require('../../utils/api');

Page({
  /**
   * 页面的初始数据
   */
  data: {
    contacts: [], // 联系人列表
    isLoading: true, // 加载状态
    errorMessage: '' // 错误信息
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function() {
    this.setData({ isLoading: true });
    // 页面加载时获取联系人列表
    this.fetchContacts();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // 每次页面显示时刷新联系人列表，确保数据最新
    this.fetchContacts();
  },

  /**
   * 从后端获取联系人列表
   */
  fetchContacts: async function() {
    try {
      this.setData({ isLoading: true, errorMessage: '' });
      
      console.log('开始获取绑定亲属列表...');
      
      // 从本地存储获取当前用户信息
      const userInfo = wx.getStorageSync('userInfo') || {};
      const childId = userInfo.id || userInfo.user_id;
      
      if (!childId) {
        throw new Error('未获取到用户信息');
      }
      
      // 调用API获取绑定的老人信息
      const response = await elderlyInfoAPI.getElderlyInfos({ childId });
      
      console.log('绑定亲属列表响应:', response);
      
      // 检查API返回格式
      if (response && response.success) {
        // 处理联系人数据
        let contactsList = [];
        
        if (response.data && response.data.items) {
          console.log('后端返回数组格式，长度:', response.data.items.length);
          
          // 转换为联系人列表格式
          contactsList = response.data.items.map(item => {
            // 构建联系人信息
            // 将关系信息添加到联系人名称中，因为模板中的关系字段被隐藏了
            const relationship = item.relative_relation || '';
            const baseName = item.user_name || item.user_nickname || '未设置姓名';
            const displayName = relationship ? `${baseName} (${relationship})` : baseName;
            
            return {
              id: item.id, // 使用记录ID作为联系人ID
              nickname: displayName, // 将关系信息添加到昵称中显示
              contact_name: displayName, // 将关系信息添加到联系人名称中显示
              contact_phone: item.user_old_phone || item.user_phone || '未设置电话', // 优先使用user_old_phone，其次使用user表中的phone
              relationship: relationship, // 与老人的关系，直接使用elder_info表中的relative_relation字段
              is_primary: false, // 设置为false，不显示主要联系人标签
              contact_role_id: 1, // 老人角色ID
              contact_role_name: '', // 设置为空字符串，不显示角色信息
              // 保留原始记录的ID，用于后续操作
              contact_record_id: item.id,
              // 保留原始记录
              original_record: item
            };
          });
        }
        
        this.setData({
          contacts: contactsList,
          isLoading: false
        });
        
        // 如果有联系人，显示第一个联系人的详细信息用于调试
        if (contactsList.length > 0) {
          console.log('第一个老人详细信息:', JSON.stringify(contactsList[0], null, 2));
        }
      } else {
        // API返回失败
        console.error('API返回失败:', response);
        this.handleError(response?.message || '获取绑定亲属列表失败');
      }
    } catch (error) {
      console.error('获取绑定亲属列表时发生错误:', error);
      this.handleError(error?.message || '网络错误，请稍后重试');
    }
  },

  /**
   * 处理错误
   * @param {string} message 错误信息
   */
  handleError: function(message) {
    this.setData({
      errorMessage: message,
      isLoading: false,
      contacts: [] // 清空联系人列表
    });
    
    // 显示错误提示
    wx.showToast({
      title: message,
      icon: 'none',
      duration: 3000
    });
  },

  /**
   * 返回上一页
   */
  goBack: function() {
    wx.navigateBack({
      delta: 1
    });
  },

  /**
   * 显示联系人详情
   * @param {Object} e 事件对象
   */
  showContactDetail: function(e) {
    const contactId = e.currentTarget.dataset.id;
    console.log('查看联系人详情:', contactId);
    
    // 查找对应的联系人
    const contact = this.data.contacts.find(item => item.id === contactId);
    if (contact) {
      console.log('联系人详情数据:', contact);
      
      // 构建更清晰的详情文本
      const name = contact.nickname || contact.contact_name || '未设置昵称';
      const relationship = contact.relationship || '未设置';
      const phone = contact.contact_phone || '未设置电话';
      
      // 构建格式化的详情内容
      const detailContent =  `👥 关系：${relationship}\n\n📞 电话：${phone}` ;
      
      // 显示联系人详情模态框
      wx.showModal({
        title: `👤 ${name}`,
        content: detailContent,
        showCancel: false,
        confirmText: '知道了',
        confirmColor: '#4CAF50',
        success: function(res) {
          if (res.confirm) {
            console.log('用户查看详情完毕');
          }
        }
      });
      
      // 如果有电话号码，可以提供快速拨打选项
      if (phone && phone !== '未设置电话') {
        setTimeout(() => {
          wx.showActionSheet({
            itemList: ['拨打电话'],
            success: function(res) {
              if (res.tapIndex === 0) {
                wx.makePhoneCall({
                  phoneNumber: phone,
                  fail: function(err) {
                    console.error('拨打电话失败:', err);
                  }
                });
              }
            }
          });
        }, 500); // 延迟显示，让用户先看到详情
      }
    } else {
      console.warn('未找到联系人:', contactId);
      wx.showToast({
        title: '未找到联系人信息',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    }
  },

  /**
   * 下拉刷新处理
   */
  onPullDownRefresh: function() {
    console.log('下拉刷新');
    this.fetchContacts().finally(() => {
      // 停止下拉刷新
      wx.stopPullDownRefresh();
    });
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    // 如果有分页功能，可以在这里实现加载更多
    console.log('上拉触底');
  }
});