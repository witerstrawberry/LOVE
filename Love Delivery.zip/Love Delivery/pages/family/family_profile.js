const { pointsAPI, addressAPI } = require('../../utils/api');
const { getResourceUrl } = require('../../utils/config');

Page({
  data: {
    loading: true,
    error: '',
    userInfo: {
      id: '',
      name: '',
      role: '',
      avatar: '/images/default-avatar.png',
      phone: ''
    },
    relativesCount: 0,
    addressesCount: 0,
    points: 0, // 积分余额
    notifications: {
      orderProgress: true,
      promotion: true,
      delivery: true
    },
    showSettingsModal: false,
    showHelpModal: false,
    // 功能菜单图标路径
    menuIcons: {
      relatives: getResourceUrl('/uploads/part/jia.png'),
      addresses: getResourceUrl('/uploads/part/我的地址.png'),
      help: getResourceUrl('/uploads/part/帮助中心.png'),
      settings: getResourceUrl('/uploads/part/系统设置.png')
    }
  },

  onLoad: function() {
    this.fetchProfileData();
  },

  // 格式化用户ID，以C开头，占6位，自动补零
  formatUserId: function(id) {
    // 确保id是字符串
    const strId = String(id || '');
    // 补零到6位
    const paddedId = strId.padStart(6, '0');
    // 返回以C开头的格式化ID
    return `C${paddedId}`;
  },

  fetchProfileData: function() {
    this.setData({ loading: true, error: '' });
    
    // 从本地存储获取用户信息
    const userInfo = wx.getStorageSync('userInfo') || {};
    const userId = userInfo.id || userInfo.user_id || '';
    
    // 格式化用户ID
    const formattedUserId = this.formatUserId(userId);
    
    // 设置基础用户信息
    this.setData({
      userInfo: {
        id: userId, // 保存原始用户ID
        formattedId: formattedUserId, // 保存格式化后的用户ID
        name: userInfo.name || userInfo.nickname || '用户',
        role: userInfo.role || '子女',
        avatar: userInfo.avatar || '/images/default-avatar.png',
        phone: userInfo.phone || ''
      },
      relativesCount: 0, // 初始值，实际使用时可以从其他接口获取
      addressesCount: 0, // 初始值，实际使用时可以从其他接口获取
      notifications: {
        orderProgress: true,
        promotion: true,
        delivery: true
      }
    });
    
    // 调用积分API获取用户积分
    const promises = [
      pointsAPI.getUserPointsBalance()
        .then(res => {
          if (res && res.success && res.data) {
            // 设置积分数据
            this.setData({
              points: res.data.balance || 0
            });
          }
        })
        .catch(error => {
          console.warn('获取积分数据失败，使用默认值:', error);
          // 使用默认值
          this.setData({
            points: 0
          });
        })
    ];
    
    // 如果有用户ID，获取地址数量
    if (userId) {
      promises.push(
        addressAPI.getAddressList({ userId, page: 1, pageSize: 1 })
          .then(res => {
            if (res && res.success && res.data) {
              // 设置地址数量
              this.setData({
                addressesCount: res.data.total || 0
              });
            }
          })
          .catch(error => {
            console.warn('获取地址数量失败，使用默认值:', error);
            // 使用默认值
            this.setData({
              addressesCount: 0
            });
          })
      );
    }
    
    // 等待所有请求完成后结束加载状态
    Promise.all(promises)
      .finally(() => {
        this.setData({
          loading: false
        });
      });
  },

  // 刷新数据
  refreshData: function() {
    this.fetchProfileData();
  },

  // 模块项点击事件
  onModuleItemTap: function(e) {
    const type = e.currentTarget.dataset.type;
    
    switch (type) {
      case 'relatives':
        wx.navigateTo({
          url: '/pages/family/family-child-contacts'
        });
        break;
      case 'addresses':
        const userId = this.data.userInfo.id;
        wx.navigateTo({
          url: `/pages/old_address/addresses?userId=${userId}`
        });
        break;

      case 'help':
        this.showHelpCenter();
        break;
      case 'settings':
        this.showSettings();
        break;
    }
  },



  // 显示帮助中心
  showHelpCenter: function() {
    wx.navigateTo({
      url: '/pages/help-center/index'
    });
  },

  // 显示设置
  showSettings: function() {
    this.setData({ showSettingsModal: true });
  },

  // 关闭设置
  closeSettingsModal: function() {
    this.setData({ showSettingsModal: false });
  },

  // 切换通知设置
  toggleNotification: function(e) {
    const type = e.currentTarget.dataset.type;
    const value = e.detail.value;
    
    this.setData({
      [`notifications.${type}`]: value
    });
    
    // 保存设置到本地存储
    wx.setStorageSync('notificationSettings', this.data.notifications);
  },

  // 显示关于我们
  showAbout: function() {
    wx.showModal({
      title: '关于我们',
      content: '爱在送达 v1.0.0\n让关爱更简单\n\n为子女提供便捷的父母点餐服务，\n让爱不再受距离限制。',
      showCancel: false
    });
  },

  // 打开客服
  openCustomerService: function() {
    wx.showModal({
      title: '联系客服',
      content: '请选择客服方式',
      showCancel: true,
      cancelText: '在线咨询',
      confirmText: '电话客服',
      success: (res) => {
        if (res.confirm) {
          // 拨打电话客服
          wx.makePhoneCall({
            phoneNumber: '400-123-4567'
          });
        } else if (res.cancel) {
          // 在线咨询
          wx.navigateTo({
            url: '/pages/family/online-service/online-service'
          });
        }
      }
    });
  },

  // 提交反馈
  submitFeedback: function() {
    wx.navigateTo({
      url: '/pages/family/feedback/feedback'
    });
  },

  // 退出登录
  logout: function() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除登录状态
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          
          // 跳转到登录页面
          wx.redirectTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  }
});