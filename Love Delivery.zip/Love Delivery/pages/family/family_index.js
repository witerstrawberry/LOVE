// pages/family/family_index.js
const { elderlyInfoAPI, orderAPI } = require('../../utils/api');
const userStores = require('../../stores/userStores');

const DEFAULT_QUICK_ACTIONS = [
  { id: '1', name: '家人就餐', icon: '🍔', color: '#FF6B6B' },
  { id: '2', name: '健康记录', icon: '📊', color: '#4ECDC4' },
  { id: '3', name: '订单历史', icon: '📋', color: '#96CEB4' }
];

const LIST_SPLIT_REGEXP = /[，,、;；\s]+/;

// 日期格式化函数，将日期转换为标准格式：年月日时分秒
const formatDate = (dateString) => {
  if (!dateString) return '--';
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return '--';
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

const splitToList = (value = '') => {
  if (!value) {
    return [];
  }
  return value
    .split(LIST_SPLIT_REGEXP)
    .map(item => item.trim())
    .filter(Boolean);
};

const getDefaultRelativeForm = () => ({
  userId: '',
  userName: '',
  userOldPhone: '',
  relativeRelation: '',
  isCommonOrder: false,
  bloodSugar: '',
  bloodPressure: '',
  allergen: '',
  dietForbidden: '',
  // 兼容旧字段，避免其他逻辑报错
  name: '',
  phone: '',
  idCard: '',
  addresses: [],
  newAddress: '',
  isDefaultAddress: false
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 亲属列表
    relatives: [],
    // 过滤后的亲属列表（用于搜索）
    filteredRelatives: [],
    // 新增亲属表单数据
    newRelative: getDefaultRelativeForm(),
    // 新增健康数据表单
    newHealthData: {
      bloodSugar: '',
      bloodPressure: '',
      allergies: '',
      dietRestrictions: '',
      date: ''
    },
    // 关系选项
    relationshipOptions: ['父亲', '母亲', '祖父母', '外祖父母', '其他长辈'],
    // 模态框状态
    showAddModal: false,
    showEditModal: false,
    showAddressModal: false,
    showHealthModal: false,
    editingRelativeId: '',
    // 搜索查询
    searchQuery: '',
    // 统计信息
    stats: {
      totalRelatives: 0,
      favoriteDiners: 0,
      recentOrders: 0,
      healthChecks: 0
    },
    // 快捷功能
    quickActions: DEFAULT_QUICK_ACTIONS
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 页面加载时的初始化逻辑
    this.refreshFamilyData();
  },

  /**
   * 搜索输入处理
   */
  onSearchInput(e) {
    this.setData({
      searchQuery: e.detail.value
    });
    // 实时搜索
    this.filterRelatives();
  },

  /**
   * 根据搜索关键词过滤亲属列表
   */
  filterRelatives() {
    const { relatives, searchQuery } = this.data;
    
    if (!searchQuery) {
      this.setData({
        filteredRelatives: relatives
      });
      return;
    }
    
    const keyword = searchQuery.toLowerCase();
    const filtered = relatives.filter(item => {
      // 搜索姓名、关系、电话等字段
      const name = item.name.toLowerCase();
      const relationship = item.relationship.toLowerCase();
      const phone = item.phone.toLowerCase();
      
      return name.includes(keyword) || relationship.includes(keyword) || phone.includes(keyword);
    });
    
    this.setData({
      filteredRelatives: filtered
    });
  },

  /**
   * 显示新增亲属模态框
   */
  showAddRelativeModal() {
    this.setData({
      newRelative: getDefaultRelativeForm(),
      showAddModal: true,
      showEditModal: false,
      editingRelativeId: ''
    });
  },

  /**
   * 关闭新增亲属模态框
   */
  closeAddModal() {
    this.setData({
      showAddModal: false,
      newRelative: getDefaultRelativeForm()
    });
  },

  /**
   * 显示编辑亲属模态框
   */
  showEditRelativeModal(e) {
    const relativeId = e.currentTarget.dataset.id;
    const relative = this.data.relatives.find(r => r.id === relativeId);
    
    if (relative) {
      this.setData({
        newRelative: {
          ...getDefaultRelativeForm(),
          userId: relative.userId || '',
          userName: relative.userName || '',
          userOldPhone: relative.userOldPhone || '',
          relativeRelation: relative.relationship || '',
          isCommonOrder: !!relative.isFavoriteDiner,
          bloodSugar: relative.healthInfo?.bloodSugar || '',
          bloodPressure: relative.healthInfo?.bloodPressure || '',
          allergen: Array.isArray(relative.healthInfo?.allergies) ? relative.healthInfo.allergies.join('、') : '',
          dietForbidden: Array.isArray(relative.healthInfo?.dietRestrictions) ? relative.healthInfo.dietRestrictions.join('、') : ''
        },
        editingRelativeId: relativeId,
        showEditModal: true,
        showAddModal: false
      });
    }
  },

  /**
   * 关闭编辑亲属模态框
   */
  closeEditModal() {
    this.setData({
      showEditModal: false,
      editingRelativeId: '',
      newRelative: getDefaultRelativeForm()
    });
  },

  /**
   * 显示地址编辑模态框
   */
  showAddressModal(e) {
    const relativeId = e.currentTarget.dataset.id;
    this.setData({
      editingRelativeId: relativeId,
      showAddressModal: true,
      'newRelative.newAddress': '',
      'newRelative.isDefaultAddress': false
    });
  },

  /**
   * 关闭地址编辑模态框
   */
  closeAddressModal() {
    this.setData({
      showAddressModal: false
    });
  },

  /**
   * 表单输入处理
   */
  onFormInput(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    
    this.setData({
      [`newRelative.${field}`]: value
    });
  },

  /**
   * 关系选择处理
   */
  onDefaultAddressChange(e) {
    this.setData({
      'newRelative.isDefaultAddress': e.detail.value
    });
  },

  /**
   * 常用点餐切换
   */
  onCommonOrderChange(e) {
    this.setData({
      'newRelative.isCommonOrder': e.detail.value
    });
  },

  /**
   * 添加地址
   */
  addAddress() {
    const { newAddress, isDefaultAddress } = this.data.newRelative;
    
    if (!newAddress.trim()) {
      wx.showToast({
        title: '地址不能为空',
        icon: 'none'
      });
      return;
    }

    const relatives = this.data.relatives;
    const relativeIndex = relatives.findIndex(r => r.id === this.data.editingRelativeId);
    
    if (relativeIndex !== -1) {
      const newAddr = {
        id: Date.now().toString(),
        address: newAddress,
        isDefault: isDefaultAddress
      };
      
      // 如果设置为默认地址，将其他地址设置为非默认
      if (isDefaultAddress) {
        relatives[relativeIndex].addresses.forEach(addr => {
          addr.isDefault = false;
        });
      }
      
      relatives[relativeIndex].addresses.push(newAddr);
      
      this.setData({
        relatives: relatives,
        'newRelative.addresses': relatives[relativeIndex].addresses,
        'newRelative.newAddress': '',
        showAddressModal: false
      });
      
      wx.showToast({
        title: '地址添加成功',
        icon: 'success'
      });
    }
  },

  /**
   * 设置默认地址
   */
  setDefaultAddress(e) {
    const { relativeId, addressId } = e.currentTarget.dataset;
    const relatives = this.data.relatives;
    const relativeIndex = relatives.findIndex(r => r.id === relativeId);
    
    if (relativeIndex !== -1) {
      relatives[relativeIndex].addresses.forEach(addr => {
        addr.isDefault = addr.id === addressId;
      });
      
      this.setData({
        relatives: relatives
      });
      
      wx.showToast({
        title: '默认地址设置成功',
        icon: 'success'
      });
    }
  },

  /**
   * 删除地址
   */
  deleteAddress(e) {
    const { relativeId, addressId } = e.currentTarget.dataset;
    const relatives = this.data.relatives;
    const relativeIndex = relatives.findIndex(r => r.id === relativeId);
    
    if (relativeIndex !== -1) {
      wx.showModal({
        title: '确认删除',
        content: '确定要删除这个地址吗？',
        success: (res) => {
          if (res.confirm) {
            relatives[relativeIndex].addresses = relatives[relativeIndex].addresses.filter(
              addr => addr.id !== addressId
            );
            
            this.setData({
              relatives: relatives
            });
            
            wx.showToast({
              title: '地址删除成功',
              icon: 'success'
            });
          }
        }
      });
    }
  },

  /**
   * 保存新增或编辑的亲属
   */
  async saveRelative() {
    const { newRelative, editingRelativeId } = this.data;
    const userInfo = userStores.getUserInfo();

    if (!userInfo || !userInfo.id) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    if (!newRelative.relativeRelation.trim()) {
      wx.showToast({ title: '请填写亲属关系', icon: 'none' });
      return;
    }

    const payload = {
      user_id: newRelative.userId ? parseInt(newRelative.userId, 10) : null,
      user_name: newRelative.userName || null,
      user_old_phone: newRelative.userOldPhone || null,
      child_id: userInfo.id,
      relative_relation: newRelative.relativeRelation.trim(),
      is_common_order: newRelative.isCommonOrder ? 1 : 0,
      blood_sugar: newRelative.bloodSugar || '',
      blood_pressure: newRelative.bloodPressure || '',
      allergen: splitToList(newRelative.allergen),
      diet_forbidden: splitToList(newRelative.dietForbidden)
    };

    try {
      wx.showLoading({ title: editingRelativeId ? '更新中...' : '保存中...' });
      if (editingRelativeId) {
        await elderlyInfoAPI.updateElderlyInfo(editingRelativeId, payload);
      } else {
        await elderlyInfoAPI.createElderlyInfo(payload);
      }

      wx.showToast({ title: editingRelativeId ? '更新成功' : '添加成功', icon: 'success' });
      this.setData({
        showAddModal: false,
        showEditModal: false,
        editingRelativeId: '',
        newRelative: getDefaultRelativeForm()
      });
      await this.refreshFamilyData();
    } catch (error) {
      console.error('保存亲属信息失败:', error);
      const message = error?.message || '保存失败';
      wx.showToast({ title: message, icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  /**
   * 删除亲属
   */
  async deleteRelative(e) {
    const relativeId = e.currentTarget.dataset.id;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个亲属吗？删除后相关数据将无法恢复。',
      success: async (res) => {
        if (res.confirm) {
          try {
            wx.showLoading({ title: '删除中...' });
            
            // 调用后端API删除亲属信息
            await elderlyInfoAPI.deleteElderlyInfo(relativeId);
            
            // 更新前端数据
            const relatives = this.data.relatives.filter(r => r.id !== relativeId);
            const favoriteCount = relatives.filter(r => r.isFavoriteDiner).length;
            
            this.setData({
              relatives: relatives,
              filteredRelatives: relatives,
              'stats.totalRelatives': relatives.length,
              'stats.favoriteDiners': favoriteCount
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            wx.hideLoading();
            console.error('删除亲属失败:', error);
            wx.showToast({
              title: error?.message || '删除失败',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  /**
   * 确认取消常用点餐
   */
  confirmCancelFavorite(e) {
    const relativeId = e.currentTarget.dataset.id;
    const relative = this.data.relatives.find(r => r.id === relativeId);
    
    if (relative) {
      wx.showModal({
        title: '确认取消',
        content: `确定要取消${relative.name}的常用点餐人身份吗？`,
        success: (res) => {
          if (res.confirm) {
            this.toggleFavoriteDiner({ currentTarget: { dataset: { id: relativeId } } });
          }
        }
      });
    }
  },

  /**
   * 切换常用点餐对象
   */
  async toggleFavoriteDiner(e) {
    const relativeId = e.currentTarget.dataset.id;
    const relatives = this.data.relatives;
    const relativeIndex = relatives.findIndex(r => r.id === relativeId);
    
    if (relativeIndex !== -1) {
      const newState = !relatives[relativeIndex].isFavoriteDiner;
      
      try {
        wx.showLoading({ title: newState ? '设置中...' : '取消中...' });
        
        // 调用后端API更新常用点餐状态
        await elderlyInfoAPI.updateElderlyInfo(relativeId, {
          is_common_order: newState ? 1 : 0
        });
        
        // 更新前端数据
        relatives[relativeIndex].isFavoriteDiner = newState;
        relatives[relativeIndex].isCommonOrder = newState;
        const favoriteCount = relatives.filter(r => r.isFavoriteDiner).length;
        
        this.setData({
          relatives: relatives,
          filteredRelatives: relatives,
          'stats.favoriteDiners': favoriteCount
        });
        
        wx.hideLoading();
        wx.showToast({
          title: newState ? '已设置为常用点餐对象' : '已取消常用点餐对象',
          icon: 'success'
        });
      } catch (error) {
        wx.hideLoading();
        console.error('更新常用点餐状态失败:', error);
        wx.showToast({
          title: error?.message || '操作失败',
          icon: 'none'
        });
      }
    }
  },

  /**
   * 快捷功能点击处理
   */
  onQuickActionClick(e) {
    const actionName = e.currentTarget.dataset.name;
    switch (actionName) {
      case '快速点餐':
        // 如果有常用点餐对象，直接为其点餐
        const favoriteDiner = this.data.relatives.find(r => r.isFavoriteDiner);
        if (favoriteDiner) {
          this.goToOrder({ currentTarget: { dataset: { id: favoriteDiner.id } } });
        } else {
          wx.showToast({
            title: '请先设置常用点餐对象',
            icon: 'none'
          });
        }
        break;
      case '健康记录':
        wx.showToast({
          title: '健康记录功能开发中',
          icon: 'none'
        });
        break;

      case '订单历史':
        // 如果有常用点餐对象，直接查看其订单历史
        const favoriteOrderDiner = this.data.relatives.find(r => r.isFavoriteDiner);
        if (favoriteOrderDiner) {
          this.viewRelativeOrders({ currentTarget: { dataset: { id: favoriteOrderDiner.id } } });
        } else {
          wx.showToast({
            title: '请先设置常用点餐对象',
            icon: 'none'
          });
        }
        break;
      case '饮食推荐':
        this.showDietRecommendations();
        break;
      case '紧急联系':
        this.showEmergencyContact();
        break;
      default:
        wx.showToast({
          title: `点击了${actionName}`,
          icon: 'none'
        });
    }
  },

  /**
   * 显示饮食推荐
   */
  showDietRecommendations() {
    wx.showModal({
      title: '老年人饮食推荐',
      content: '1. 低盐低脂饮食\n2. 多吃蔬菜水果\n3. 适量摄入优质蛋白质\n4. 饮食规律，定时定量\n5. 避免生冷刺激性食物',
      showCancel: false
    });
  },

  /**
   * 显示紧急联系人
   */
  showEmergencyContact() {
    wx.showModal({
      title: '紧急联系',
      content: '紧急情况请拨打：\n1. 120 急救中心\n2. 110 报警电话\n3. 社区服务热线：020-12345678',
      showCancel: false
    });
  },

  /**
   * 显示健康信息编辑模态框
   */
  showHealthModal(e) {
    const relativeId = e.currentTarget.dataset.id;
    const relative = this.data.relatives.find(r => r.id === relativeId);
    
    if (relative) {
      // 确保healthInfo存在
      const healthInfo = relative.healthInfo || {
        bloodSugar: '',
        bloodPressure: '',
        allergies: [],
        dietRestrictions: [],
        date: ''
      };
      
      this.setData({
        editingRelativeId: relativeId,
        'newHealthData.bloodSugar': healthInfo.bloodSugar || '',
        'newHealthData.bloodPressure': healthInfo.bloodPressure || '',
        'newHealthData.allergies': Array.isArray(healthInfo.allergies) ? healthInfo.allergies.join('、') : '',
        'newHealthData.dietRestrictions': Array.isArray(healthInfo.dietRestrictions) ? healthInfo.dietRestrictions.join('、') : '',
        'newHealthData.date': healthInfo.date || new Date().toISOString().split('T')[0],
        showHealthModal: true
      });
    }
  },

  /**
   * 关闭健康信息编辑模态框
   */
  closeHealthModal() {
    this.setData({ showHealthModal: false });
  },

  /**
   * 保存健康信息
   */
  async saveHealthInfo() {
    const { editingRelativeId, newHealthData } = this.data;

    if (!editingRelativeId) {
      wx.showToast({ title: '未选择要更新的亲属', icon: 'none' });
      return;
    }

    const allergiesStr = newHealthData.allergies || '';
    const dietRestrictionsStr = newHealthData.dietRestrictions || '';
    const allergies = splitToList(allergiesStr);
    const dietRestrictions = splitToList(dietRestrictionsStr);

    const payload = {
      blood_sugar: newHealthData.bloodSugar || '',
      blood_pressure: newHealthData.bloodPressure || '',
      allergen: allergies,
      diet_forbidden: dietRestrictions
    };

    try {
      wx.showLoading({ title: '保存中...' });
      await elderlyInfoAPI.updateElderlyInfo(editingRelativeId, payload);

      wx.showToast({ title: '健康信息已更新', icon: 'success' });
      this.setData({ showHealthModal: false });
      await this.fetchRelativesFromServer();
    } catch (error) {
      console.error('更新健康信息失败:', error);
      const message = error?.message || '保存失败';
      wx.showToast({ title: message, icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  /**
   * 查看亲属订单历史
   */
  viewRelativeOrders(e) {
    const relativeId = e.currentTarget.dataset.id;
    const userInfo = userStores.getUserInfo();
    const relatives = this.data.relatives;
    const relative = relatives.find(r => r.id === relativeId);
    
    // 简化跳转逻辑，确保能正常跳转
    wx.navigateTo({
      url: `/pages/order_list/order_list?userId=${relative?.userId || ''}&roleId=${userInfo?.role || 'family'}`
    });
  },

  /**
   * 健康数据输入处理
   */
  onHealthDataInput(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    this.setData({
      [`newHealthData.${field}`]: value
    });
  },
  


  /**
   * 前往点餐
   */
  goToOrder(e) {
    const relativeId = e.currentTarget.dataset.id;
    if (!relativeId) {
      wx.showToast({
        title: '亲属信息错误',
        icon: 'none'
      });
      return;
    }
    
    console.log('前往点餐，亲属ID:', relativeId);
    
    // 存储relativeId到本地存储
    wx.setStorageSync('selectedRelativeId', relativeId);
    
    // 跳转到商家列表页面，让用户选择商家
    wx.navigateTo({
      url: '/pages/family/merchant-list',
      success: () => {
        console.log('跳转到商家列表页面成功');
      },
      fail: (err) => {
        console.error('跳转到商家列表页面失败:', err);
        wx.showToast({
          title: '跳转失败，请重试',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.refreshFamilyData();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.refreshFamilyData();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  /**
   * 获取后端绑定亲属数量
   */
  async fetchBoundRelativesStats(showLoading = true) {
    const userInfo = userStores.getUserInfo();

    if (!userInfo || !userInfo.id) {
      console.warn('未找到有效的用户信息，无法统计绑定亲属数量');
      return;
    }

    try {
      if (showLoading) {
        wx.showNavigationBarLoading();
      }
      const response = await elderlyInfoAPI.getChildStats(userInfo.id);

      if (response && response.success && response.data) {
        this.setData({
          'stats.totalRelatives': response.data.total || 0
        });
      } else {
        const message = response?.message || '获取绑定亲属数量失败';
        wx.showToast({ title: message, icon: 'none' });
      }
    } catch (error) {
      console.error('获取绑定亲属数量失败:', error);
      wx.showToast({ title: '获取绑定亲属数量失败', icon: 'none' });
    } finally {
      if (showLoading) {
        wx.hideNavigationBarLoading();
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 从后端获取亲属健康信息列表
   */
  async fetchRelativesFromServer() {
    const userInfo = userStores.getUserInfo();

    if (!userInfo || !userInfo.id) {
      console.warn('未找到有效的用户信息，无法获取亲属列表');
      return;
    }

    try {
      const response = await elderlyInfoAPI.getElderlyInfos({ page: 1, pageSize: 20 });
      if (response && response.success && response.data) {
        const items = response.data.items || [];

        const relatives = items.map(record => {
          // 优先使用elder_info表中的user_name，其次是user表中的user_nickname，最后是默认值
          const displayName = record.user_name || record.user_nickname || record.relative_relation || `亲属${record.id}`;
          const allergies = Array.isArray(record.allergen) ? record.allergen : splitToList(record.allergen);
          const dietRestrictions = Array.isArray(record.diet_forbidden) ? record.diet_forbidden : splitToList(record.diet_forbidden);
          // 优先使用elder_info表中的user_old_phone，其次是user表中的user_phone，最后是默认值
          const primaryPhone = record.user_old_phone || record.user_phone || record.contact_phone || '--';

          return {
            id: record.id,
            userId: record.user_id || '',
            userName: record.user_name || '',
            userOldPhone: record.user_old_phone || '',
            name: displayName,
            phone: primaryPhone,
            idCard: record.id_card || '',
            relationship: record.relative_relation || '',
            relativeRelation: record.relative_relation || '',
            isFavoriteDiner: record.is_common_order === 1,
            isCommonOrder: record.is_common_order === 1,
            healthInfo: {
              bloodSugar: record.blood_sugar || '',
              bloodPressure: record.blood_pressure || '',
              allergies,
              dietRestrictions,
              date: record.updated_at ? formatDate(record.updated_at) : ''
            },
            user_phone: primaryPhone,
            medications: record.medications || [],
            recentOrders: record.recentOrders || [],
            addresses: record.addresses || []
          };
        });

        const favoriteCount = relatives.filter(item => item.isFavoriteDiner).length;
        const healthCheckCount = relatives.filter(item => item.healthInfo.bloodSugar || item.healthInfo.bloodPressure).length;

        this.setData({
          relatives,
          filteredRelatives: relatives,
          'stats.favoriteDiners': favoriteCount,
          'stats.healthChecks': healthCheckCount
        });
      } else {
        const message = response?.message || '获取亲属列表失败';
        wx.showToast({ title: message, icon: 'none' });
      }
    } catch (error) {
      console.error('获取亲属列表失败:', error);
      wx.showToast({ title: '获取亲属列表失败', icon: 'none' });
    }
  },

  /**
   * 获取订单总数
   */
  async fetchOrderStats() {
    try {
      const response = await orderAPI.getOrderStats();
      if (response && response.success && response.data) {
        this.setData({
          'stats.recentOrders': response.data.total || 0
        });
      }
    } catch (error) {
      console.error('获取订单总数失败:', error);
    }
  },

  /**
   * 统一刷新家庭端数据
   */
  async refreshFamilyData() {
    try {
      wx.showNavigationBarLoading();
      await Promise.allSettled([
        this.fetchBoundRelativesStats(false),
        this.fetchRelativesFromServer(),
        this.fetchOrderStats()
      ]);
    } finally {
      wx.hideNavigationBarLoading();
      wx.stopPullDownRefresh();
    }
  }
})