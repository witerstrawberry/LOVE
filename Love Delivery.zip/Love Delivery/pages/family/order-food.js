// 点餐页面 - 老人端
const { productAPI, merchantAPI, favoriteAPI, cartAPI, addressAPI, orderAPI, elderlyInfoAPI } = require('../../utils/api');
const { getFullImageUrl } = require('../../utils/imageUtils');

// 完整的商家模拟数据，用于API调用失败时的降级方案
const completeMockMerchant = {
  name: '排骨焖花卷砂锅（第七档口店）',
  image: '/images/restaurant.png',
  logo: '/images/restaurant.png',
  rating: 4.3,
  monthlySales: '2000+',
  deliveryTime: '上午10:00-14:00下午16:00-21:00可以送到财经大学宿舍楼下.其余时间送门口，雨天会延迟一些',
  address: '学校第七档口',
  phone: '13800138000',
  businessHours: '10:00-21:00',
  hasAddress: true
};



Page({
  data: {
    // 从family_index页面传递的亲属ID
    relativeId: '',
    // 餐厅信息
    restaurant: {
      name: '排骨焖花卷砂锅（第七档口店）',
      image: '/images/restaurant.png',
      rating: 4.3,
      monthlySales: '2000+',
      deliveryTime: '上午10:00-14:00下午16:00-21:00可以送到财经大学宿舍楼下.其余时间送门口，雨天会延迟一些',
    },
    // 当前激活的标签页
    activeTab: 'menu',
    // 菜单分类
    menuCategories: [], // 从后端获取分类列表
    // 选中的分类
    selectedCategory: 'recommend',
    // 所有餐品数据
    allFoodList: [], // 从后端获取所有商品数据
    // 加载状态
    loading: false,
    // 错误信息
    errorMessage: '',
    // 是否还有更多数据
    hasMore: true,
    // 当前页码
    currentPage: 1,
    // 每页数量
    pageSize: 20,
    // 当前显示的餐品列表
    currentFoodList: [],
    // 购物车数据
    cartItems: [],
    // 购物车商品总数
    cartCount: 0,
    // 购物车总价
    totalPrice: 0,
    // 显示购物车
    showCart: false,

    // 收藏状态
    isFavorite: false,
    // 商家ID
    merchantId: '',
    // 收藏图标URL
    favoriteIconUrl: '',

    // 地址相关数据
    addresses: [], // 地址列表
    selectedAddress: null, // 当前选中的地址
    defaultAddress: null, // 默认地址
    addressLoading: false, // 地址加载状态
    hasAddress: false, // 是否有地址

    // 配送方式
    deliveryMethod: '外送', // '外送' 或 '自取'

    // 配送时间
    deliveryTime: {
      type: '立即配送',
      estimatedTime: '',
      selectedDate: '',
      selectedSlot: ''
    },

    // 自取时间
    pickupTime: {
      type: '',
      estimatedTime: '请选择',
      selectedDate: '',
      selectedSlot: ''
    },

    // 取餐号
    pickupNumber: '',

    // 备注
    noteContent: '',

    // 餐具选择
    selectedTableware: 0, // 0-按餐量提供，1-一份，2-两份，3-三份

    // 配送费
    deliveryFee: 0
  },

  // 阻止事件冒泡
  stopPropagation: function (e) {
    // 在微信小程序中，使用e.stopPropagation()或e.stopImmediatePropagation()
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    } else if (e && typeof e.stopImmediatePropagation === 'function') {
      e.stopImmediatePropagation();
    }
  },

  onLoad(options) {
    // 从URL参数获取merchantId（从商家列表页面跳转时传递）
    let merchantId = '';
    if (options.merchantId) {
      merchantId = options.merchantId;
      this.setData({
        merchantId: merchantId
      });
      // 保存到本地存储，供loadMerchantInfo使用
      wx.setStorageSync('activeMerchantId', merchantId);
      console.log('从商家列表页面获取的商家ID:', merchantId);
    } else {
      // 如果没有从URL获取，尝试从本地存储获取
      merchantId = wx.getStorageSync('activeMerchantId') || '';
      if (merchantId) {
        this.setData({
          merchantId: merchantId
        });
        console.log('从本地存储获取的商家ID:', merchantId);
      }
    }

    // 从本地存储获取relativeId
    const relativeId = wx.getStorageSync('selectedRelativeId');
    if (relativeId) {
      this.setData({
        relativeId: relativeId
      });
      // 根据relativeId加载老人的地址信息
      console.log('从子女首页选择的亲属ID:', relativeId);
      // 先加载老人信息，然后加载地址
      this.loadElderlyAddress(relativeId);
    }

    // 初始化收藏图标（默认未收藏状态）
    this.updateFavoriteIcon();

    // 从后端加载商家信息
    this.loadMerchantInfo();

    // 从后端加载分类列表和商品数据
    // 注意：loadProducts 方法内部会使用 this.data.merchantId 或从存储中获取
    this.loadCategories();
    this.loadProducts();

    // 从后端获取购物车数据
    this.getCartItems();

    // 如果没有relativeId，才加载当前用户的地址列表
    if (!relativeId) {
      this.loadAddresses();
    }
  },

  // 页面显示时触发，用于处理从地址选择页面返回后的逻辑
  onShow() {
    console.log('order-food页面显示');
    // 检查是否有从地址选择页面返回的选中地址
    const selectedAddress = wx.getStorageSync('selectedAddressForOrder');
    if (selectedAddress) {
      console.log('从地址选择页面获取到选中地址:', selectedAddress);
      // 更新选中地址
      this.setData({
        selectedAddress: selectedAddress
      });
      // 清除本地存储的选中地址，避免重复使用
      wx.removeStorageSync('selectedAddressForOrder');
    }
  },

  // 根据relativeId加载老人的地址信息
  async loadElderlyAddress(relativeId) {
    console.log('开始根据relativeId加载老人地址信息，relativeId:', relativeId);
    this.setData({ addressLoading: true });

    try {
      // 1. 根据relativeId获取老人信息
      const elderlyInfoRes = await elderlyInfoAPI.getElderlyInfos({ page: 1, pageSize: 100 });
      console.log('获取老人信息列表响应:', elderlyInfoRes);

      if (!elderlyInfoRes || !elderlyInfoRes.success || !elderlyInfoRes.data) {
        throw new Error('获取老人信息失败');
      }

      const elderlyInfoList = elderlyInfoRes.data.items || elderlyInfoRes.data || [];
      const elderlyInfo = elderlyInfoList.find(item => item.id == relativeId);

      if (!elderlyInfo) {
        console.warn('未找到对应的老人信息，relativeId:', relativeId);
        this.setData({ addressLoading: false });
        return;
      }

      console.log('找到老人信息:', elderlyInfo);

      // 2. 获取老人的user_id
      const elderlyUserId = elderlyInfo.user_id;
      if (!elderlyUserId) {
        console.warn('老人信息中没有user_id，无法获取地址');
        this.setData({ addressLoading: false });
        return;
      }

      console.log('老人user_id:', elderlyUserId);

      // 3. 根据user_id获取老人的地址列表
      const addressRes = await addressAPI.getAddressList({ userId: elderlyUserId });
      console.log('获取老人地址列表响应:', addressRes);

      // 处理不同的响应数据格式
      let addresses = [];
      if (addressRes.data && Array.isArray(addressRes.data)) {
        addresses = addressRes.data;
      } else if (addressRes.data && addressRes.data.list && Array.isArray(addressRes.data.list)) {
        addresses = addressRes.data.list;
      } else if (addressRes.data && addressRes.data.addresses && Array.isArray(addressRes.data.addresses)) {
        addresses = addressRes.data.addresses;
      } else if (Array.isArray(addressRes)) {
        addresses = addressRes;
      }

      // 过滤掉无效地址
      const validAddresses = addresses.filter(addr => addr && addr.id);

      // 查找默认地址
      const defaultAddress = validAddresses.find(addr => addr.is_default === 1 || addr.is_default === true) || null;

      // 设置选中地址（优先使用默认地址）
      const selectedAddress = defaultAddress || (validAddresses.length > 0 ? validAddresses[0] : null);

      this.setData({
        addresses: validAddresses,
        defaultAddress: defaultAddress,
        selectedAddress: selectedAddress,
        hasAddress: validAddresses.length > 0,
        addressLoading: false
      });

      console.log('老人地址加载成功:', {
        total: validAddresses.length,
        hasDefault: !!defaultAddress,
        selectedAddressId: selectedAddress ? selectedAddress.id : null
      });

      if (selectedAddress) {
        wx.showToast({
          title: '已自动填充收货地址',
          icon: 'success',
          duration: 2000
        });
      }
    } catch (error) {
      console.error('加载老人地址失败:', error);
      this.setData({
        addresses: [],
        defaultAddress: null,
        selectedAddress: null,
        hasAddress: false,
        addressLoading: false
      });
      wx.showToast({
        title: '加载地址失败，请手动选择',
        icon: 'none',
        duration: 2000
      });
    }
  },

  // 从后端获取地址列表
  loadAddresses() {
    console.log('开始获取地址列表...');
    this.setData({ addressLoading: true });

    // 获取用户ID
    const userInfo = wx.getStorageSync('userInfo') || {};
    const userId = userInfo.id || '';

    // 构建请求参数
    const params = userId ? { userId } : {};

    // 发送请求
    addressAPI.getAddressList(params)
      .then(res => {
        console.log('地址列表API响应:', res);

        try {
          // 处理不同的响应数据格式
          let addresses = [];

          // 尝试多种可能的数据路径
          if (res.data && Array.isArray(res.data)) {
            addresses = res.data;
            console.log('地址数据在res.data中:', addresses);
          } else if (res.data && res.data.list && Array.isArray(res.data.list)) {
            addresses = res.data.list;
            console.log('地址数据在res.data.list中:', addresses);
          } else if (res.data && res.data.addresses && Array.isArray(res.data.addresses)) {
            addresses = res.data.addresses;
            console.log('地址数据在res.data.addresses中:', addresses);
          } else if (Array.isArray(res)) {
            addresses = res;
            console.log('地址数据直接是数组:', addresses);
          } else {
            console.error('无法识别的地址数据格式:', res);
          }

          // 过滤掉无效地址
          const validAddresses = addresses.filter(addr => addr && addr.id);

          // 查找默认地址
          const defaultAddress = validAddresses.find(addr => addr.is_default === 1 || addr.is_default === true) || null;

          // 设置选中地址（优先使用默认地址）
          const selectedAddress = defaultAddress || (validAddresses.length > 0 ? validAddresses[0] : null);

          this.setData({
            addresses: validAddresses,
            defaultAddress: defaultAddress,
            selectedAddress: selectedAddress,
            hasAddress: validAddresses.length > 0,
            addressLoading: false
          });

          console.log('地址列表加载成功:', {
            total: validAddresses.length,
            hasDefault: !!defaultAddress,
            selectedAddressId: selectedAddress ? selectedAddress.id : null
          });
        } catch (error) {
          console.error('处理地址数据时出错:', error);
          this.setData({
            addresses: [],
            defaultAddress: null,
            selectedAddress: null,
            hasAddress: false,
            addressLoading: false
          });
        }
      })
      .catch(error => {
        console.error('获取地址列表失败:', error);
        this.setData({
          addresses: [],
          defaultAddress: null,
          selectedAddress: null,
          hasAddress: false,
          addressLoading: false
        });
      });
  },

  // 从后端加载商家信息
  loadMerchantInfo() {
    console.log('开始获取商家信息...');
    const merchantId = wx.getStorageSync('activeMerchantId');
    const params = merchantId ? { merchantId } : {};

    // 从后端获取商家信息（公开接口）
    merchantAPI.getPublicMerchantInfo(params)
      .then(res => {
        console.log('商家信息API响应完整数据:', res);

        try {
          // 检查响应的基本结构
          console.log('响应success字段:', res.success);
          console.log('响应data字段类型:', typeof res.data);
          console.log('响应data字段内容:', JSON.stringify(res.data));

          // 处理不同的响应数据格式
          let merchantData = null;

          // 更健壮的响应数据提取逻辑
          if (res && typeof res === 'object') {
            if (res.success && res.data) {
              console.log('使用res.success && res.data路径');
              merchantData = res.data;
            } else if (res.data && res.data.merchant) {
              console.log('使用res.data.merchant路径');
              merchantData = res.data.merchant;
            } else if (res.data) {
              console.log('使用res.data路径');
              merchantData = res.data;
            } else if (res.merchant) {
              console.log('使用res.merchant路径');
              merchantData = res.merchant;
            }
          }

          if (merchantData && typeof merchantData === 'object') {
            console.log('获取到商家数据:', JSON.stringify(merchantData));
            console.log('商家数据包含的字段:', Object.keys(merchantData));

            // 标准化商家数据格式，优先使用后端数据，缺失时使用模拟数据
            const standardizedMerchant = {
              name: merchantData.name || merchantData.merchant_name || completeMockMerchant.name,
              image: merchantData.logo ? getFullImageUrl(merchantData.logo) : completeMockMerchant.image,
              logo: merchantData.logo ? getFullImageUrl(merchantData.logo) : completeMockMerchant.image, // 同时设置logo属性
              rating: merchantData.rating || merchantData.score || completeMockMerchant.rating,
              monthlySales: merchantData.monthly_sales || merchantData.sales || completeMockMerchant.monthlySales,
              deliveryTime: merchantData.delivery_time || merchantData.business_hours || completeMockMerchant.deliveryTime,
              address: merchantData.address || merchantData.business_address || completeMockMerchant.address,
              phone: merchantData.phone || merchantData.contact_phone || completeMockMerchant.phone,
              businessHours: merchantData.business_hours || completeMockMerchant.businessHours,
              hasAddress: !!(merchantData.address || merchantData.business_address || completeMockMerchant.address)
            };

            console.log('标准化后的商家数据:', JSON.stringify(standardizedMerchant));
            console.log('hasAddress标志:', standardizedMerchant.hasAddress);

            // 提取商家ID（优先使用merchantData中的id或merchant_id，其次使用存储的merchantId）
            const extractedMerchantId = merchantData.id || merchantData.merchant_id || merchantId || '';

            console.log('提取的商家ID:', extractedMerchantId, '来源:', {
              'merchantData.id': merchantData.id,
              'merchantData.merchant_id': merchantData.merchant_id,
              'storedMerchantId': merchantId
            });

            this.setData({
              restaurant: standardizedMerchant,
              merchantId: extractedMerchantId
            });
            console.log('商家信息更新成功，当前this.data.restaurant:', JSON.stringify(this.data.restaurant));
            console.log('商家ID:', this.data.merchantId);

            // 如果有商家ID，检查收藏状态；否则只设置默认图标
            if (extractedMerchantId) {
              this.checkFavoriteStatus();
            } else {
              console.warn('未获取到商家ID，无法检查收藏状态');
              this.updateFavoriteIcon();
            }
          } else {
            console.log('未获取到有效的商家数据，使用完整模拟数据');

            this.setData({
              restaurant: completeMockMerchant
            });
            console.log('模拟数据设置成功:', JSON.stringify(completeMockMerchant));
          }
        } catch (error) {
          console.error('处理商家数据时出错:', error);
          console.error('错误堆栈:', error.stack);

          // 错误情况下使用完整的模拟数据，确保包含所有必要信息
          console.log('错误情况下使用完整模拟数据');
          this.setData({
            restaurant: completeMockMerchant
          });
          console.log('错误情况下模拟数据设置成功:', JSON.stringify(completeMockMerchant));
        }
      })
      .catch(error => {
        console.error('获取商家信息失败:', error);
        if (error && error.stack) {
          console.error('错误堆栈:', error.stack);
        }

        // API调用失败时使用完整的模拟数据
        console.log('API调用失败时使用完整模拟数据');
        this.setData({
          restaurant: completeMockMerchant
        });
        console.log('API调用失败时模拟数据设置成功:', JSON.stringify(completeMockMerchant));
      });
  },

  // 从后端加载商品数据
  loadProducts(categoryId, page = 1, append = false) {
    if (this.data.loading) return;

    this.setData({ loading: true, errorMessage: '' });

    // 获取当前商家ID
    const merchantId = this.data.merchantId || wx.getStorageSync('activeMerchantId');

    // 构建请求参数
    const params = {
      page,
      limit: this.data.pageSize // 使用limit而不是pageSize，匹配后端API
    };

    // 如果有商家ID，添加到请求参数中
    if (merchantId) {
      params.merchant_id = merchantId;
      console.log('加载商家产品，merchantId:', merchantId);
    }

    // 定义请求方法
    let apiCall;

    if (categoryId && categoryId !== 'recommend' && String(categoryId) !== '1') {
      // 根据分类获取商品，但跳过'recommend'和'1'(代表推荐)
      console.log(`根据分类${categoryId}获取商品，商家ID: ${merchantId || '无'}`);
      apiCall = productAPI.getProductsByCategory(categoryId, params);
    } else {
      // 获取所有商品或推荐商品
      console.log('获取所有商品，商家ID:', merchantId || '无');
      apiCall = productAPI.getProducts(params);
    }

    // 发送请求
    apiCall
      .then(res => {
        try {
          console.log('商品API响应完整数据:', res);

          // 处理不同的响应数据格式
          let products = [];
          // 打印更详细的响应数据结构
          console.log('res.data类型:', typeof res.data);
          console.log('res.data结构:', JSON.stringify(res.data));

          if (res.success && res.data) {
            // 处理格式: {success: true, code: 200, data: {...}, message: "", timestamp: ""}
            if (res.data.list) {
              products = res.data.list;
              console.log('从res.data.list获取商品数据');
            } else if (res.data.items) {
              products = res.data.items;
              console.log('从res.data.items获取商品数据');
            } else if (res.data.products) {
              products = res.data.products;
              console.log('从res.data.products获取商品数据');
            } else if (Array.isArray(res.data)) {
              products = res.data;
              console.log('res.data是数组，直接使用');
            } else if (typeof res.data === 'object') {
              // 尝试将整个data对象作为一个商品处理
              console.log('res.data是对象但不包含list/items/products，尝试将其作为单个商品');
              products = [res.data];
            } else {
              console.error('data字段格式不正确');
              // 使用模拟数据作为降级方案
              this.useMockData();
              return;
            }
          } else if (res.data && res.data.list) {
            // 处理格式: {data: {list: [...]}}
            products = res.data.list;
          } else if (res.data && res.data.items) {
            // 处理格式: {data: {items: [...]}}
            products = res.data.items;
          } else if (res.data && Array.isArray(res.data)) {
            // 处理格式: {data: [...]}
            products = res.data;
          } else if (Array.isArray(res)) {
            // 处理格式: [...] 直接返回数组
            products = res;
          } else {
            console.error('无法识别的响应格式');
            // 使用模拟数据作为降级方案
            this.useMockData();
            return;
          }

          console.log(`获取到${products.length}个商品`);

          // 标准化商品数据格式，确保包含页面所需的字段
          const standardizedProducts = products.map(product => {
            // 根据category_name映射到对应的categoryId
            let categoryId = 1; // 默认推荐
            const categoryMap = {
              '推荐': 1,
              '软食': 2,
              '控糖': 3,
              '低盐': 4,
              '低脂': 5,
              '营养套餐': 6,
              '传统家常': 7,
              '主食': 8,
              '凉菜': 9,
              '汤类': 10,
              '小份菜': 11
            };

            if (product.category_name && categoryMap[product.category_name]) {
              categoryId = categoryMap[product.category_name];
            }

            // 获取原始图片路径
            const originalImagePath = product.image || product.image_url;
            // 使用工具函数处理图片URL，确保返回正确的完整路径
            const processedImageUrl = originalImagePath ? getFullImageUrl(originalImagePath) : '../../images/default-avatar.png';

            return {
              id: product.id,
              category: categoryId,
              categoryId: categoryId,
              category_name: product.category_name || '推荐',
              name: product.name || '未命名商品',
              price: parseFloat(product.price || 0),
              originalPrice: product.original_price ? parseFloat(product.original_price) : null,
              image: processedImageUrl,
              image_url: processedImageUrl,
              tags: product.tags || product.tag || [],
              description: product.description || product.desc || '暂无描述',
              sales: product.sales || product.sales_count || product.view_count || 0,
              view_count: product.sales || product.sales_count || product.view_count || 0
            };
          });

          // 更新商品列表
          let updatedFoodList;
          if (append) {
            updatedFoodList = [...this.data.allFoodList, ...standardizedProducts];
          } else {
            updatedFoodList = standardizedProducts;
          }

          // 检查是否还有更多数据
          const hasMore = standardizedProducts.length >= this.data.pageSize;

          // 更新数据状态
          this.setData({
            allFoodList: updatedFoodList,
            loading: false,
            hasMore: hasMore
          });

          // 更新当前显示的餐品列表
          this.setCurrentFoodList(categoryId);
        } catch (error) {
          console.error('处理商品数据时出错:', error);
          this.setData({
            loading: false,
            errorMessage: '处理商品数据失败'
          });

          // 发生异常时使用模拟数据
          this.useMockData();
        }
      })
      .catch(error => {
        console.error('获取商品数据失败:', error);
        this.setData({
          loading: false,
          errorMessage: '获取商品数据失败，请重试'
        });

        // 无论是否是加载更多，都使用模拟数据作为降级方案
        this.useMockData();
      });
  },

  // 重新加载数据
  retry() {
    console.log('重新加载数据');
    this.setData({
      errorMessage: '',
      hasMore: true,
      currentPage: 1
    });
    this.loadCategories();
    this.loadProducts(null, 1, false);
  },

  // 加载更多商品
  loadMore() {
    if (!this.data.hasMore || this.data.loading) return;

    const nextPage = this.data.currentPage + 1;
    this.setData({ currentPage: nextPage });

    // 从后端加载更多数据
    this.loadProducts(this.data.selectedCategory, nextPage, true);
  },

  // 从后端加载分类列表
  loadCategories() {
    console.log('开始获取分类数据...');
    productAPI.getCategories()
      .then(res => {
        try {
          console.log('分类API响应完整数据:', res);
          console.log('响应数据类型:', typeof res.data);
          // 打印响应数据的所有键
          console.log('响应数据对象结构:', Object.keys(res.data));
          // 尝试多种可能的数据路径
          if (res.data && res.data.categories && Array.isArray(res.data.categories)) {
            console.log('从res.data.categories获取到分类数据:', res.data.categories);
            // 转换分类数据格式，确保包含页面所需的字段
            const activeCategories = res.data.categories.map(cat => ({
              id: String(cat.id), // 确保ID是字符串
              name: cat.name,
              icon: '', // 图片路径已删除
              status: 'active' // 设置为active确保被显示
            }));
            console.log('转换后的分类数据:', activeCategories);

            // 确保至少有一个分类
            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              this.setData({
                menuCategories: activeCategories,
                selectedCategory: selectedCategoryId,
                currentCategoryName: selectedCategoryName
              });
              console.log('设置分类成功，当前选中:', this.data.selectedCategory);
              this.setCurrentFoodList(this.data.selectedCategory);
            } else {
              console.log('没有分类数据，使用默认分类');
              this.useDefaultCategories();
            }
          } else if (res.data && res.data.data && Array.isArray(res.data.data)) {
            console.log('从res.data.data获取到分类数据:', res.data.data);
            const activeCategories = res.data.data;
            console.log('过滤后的分类(兼容格式):', activeCategories);

            if (activeCategories.length > 0) {
              const selectedCategoryId = activeCategories[0]?.id || '1';
              const selectedCategoryName = activeCategories[0]?.name || '推荐';
              this.setData({
                menuCategories: activeCategories,
                selectedCategory: selectedCategoryId,
                currentCategoryName: selectedCategoryName
              });
              this.setCurrentFoodList(this.data.selectedCategory);
            } else {
              this.useDefaultCategories();
            }
          } else {
            console.log('无法识别的响应格式，尝试直接使用res.data作为数组:', res.data);
            // 尝试直接使用res.data作为数组
            if (Array.isArray(res.data)) {
              console.log('res.data本身是数组，直接使用');
              const activeCategories = res.data;
              console.log('过滤后的分类(直接数组格式):', activeCategories);

              if (activeCategories.length > 0) {
                const selectedCategoryId = activeCategories[0]?.id || '1';
                const selectedCategoryName = activeCategories[0]?.name || '推荐';
                this.setData({
                  menuCategories: activeCategories,
                  selectedCategory: selectedCategoryId,
                  currentCategoryName: selectedCategoryName
                });
                this.setCurrentFoodList(this.data.selectedCategory);
              } else {
                this.useDefaultCategories();
              }
            } else {
              console.log('响应数据格式不符合预期，但尝试直接从res.data.categories获取数据，然后使用默认分类');
              console.log('强制使用默认分类');
              this.useDefaultCategories();
            }
          }
        } catch (error) {
          console.error('处理分类数据时发生异常:', error);
          this.useDefaultCategories();
        }
      })
      .catch(err => {
        console.error('获取分类失败:', err);
        this.useDefaultCategories();
      });
  },
  // 使用默认分类数据
  useDefaultCategories() {
    console.log('使用默认分类数据');
    const defaultCategories = [
      { id: '1', name: '推荐', status: 'active' },
      { id: '2', name: '软食', status: 'active' },
      { id: '3', name: '控糖', status: 'active' },
      { id: '4', name: '低盐', status: 'active' },
      { id: '5', name: '低脂', status: 'active' },
      { id: '6', name: '营养套餐', status: 'active' },
      { id: '7', name: '传统家常', status: 'active' },
      { id: '8', name: '主食', status: 'active' },
      { id: '9', name: '凉菜', status: 'active' },
      { id: '10', name: '汤类', status: 'active' },
      { id: '11', name: '小份菜', status: 'active' }
    ];
    this.setData({
      menuCategories: defaultCategories,
      selectedCategory: '1',
      currentCategoryName: '推荐'
    });
    console.log('设置默认分类成功');
    this.setCurrentFoodList('1');
  },
  // 选择分类
  selectCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    console.log('选择分类:', categoryId);
    const categoryName = this.data.menuCategories.find(cat => cat.id === categoryId)?.name || '';

    this.setData({
      selectedCategory: categoryId,
      currentCategoryName: categoryName,
      hasMore: true,
      currentPage: 1
    });

    // 从后端加载该分类的商品数据
    this.loadProducts(categoryId, 1, false);
  },

  // 根据分类筛选餐品
  setCurrentFoodList(categoryId) {
    // 使用已从后端获取的商品列表进行筛选
    console.log('根据分类筛选商品:', categoryId);
    let currentFoodList = [];
    // 转换为字符串以便比较
    const categoryIdStr = String(categoryId);

    // 确保使用allFoodList，完全不依赖模拟数据
    if (this.data.allFoodList && this.data.allFoodList.length > 0) {
      // 处理推荐分类
      if (categoryIdStr === '1' || categoryIdStr === 'recommend') {
        // 推荐分类显示所有商品
        currentFoodList = [...this.data.allFoodList];
      } else {
        // 根据分类ID筛选商品
        currentFoodList = this.data.allFoodList.filter(item =>
          String(item.category) === categoryIdStr ||
          String(item.categoryId) === categoryIdStr
        );

        // 如果没有找到匹配项，尝试根据category_name筛选
        if (currentFoodList.length === 0) {
          console.log('未找到匹配ID的食品，尝试根据分类名称筛选');
          // 反向映射：根据数字ID找到对应的分类名称
          const idToCategoryMap = {
            '2': '软食',
            '3': '控糖',
            '4': '低盐',
            '5': '低脂',
            '6': '营养套餐',
            '7': '传统家常',
            '8': '主食',
            '9': '凉菜',
            '10': '汤类',
            '11': '小份菜'
          };
          const categoryName = idToCategoryMap[categoryIdStr];

          if (categoryName) {
            currentFoodList = this.data.allFoodList.filter(item =>
              item.category_name === categoryName
            );
          }

          // 如果仍然没有找到匹配项，返回所有食品
          if (currentFoodList.length === 0) {
            console.log('未找到匹配的食品，返回所有食品');
            currentFoodList = [...this.data.allFoodList];
          }
        }
      }
    }

    // 为每个餐品添加quantity属性（初始为0）
    currentFoodList = currentFoodList.map(item => {
      const cartItem = this.data.cartItems.find(cart => cart.id === item.id);
      return {
        ...item,
        quantity: cartItem ? cartItem.quantity : 0
      };
    });

    console.log('设置的食品列表数量:', currentFoodList.length);
    this.setData({
      currentFoodList: currentFoodList
    });
  },

  // 获取模拟食品数据
  getMockFoodList(categoryId) {
    console.log('获取模拟食品数据，分类ID:', categoryId);
    const mockFoods = [
      { id: 1, name: '红烧肉', price: 28, description: '经典红烧肉，肥而不腻', image: '/images/food1.jpg', sales: 120, tags: ['招牌', '热销'], category: 1, quantity: 0 },
      { id: 2, name: '宫保鸡丁', price: 22, description: '麻辣鲜香，回味无穷', image: '/images/food2.jpg', sales: 98, tags: ['辣'], category: 2, quantity: 0 },
      { id: 3, name: '鱼香肉丝', price: 20, description: '酸甜可口，下饭神器', image: '/images/food3.jpg', sales: 88, tags: ['酸甜'], category: 3, quantity: 0 },
      { id: 4, name: '西红柿鸡蛋', price: 18, description: '家常口味，营养健康', image: '/images/food4.jpg', sales: 76, tags: ['清淡'], category: 2, quantity: 0 },
      { id: 5, name: '麻婆豆腐', price: 16, description: '麻辣鲜香，豆腐嫩滑', image: '/images/food5.jpg', sales: 68, tags: ['辣', '招牌'], category: 3, quantity: 0 }
    ];
    return mockFoods;
  },

  // 返回上一页
  navigateBack() {
    wx.navigateBack();
  },

  // 切换标签页
  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });

    // 根据不同标签页可以添加不同的逻辑
    if (tab === 'menu') {
      // 确保菜品列表正确显示
      this.setCurrentFoodList(this.data.selectedCategory);
    }
  },

  // 添加商品到购物车
  async addToCart(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('添加商品到购物车:', foodId);

    // 从当前餐品列表中查找商品
    const food = this.data.currentFoodList.find(item => item.id === foodId);
    if (!food) return;

    // 检查是否有足够库存
    const cartItem = this.data.cartItems.find(item => item.id === foodId);
    if (food.stock !== undefined && (cartItem ? cartItem.quantity >= food.stock : false)) {
      wx.showToast({ title: '已达库存上限', icon: 'none' });
      return;
    }

    // 更新购物车
    const newCartItems = [...this.data.cartItems];
    const existingItem = newCartItems.find(item => item.id === foodId);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      newCartItems.push({ ...food, quantity: 1 });
    }

    // 更新购物车并重新计算总数和总价（会自动同步到后端）
    this.updateCart(newCartItems);

    // 更新当前显示列表中的数量
    const updatedQuantity = newCartItems.find(item => item.id === foodId).quantity;
    this.updateCurrentFoodQuantity(foodId, updatedQuantity);

    // 显示添加成功提示
    wx.showToast({ title: '已添加', icon: 'success', duration: 1000 });
  },

  // 增加商品数量
  async increaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('增加商品数量:', foodId);

    // 从当前餐品列表中查找商品
    const food = this.data.currentFoodList.find(item => item.id === foodId);
    if (!food) return;

    // 检查是否有足够库存
    const cartItem = this.data.cartItems.find(item => item.id === foodId);
    if (food.stock !== undefined && (cartItem ? cartItem.quantity >= food.stock : false)) {
      wx.showToast({ title: '已达库存上限', icon: 'none' });
      return;
    }

    // 更新购物车
    const newCartItems = [...this.data.cartItems];
    const existingItem = newCartItems.find(item => item.id === foodId);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      newCartItems.push({ ...food, quantity: 1 });
    }

    // 更新购物车并重新计算总数和总价（会自动同步到后端）
    this.updateCart(newCartItems);

    // 更新当前显示列表中的数量
    const updatedQuantity = newCartItems.find(item => item.id === foodId).quantity;
    this.updateCurrentFoodQuantity(foodId, updatedQuantity);

    // 显示添加成功提示
    wx.showToast({ title: '已添加', icon: 'success', duration: 1000 });
  },

  // 减少商品数量
  async decreaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    console.log('减少商品数量:', foodId);

    // 更新购物车
    let newCartItems = [...this.data.cartItems];
    const existingItemIndex = newCartItems.findIndex(item => item.id === foodId);

    if (existingItemIndex !== -1) {
      newCartItems[existingItemIndex].quantity -= 1;

      const newQuantity = newCartItems[existingItemIndex].quantity;

      // 如果数量为0，从购物车中移除
      if (newQuantity <= 0) {
        newCartItems = newCartItems.filter(item => item.id !== foodId);
        // 从后端删除该商品
        try {
          const userInfo = wx.getStorageSync('userInfo');
          if (userInfo && userInfo.id) {
            await cartAPI.removeCartItem(foodId);
            console.log(`从后端删除商品 ${foodId}`);
          }
        } catch (error) {
          console.error(`删除商品 ${foodId} 失败:`, error);
        }
      } else {
        // 数量大于0，更新到后端
        try {
          const userInfo = wx.getStorageSync('userInfo');
          if (userInfo && userInfo.id) {
            await cartAPI.updateCartItem(foodId, newQuantity);
            console.log(`更新商品 ${foodId} 数量到后端: ${newQuantity}`);
          }
        } catch (error) {
          console.error(`更新商品 ${foodId} 数量失败:`, error);
        }
      }

      // 更新购物车并重新计算总数和总价（跳过已单独处理的商品）
      this.updateCart(newCartItems, { skipProductId: foodId });

      // 更新当前显示列表中的数量
      const updatedQuantity = newCartItems.find(item => item.id === foodId)?.quantity || 0;
      this.updateCurrentFoodQuantity(foodId, updatedQuantity);
    }
  },

  // 更新当前食品列表中的数量
  updateCurrentFoodQuantity(foodId, quantity) {
    const updatedFoodList = this.data.currentFoodList.map(item => {
      if (item.id === foodId) {
        return { ...item, quantity: quantity };
      }
      return item;
    });

    this.setData({
      currentFoodList: updatedFoodList
    });
  },

  // 更新购物车数据
  updateCart(cartItems, options = {}) {
    const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

    this.setData({
      cartItems: cartItems,
      cartCount: cartCount,
      totalPrice: totalPrice.toFixed(2)
    });

    // 同步购物车到后端，除非指定了skipSync选项
    if (!options.skipSync) {
      this.syncCartToBackend(cartItems, options);
    }
  },

  /**
   * 同步购物车数据到后端
   * @param {Array} cartItems 购物车商品列表
   * @param {Object} options 选项 { skipProductId: 跳过同步的商品ID（已单独处理） }
   */
  async syncCartToBackend(cartItems, options = {}) {
    try {
      // 获取用户ID
      const userInfo = wx.getStorageSync('userInfo');
      if (!userInfo || !userInfo.id) {
        console.log('未登录用户，跳过购物车同步');
        return;
      }

      const { skipProductId } = options;

      // 遍历购物车商品，同步到后端
      for (let i = 0; i < cartItems.length; i++) {
        const item = cartItems[i];
        // 如果该商品已单独处理，跳过
        if (skipProductId && item.id === skipProductId) {
          continue;
        }

        try {
          if (item.quantity > 0) {
            // 更新或添加商品到购物车
            await cartAPI.updateCartItem(item.id, item.quantity);
            console.log(`同步商品 ${item.id} 到购物车，数量: ${item.quantity}`);
          }
        } catch (error) {
          console.error(`同步商品 ${item.id} 失败:`, error);
          // 如果更新失败（可能是商品不存在），尝试添加
          if (item.quantity > 0) {
            try {
              await cartAPI.addToCart(item.id, item.quantity);
              console.log(`添加商品 ${item.id} 到购物车，数量: ${item.quantity}`);
            } catch (addError) {
              console.error(`添加商品 ${item.id} 失败:`, addError);
            }
          }
        }
      }
    } catch (error) {
      console.error('同步购物车到后端失败:', error);
      // 不显示错误提示，避免影响用户体验
    }
  },



  // 打开购物车
  openCart() {
    this.setData({ showCart: true });
  },

  // 关闭购物车
  closeCart() {
    this.setData({ showCart: false });
  },

  // 从后端获取购物车数据
  async getCartItems() {
    try {
      wx.showLoading({ title: '加载购物车...', mask: true });
      const cartData = await cartAPI.getCartItems();
      wx.hideLoading();

      console.log('购物车API原始响应:', JSON.stringify(cartData));

      // 更灵活的响应处理，不依赖success字段
      let cartItems = [];

      // 尝试多种可能的数据路径
      if (Array.isArray(cartData)) {
        // 响应直接是数组
        cartItems = cartData;
        console.log('购物车数据直接是数组:', cartItems);
      } else if (cartData && Array.isArray(cartData.data)) {
        // 响应是 { data: [...] }
        cartItems = cartData.data;
        console.log('购物车数据在data字段中:', cartItems);
      } else if (cartData && cartData.data && Array.isArray(cartData.data.items)) {
        // 响应是 { data: { items: [...] } }
        cartItems = cartData.data.items;
        console.log('购物车数据在data.items字段中:', cartItems);
      } else if (cartData && Array.isArray(cartData.items)) {
        // 响应是 { items: [...] }
        cartItems = cartData.items;
        console.log('购物车数据在items字段中:', cartItems);
      } else {
        // 尝试直接使用cartData作为购物车项（单个商品情况）
        if (cartData && typeof cartData === 'object' && cartData.id) {
          cartItems = [cartData];
          console.log('购物车数据是单个商品:', cartItems);
        } else {
          console.error('无法识别的购物车数据格式:', cartData);
        }
      }

      // 过滤掉数量为0的商品
      cartItems = cartItems.filter(item => {
        const quantity = parseInt(item.quantity || 0);
        return quantity > 0;
      });

      console.log('过滤后的购物车数据:', cartItems);

      // 标准化购物车数据格式
      const standardizedCartItems = cartItems.map(item => ({
        id: item.id || item.product_id || '',
        name: item.name || item.product_name || '未知商品',
        price: parseFloat(item.price || 0),
        quantity: parseInt(item.quantity || 0),
        image: item.image || item.image_url || '',
        product_id: item.product_id || item.id || ''
      }));

      console.log('标准化后的购物车数据:', standardizedCartItems);

      // 更新购物车数据
      this.updateCart(standardizedCartItems, { skipSync: true });
      console.log('购物车数据更新成功');
    } catch (error) {
      wx.hideLoading();
      console.error('获取购物车数据失败:', error);
      console.error('错误堆栈:', error.stack);
      // 显示错误提示，方便调试
      wx.showToast({
        title: '获取购物车数据失败',
        icon: 'none',
        duration: 2000
      });
    }
  },

  // 更新收藏图标URL
  updateFavoriteIcon() {
    const { isFavorite } = this.data;
    const app = getApp();
    const baseUrl = app.globalData.baseUrl.replace('/api', '');
    // 使用后端路径：/img/part/sc1.png (已收藏) 或 /img/part/sc2.png (未收藏)
    const iconUrl = isFavorite
      ? `${baseUrl}/img/part/sc1.png`
      : `${baseUrl}/img/part/sc2.png`;
    this.setData({
      favoriteIconUrl: iconUrl
    });
  },

  // 检查商家收藏状态
  checkFavoriteStatus() {
    const { merchantId } = this.data;
    if (!merchantId) {
      console.warn('商家ID为空，无法检查收藏状态');
      // 即使没有merchantId，也要设置默认图标
      this.updateFavoriteIcon();
      return;
    }

    // 确保merchantId是字符串格式（后端要求）
    const merchantIdStr = String(merchantId);
    console.log('检查商家收藏状态，商家ID:', merchantIdStr);
    // 检查商家是否已收藏
    favoriteAPI.checkFavoriteStatus(merchantIdStr)
      .then(res => {
        console.log('检查商家收藏状态结果:', res);
        if (res && res.success) {
          this.setData({
            isFavorite: res.data.isFavorite || false
          });
          this.updateFavoriteIcon();
        } else {
          // 如果检查失败，默认未收藏
          this.setData({
            isFavorite: false
          });
          this.updateFavoriteIcon();
        }
      })
      .catch(error => {
        console.error('检查商家收藏状态失败:', error);
        // 错误情况下默认未收藏
        this.setData({
          isFavorite: false
        });
        this.updateFavoriteIcon();
      });
  },

  // 切换商家收藏状态
  toggleFavorite() {
    const { merchantId, isFavorite } = this.data;
    if (!merchantId) {
      wx.showToast({ title: '商家信息获取失败', icon: 'none' });
      return;
    }

    // 确保merchantId是字符串格式（后端要求）
    const merchantIdStr = String(merchantId);
    const currentStatus = isFavorite;
    const newStatus = !currentStatus;

    console.log('切换收藏状态，商家ID:', merchantIdStr);
    console.log('当前状态:', currentStatus ? '已收藏' : '未收藏');
    console.log('目标状态:', newStatus ? '收藏' : '取消收藏');

    // 根据当前状态决定调用哪个API
    const apiCall = currentStatus
      ? favoriteAPI.removeFavorite(merchantIdStr)  // 当前已收藏，点击后取消收藏
      : favoriteAPI.addFavorite(merchantIdStr);    // 当前未收藏，点击后添加收藏

    // 显示加载提示
    wx.showLoading({ title: currentStatus ? '取消收藏中...' : '添加收藏中...', mask: true });

    apiCall
      .then(res => {
        wx.hideLoading();
        console.log('收藏操作响应:', res);

        if (res && res.success) {
          // 更新状态
          this.setData({
            isFavorite: newStatus
          });
          // 更新图标
          this.updateFavoriteIcon();

          // 显示成功提示
          const successMsg = currentStatus ? '已取消收藏' : '已添加收藏';
          wx.showToast({
            title: successMsg,
            icon: 'success',
            duration: 1500
          });

          console.log('收藏状态更新成功，新状态:', newStatus ? '已收藏' : '未收藏');
        } else {
          const errorMsg = res?.message || '操作失败';
          console.error('收藏操作失败:', errorMsg);
          wx.showToast({
            title: errorMsg,
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(error => {
        wx.hideLoading();
        console.error('切换收藏状态失败:', error);
        const errorMsg = error?.message || '操作失败，请重试';
        wx.showToast({
          title: errorMsg,
          icon: 'none',
          duration: 2000
        });
      });
  },

  // 选择地址
  selectAddress() {
    console.log('跳转到地址选择页面');
    // 跳转到地址选择页面，使用navigateTo可以返回
    wx.navigateTo({
      url: '/pages/old_address/addresses?from=order-food'
    });
  },

  // 设置默认地址
  setDefaultAddress(addressId) {
    console.log('设置默认地址:', addressId);

    // 获取用户ID
    const userInfo = wx.getStorageSync('userInfo') || {};
    const userId = userInfo.id || '';

    // 调用API设置默认地址
    addressAPI.setDefaultAddress(addressId, userId)
      .then(res => {
        console.log('设置默认地址成功:', res);
        // 重新加载地址列表
        this.loadAddresses();
        wx.showToast({ title: '已设置为默认地址', icon: 'success' });
      })
      .catch(error => {
        console.error('设置默认地址失败:', error);
        wx.showToast({ title: '设置默认地址失败', icon: 'none' });
      });
  },

  // 选择配送方式
  selectDeliveryMethod(e) {
    const method = e.currentTarget.dataset.method;
    this.setData({
      deliveryMethod: method
    });

    // 如果是自取，生成取餐号
    if (method === '自取') {
      const pickupNumber = this.generatePickupNumber();
      this.setData({
        pickupNumber: pickupNumber,
        'pickupTime.estimatedTime': '请选择',
        'pickupTime.selectedDate': '',
        'pickupTime.selectedSlot': ''
      });
    }
  },

  // 备注输入
  onNoteInput(e) {
    this.setData({
      noteContent: e.detail.value
    });
  },

  // 去结算
  checkout() {
    const { cartItems, totalPrice, relativeId, selectedAddress, merchantId } = this.data;

    // 检查购物车是否为空
    if (cartItems.length === 0) {
      wx.showToast({ title: '购物车为空', icon: 'none' });
      return;
    }

    // 检查是否选择了地址
    if (!selectedAddress) {
      wx.showToast({ title: '请选择收货地址', icon: 'none' });
      return;
    }

    // 获取用户数据
    const userInfo = wx.getStorageSync('userInfo') || {};

    // 准备跳转参数
    const params = {
      // 购物车数据
      cartItems: JSON.stringify(cartItems),
      // 结算价格
      totalPrice: totalPrice,
      // 用户数据
      relativeId: relativeId,
      userId: userInfo.id || '',
      userName: userInfo.user_name || userInfo.name || '',
      phone: userInfo.phone || '',
      // 地址数据
      addressId: selectedAddress.id || '',
      address: JSON.stringify(selectedAddress),
      // 商家ID
      merchantId: merchantId || ''
    };

    console.log('结算参数:', params);

    // 跳转到确认订单页面
    wx.navigateTo({
      url: `/pages/old-confirm/order-confirm?${Object.keys(params)
        .map(key => `${key}=${encodeURIComponent(params[key])}`)
        .join('&')}`
    });
  },

  // 立即支付
  payNow() {
    const { cartItems, totalPrice, relativeId, selectedAddress, merchantId, deliveryMethod, deliveryTime, pickupTime, pickupNumber, noteContent, selectedTableware } = this.data;

    // 检查购物车是否为空
    if (cartItems.length === 0) {
      wx.showToast({ title: '购物车为空', icon: 'none' });
      return;
    }

    // 如果是外送，检查是否选择了地址
    if (deliveryMethod === '外送' && !selectedAddress) {
      wx.showToast({ title: '请选择收货地址', icon: 'none' });
      return;
    }

    // 如果是自取，设置默认自取时间（如果未选择）
    if (deliveryMethod === '自取' && (!pickupTime.estimatedTime || pickupTime.estimatedTime === '请选择')) {
      this.setData({
        'pickupTime.estimatedTime': '立即自取',
        'pickupTime.type': '立即自取'
      });
    }

    // 获取用户数据
    const userInfo = wx.getStorageSync('userInfo') || {};

    // 生成取餐号（如果是自取）
    let finalPickupNumber = pickupNumber;
    if (deliveryMethod === '自取' && !finalPickupNumber) {
      finalPickupNumber = this.generatePickupNumber();
    }

    // 转换商品项格式以匹配后端要求
    const items = cartItems.map(item => ({
      productId: item.id || '',
      productName: item.name || '',
      price: Number(item.price) || 0,
      quantity: Number(item.quantity) || 0,
      subtotal: (Number(item.price) || 0) * (Number(item.quantity) || 0)
    }));

    // 构建订单数据
    const orderData = {
      total_amount: Number(totalPrice),
      payment_method: 'points',
      order_type: deliveryMethod === '自取' ? 'dine_in' : 'takeaway',
      merchant_id: merchantId || '',
      items: items,
      remark: noteContent || null,
      utensils: Number(selectedTableware) || 0,
      pickup_number: deliveryMethod === '自取' ? finalPickupNumber : null,
      delivery_fee: deliveryMethod === '外送' ? (this.data.deliveryFee || 0) : 0
    };

    // 如果是外送，添加配送地址信息
    if (deliveryMethod === '外送' && selectedAddress) {
      orderData.delivery_address = `${selectedAddress.province || ''}${selectedAddress.city || ''}${selectedAddress.district || ''}${selectedAddress.address || ''}`;
      orderData.recipient_name = selectedAddress.name || selectedAddress.receiver_name || '';
      orderData.recipient_phone = selectedAddress.phone || '';

      // 添加配送时间：如果选择立即配送，传递 null；否则传递选择的时间
      if (deliveryTime && deliveryTime.estimatedTime && deliveryTime.estimatedTime !== '立即配送') {
        // 将选择的时间转换为 datetime 格式
        // deliveryTime.estimatedTime 可能是 "今天 12:00 - 14:00" 或具体时间
        orderData.scheduledDeliveryTime = deliveryTime.estimatedTime;
      } else {
        // 立即配送，传递 null
        orderData.scheduledDeliveryTime = null;
      }
    } else if (deliveryMethod === '自取') {
      // 自取订单：如果选择立即自取，传递 null；否则传递选择的时间
      if (pickupTime && pickupTime.estimatedTime && pickupTime.estimatedTime !== '立即自取' && pickupTime.estimatedTime !== '请选择') {
        orderData.scheduledDeliveryTime = pickupTime.estimatedTime;
      } else {
        orderData.scheduledDeliveryTime = null;
      }
    }

    console.log('立即支付订单数据:', orderData);

    // 显示提交中提示
    wx.showLoading({ title: '提交订单中...' });

    // 调用API创建订单
    orderAPI.createOrder(orderData)
      .then(res => {
        wx.hideLoading();
        console.log('订单创建成功:', res);

        if (res.success !== false) {
          // 清空购物车
          this.setData({
            cartItems: [],
            cartCount: 0,
            totalPrice: 0
          });

          // 保存订单信息
          const orderInfo = {
            orderId: res.data?.orderId || res.orderId,
            orderNo: res.data?.orderNo || res.orderNo,
            totalAmount: totalPrice,
            deliveryMethod: deliveryMethod
          };
          wx.setStorageSync('lastOrder', orderInfo);

          // 跳转到支付成功页面
          wx.redirectTo({
            url: `/pages/pay_success/pay_success?orderId=${orderInfo.orderId || ''}&orderNo=${orderInfo.orderNo || ''}&totalAmount=${totalPrice}&deliveryMethod=${deliveryMethod}`
          });
        } else {
          wx.showToast({
            title: res.message || '订单创建失败',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(error => {
        wx.hideLoading();
        console.error('订单创建失败:', error);
        wx.showToast({
          title: error.message || '订单创建失败，请重试',
          icon: 'none',
          duration: 2000
        });
      });
  },

  // 生成取餐号（与order-confirm页面相同的逻辑）
  generatePickupNumber() {
    const now = new Date();
    let pickupInfo = wx.getStorageSync('pickupNumberInfo') || {};
    let { resetTimestamp = 0, currentLetter = 'A', currentNumber = 1 } = pickupInfo;

    const today = new Date(now);
    today.setHours(4, 0, 0, 0);
    let resetTimeToday = today.getTime();

    if (now.getTime() < resetTimeToday) {
      resetTimeToday = new Date(today.getTime() - 24 * 60 * 60 * 1000).getTime();
    }

    if (resetTimestamp !== resetTimeToday) {
      currentLetter = 'A';
      currentNumber = 1;
      resetTimestamp = resetTimeToday;
    }

    const formattedNumber = String(currentNumber).padStart(5, '0');
    const pickupNumber = `${currentLetter}-${formattedNumber}`;

    currentNumber++;

    if (currentNumber > 99999) {
      currentNumber = 1;
      if (currentLetter === 'Z') {
        currentLetter = 'A';
      } else {
        currentLetter = String.fromCharCode(currentLetter.charCodeAt(0) + 1);
      }
    }

    wx.setStorageSync('pickupNumberInfo', {
      resetTimestamp,
      currentLetter,
      currentNumber
    });

    return pickupNumber;
  }
});