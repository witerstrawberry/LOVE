const { orderAPI } = require('../../utils/api');
const { isLoggedIn } = require('../../utils/auth');

Page({
  data: {
    orders: [],
    loading: false,
    errorMessage: ''
  },

  // 导航到首页
  navigateToHome() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  },

  // 导航到分类页
  navigateToCategory() {
    wx.switchTab({
      url: '/pages/goods/goods'
    });
  },

  // 导航到购物车
  navigateToCart() {
    wx.switchTab({
      url: '/pages/cart/index'
    });
  },

  // 导航到我的页面
  navigateToMine() {
    wx.switchTab({
      url: '/pages/mine/index'
    });
  },

  onLoad(options) {
    console.log('订单页面加载，参数:', options);

    // 检查登录状态
    if (!isLoggedIn()) {
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000
      });
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/login/login'
        });
      }, 2000);
      return;
    }

    this.loadOrderList();
  },

  onShow() {
    // 检查登录状态
    if (!isLoggedIn()) {
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000
      });
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/login/login'
        });
      }, 2000);
      return;
    }

    // 刷新订单列表
    this.refreshOrderList();
  },

  onPullDownRefresh() {
    this.refreshOrderList();
  },

  // 加载订单列表
  loadOrderList() {
    if (this.data.loading) return;

    this.setData({
      loading: true,
      errorMessage: ''
    });

    // 构建请求参数 - 获取所有订单，不进行状态筛选
    const params = {
      page: 1,
      pageSize: 100 // 后端限制最大为100
    };
    console.log('请求订单列表，参数:', params);
    orderAPI.getUserOrders(params)
      .then(response => {
        console.log('订单列表响应:', response);

        if (response && response.data && response.data.orders) {
          // 格式化订单数据
          const formattedOrders = response.data.orders.map(order => ({
            ...order,
            statusText: this.getStatusText(order.status),
            statusClass: this.getStatusClass(order.status),
            formattedAmount: parseFloat(order.total_amount || 0).toFixed(2), // 直接格式化金额，不除以100
            formattedTime: this.formatTime(order.created_at),
            utensilText: order.utensils ? `${order.utensils}份` : '无'
          }));

          this.setData({
            orders: formattedOrders,
            loading: false
          });
        } else {
          this.setData({
            orders: [],
            loading: false,
            errorMessage: '暂无订单数据'
          });
        }
      })
      .catch(error => {
        console.error('获取订单列表失败:', error);
        this.setData({
          loading: false,
          errorMessage: '获取订单列表失败，请重试'
        });

        wx.showToast({
          title: '获取订单列表失败',
          icon: 'none',
          duration: 2000
        });
      })
      .finally(() => {
        wx.stopPullDownRefresh();
      });
  },

  // 刷新订单列表
  refreshOrderList() {
    this.loadOrderList();
  },

  // 查看订单详情
  onOrderDetail(e) {
    const orderId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/old-detail/order-detail?id=${orderId}`
    });
  },

  // 取消订单
  onCancelOrder(e) {
    const orderId = e.currentTarget.dataset.id;

    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个订单吗？',
      success: (res) => {
        if (res.confirm) {
          this.cancelOrder(orderId);
        }
      }
    });
  },

  // 执行取消订单
  cancelOrder(orderId) {
    wx.showLoading({
      title: '取消中...'
    });

    orderAPI.cancelOrder(orderId)
      .then(response => {
        wx.hideLoading();
        wx.showToast({
          title: '订单已取消',
          icon: 'success'
        });
        this.refreshOrderList();
      })
      .catch(error => {
        wx.hideLoading();
        console.error('取消订单失败:', error);
        wx.showToast({
          title: '取消失败，请重试',
          icon: 'none'
        });
      });
  },

  // 删除订单
  onDeleteOrder(e) {
    const orderId = e.currentTarget.dataset.id;

    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个订单吗？删除后无法恢复。',
      success: (res) => {
        if (res.confirm) {
          this.deleteOrder(orderId);
        }
      }
    });
  },

  // 执行删除订单
  deleteOrder(orderId) {
    wx.showLoading({
      title: '删除中...'
    });

    // 先获取订单详情，检查是否使用了优惠券
    orderAPI.getOrderDetail(orderId)
      .then(orderDetail => {
        console.log('订单详情:', orderDetail);
        const usedCouponId = orderDetail.data?.coupon_id || orderDetail.data?.used_coupon_id;

        // 删除订单
        return orderAPI.deleteOrder(orderId)
          .then(deleteResult => {
            // 如果订单使用了优惠券，恢复优惠券状态
            if (usedCouponId) {
              console.log('恢复优惠券状态，优惠券ID:', usedCouponId);
              // 直接调用couponAPI.restoreCoupon方法
              const { couponAPI } = require('../../utils/api');
              return couponAPI.restoreCoupon(usedCouponId)
                .then(() => {
                  // 同时从本地存储中移除已使用的优惠券ID
                  const usedCoupons = wx.getStorageSync('usedCoupons') || [];
                  const updatedUsedCoupons = usedCoupons.filter(couponId => couponId !== usedCouponId);
                  wx.setStorageSync('usedCoupons', updatedUsedCoupons);
                  console.log('已从本地存储移除优惠券ID:', usedCouponId);
                  return deleteResult;
                })
                .catch(couponError => {
                  console.warn('恢复优惠券状态失败，但订单已成功删除:', couponError);
                  return deleteResult;
                });
            }
            return deleteResult;
          });
      })
      .then(response => {
        wx.hideLoading();
        wx.showToast({
          title: '订单已删除',
          icon: 'success'
        });
        this.refreshOrderList();
      })
      .catch(error => {
        wx.hideLoading();
        console.error('删除订单失败:', error);
        wx.showToast({
          title: '删除失败，请重试',
          icon: 'none'
        });
      });
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      'pending': '待付款',
      'paid': '已下单',
      'shipped': '已接单',
      'delivered': '已完成',
      'cancelled': '已取消'
    };
    return statusMap[status] || '未知状态';
  },

  // 获取状态样式类
  getStatusClass(status) {
    const classMap = {
      'pending': 'status-pending',
      'paid': 'status-paid',
      'shipped': 'status-shipped',
      'delivered': 'status-delivered',
      'cancelled': 'status-cancelled'
    };
    return classMap[status] || 'status-default';
  },

  // 格式化时间
  formatTime(timeStr) {
    const date = new Date(timeStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hour = String(date.getHours()).padStart(2, '0');
    const minute = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day} ${hour}:${minute}`;
  },

  // 重试加载
  onRetry() {
    this.loadOrderList();
  }
});