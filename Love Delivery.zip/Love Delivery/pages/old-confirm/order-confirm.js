// pages/old-confirm/order-confirm.js
const { addressAPI, merchantAPI } = require('../../utils/api.js');
const { getFullImageUrl } = require('../../utils/imageUtils.js');
const { getApiUrl } = require('../../utils/config');
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    // 收货地址信息
    address: {
      id: '',
      name: '',
      phone: '',
      location: '',
      province: '',
      city: '',
      district: '',
      detail: ''
    },
      addressList: [], // 保存获取到的地址列表
      
      // 商家ID
      merchantId: '',
      
      // 配送方式
    deliveryMethod: '外送', // '外送' 或 '自取'
    
    // 配送时间选项
    deliveryTime: {
      type: '立即配送',
      selectedDate: '今天',
      selectedSlot: '12:00 - 14:00'
    },
    
    // 自取时间（单独管理，未选择时显示"请选择"）
    pickupTime: {
      type: '',
      estimatedTime: '请选择',
      selectedDate: '',
      selectedSlot: ''
    },
    
    // 时间选择器相关
    showTimePicker: false,
    timePickerTitle: '',
    timeOptions: [],
    timeOptionsByDate: {}, // 按日期分组的时间选项
    currentTimeType: '', // 'delivery' 或 'pickup'
    selectedDate: 'today', // 当前选中的日期标签
    
    // 订单商品列表
    orderItems: [],
    
    // 配送费（从后端获取）
    deliveryFee: 0,
    
    // 订单总价
    totalPrice: 17.6,
    
    // 取餐号
    pickupNumber: '',
    
    // 商家信息
    merchantInfo: {
      name: '',
      address: '',
      phone: '',
      logo: ''
    },
    
    // 是否显示取餐号提示
    showPickupHint: true,
    
    // 餐具选择相关
    showTablewareDialog: false,
    tablewareOptions: [
      { id: 0, name: '按餐量提供' },
      { id: 1, name: '一份餐具' },
      { id: 2, name: '两份餐具' },
      { id: 3, name: '三份餐具' }
    ],
    selectedTableware: 0, // 默认选择"按餐量提供"
    
    // 备注相关
    showNoteDialog: false,
    noteContent: '',
    // 默认备注选项
    defaultNotes: [
      '少盐',
      '少糖',
      '不要辣',
      '多放醋',
      '不要香菜',
      '不要葱花',
      '多加饭',
      '多加菜',
      '不要蒜',
      '不要姜',
      '打包',
      '堂食'
    ]
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('order-confirm onLoad options:', options);
    
    let cartItems = null;
    let totalPrice = null;
    
    // 优先从URL参数获取购物车数据（从order-food页面传递）
    if (options && options.cartItems) {
      try {
        cartItems = JSON.parse(decodeURIComponent(options.cartItems));
        console.log('从URL参数获取到购物车数据:', cartItems);
      } catch (e) {
        console.error('解析URL参数中的cartItems失败:', e);
      }
    }
    
    // 优先从URL参数获取总价
    if (options && options.totalPrice) {
      totalPrice = parseFloat(options.totalPrice);
      console.log('从URL参数获取到总价:', totalPrice);
    }
    
    // 如果URL参数中没有数据，则从本地存储获取（兼容旧版本）
    if (!cartItems || cartItems.length === 0) {
      cartItems = wx.getStorageSync('currentCart');
      console.log('从本地存储获取到购物车数据:', cartItems);
    }
    
    if (!totalPrice) {
      totalPrice = wx.getStorageSync('totalPrice');
      console.log('从本地存储获取到总价:', totalPrice);
    }
    
    // 如果有购物车数据，更新订单数据
    if (cartItems && cartItems.length > 0) {
      console.log('处理购物车数据:', cartItems);
      console.log('订单总价:', totalPrice);
      
      // 格式化购物车商品为订单项目格式
      const orderItems = cartItems.map(item => ({
        id: item.id,
        name: item.name,
        store: item.store || this.data.restaurant?.name || '爱心送餐',
        image: getFullImageUrl(item.image) || '/images/default-avatar.png',
        options: item.options || this.getFoodOptions(item),
        quantity: item.quantity,
        price: item.price,
        originalPrice: item.originalPrice || item.price
      }));
           
      // 更新数据
      this.setData({
        orderItems: orderItems,
        totalPrice: parseFloat(totalPrice) || this.data.totalPrice
      });
    } else if (options && options.orderData) {
      // 也支持从上个页面通过参数接收订单信息
      try {
        const orderData = JSON.parse(options.orderData);
        // 更新订单数据，处理商品图片路径
        const processedItems = (orderData.items || []).map(item => ({
          ...item,
          image: getFullImageUrl(item.image) || '/images/default-avatar.png'
        }));
        this.setData({
          orderItems: processedItems,
          totalPrice: orderData.totalPrice || this.data.totalPrice
        });
      } catch (e) {
        console.error('解析订单数据失败:', e);
      }
    }
    
    // 处理地址信息：优先从URL参数获取
    if (options && options.address) {
      try {
        const addressData = JSON.parse(decodeURIComponent(options.address));
        console.log('从URL参数获取到地址数据:', addressData);
        // 格式化并设置地址
        // 确保详细地址字段正确获取
        const detailAddress = addressData.detail_address || addressData.address || addressData.detail || '';
        const formattedAddress = {
          id: addressData.id,
          name: addressData.receiver_name || addressData.name,
          phone: addressData.phone,
          location: this.formatLocation(addressData),
          province: addressData.province || '',
          city: addressData.city || '',
          district: addressData.district || '',
          detail: detailAddress
        };
        console.log('格式化后的地址数据:', formattedAddress);
        this.setData({ address: formattedAddress });
      } catch (e) {
        console.error('解析URL参数中的地址失败:', e);
        // 如果解析失败，则获取地址列表
    this.fetchAddressList();
      }
    } else {
      // 如果没有从URL参数传递地址，则获取地址列表
      this.fetchAddressList();
    }
    
    // 获取商家信息
    this.fetchMerchantInfo(options);
  },
  
  /**
   * 获取商家信息
   */
  fetchMerchantInfo: function(options) {
    // 优先从URL参数获取merchantId
    let merchantId = '';
    if (options && options.merchantId) {
      merchantId = options.merchantId;
      console.log('从URL参数获取到商家ID:', merchantId);
    } else {
      // 从本地存储获取
      merchantId = wx.getStorageSync('activeMerchantId') || '';
      console.log('从本地存储获取到商家ID:', merchantId);
    }
    
    // 保存merchantId到data中，供提交订单时使用
    this.setData({ merchantId: merchantId });
    console.log('设置的商家ID:', this.data.merchantId);
    
    if (!merchantId) {
      console.error('未找到商家ID，订单提交将失败');
      wx.showToast({ 
        title: '商家信息缺失，请返回重新选择', 
        icon: 'none',
        duration: 3000
      });
      return;
    }
    
    console.log('获取商家信息，merchantId:', merchantId);
    
    // 调用API获取商家信息
    merchantAPI.getPublicMerchantInfo({ merchantId: merchantId })
      .then(res => {
        console.log('获取商家信息成功:', res);
        if (res.data) {
          // 从返回数据中提取商家ID（确保使用正确的ID）
          const extractedMerchantId = res.data.id || res.data.merchant_id || merchantId;
          if (extractedMerchantId && extractedMerchantId !== merchantId) {
            console.log('从API响应中提取到新的商家ID:', extractedMerchantId);
            // 更新本地存储和data中的merchantId
            wx.setStorageSync('activeMerchantId', extractedMerchantId);
            this.setData({ merchantId: extractedMerchantId });
          }
          
          const merchantInfo = {
            name: res.data.merchant_name || res.data.name || '商家名称',
            address: res.data.business_address || res.data.register_address || res.data.address || '地址信息',
            phone: res.data.contact_phone || res.data.legal_phone || res.data.phone || '联系电话',
            logo: res.data.logo ? getFullImageUrl(res.data.logo) : ''
          };
          
          // 获取配送费
          const deliveryFee = res.data.delivery_fee || res.data.deliveryFee || 0;
          
          this.setData({ 
            merchantInfo: merchantInfo,
            deliveryFee: parseFloat(deliveryFee) || 0
          });
          
          console.log('获取到的配送费:', this.data.deliveryFee);
          console.log('当前使用的商家ID:', this.data.merchantId);
        }
      })
      .catch(error => {
        console.error('获取商家信息失败:', error);
        // 如果获取失败，使用默认配送费 0
        this.setData({ deliveryFee: 0 });
      });
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('order-confirm页面显示');
    // 检查是否有从地址选择页面返回的选中地址
    let selectedAddress = wx.getStorageSync('selectedAddressForOrder');
    
    // 如果没有找到，尝试从另一个存储键获取
    if (!selectedAddress) {
      selectedAddress = wx.getStorageSync('selectedAddress');
    }
    
    // 如果还没有，尝试从全局变量获取
    if (!selectedAddress) {
      const app = getApp();
      selectedAddress = app.globalData.selectedAddress;
    }
    
    if (selectedAddress) {
      console.log('从地址选择页面获取到选中地址:', selectedAddress);
      // 格式化并设置选中的地址
      // 确保详细地址字段正确获取（时羊村123等详细地址）
      const detailAddress = selectedAddress.detail_address || selectedAddress.address || selectedAddress.detail || '';
      const formattedAddress = {
        id: selectedAddress.id,
        name: selectedAddress.receiver_name || selectedAddress.name,
        phone: selectedAddress.phone,
        location: this.formatLocation(selectedAddress),
        province: selectedAddress.province || '',
        city: selectedAddress.city || '',
        district: selectedAddress.district || '',
        detail: detailAddress
      };
      console.log('格式化后的地址数据（包含详细地址）:', formattedAddress);
      this.setData({ address: formattedAddress });
      // 清除本地存储的选中地址，避免重复使用
      wx.removeStorageSync('selectedAddressForOrder');
      wx.removeStorageSync('selectedAddress');
      // 清除全局变量
      const app = getApp();
      if (app.globalData) {
        app.globalData.selectedAddress = null;
      }
    }
    
    // 如果当前是自取模式且没有取餐号，生成取餐号
    if (this.data.deliveryMethod === '自取' && !this.data.pickupNumber) {
      const pickupNumber = this.generatePickupNumber();
      this.setData({ pickupNumber: pickupNumber });
    }
  },
  
  /**
   * 获取商品选项信息
   */
  getFoodOptions: function(food) {
    // 根据商品信息生成选项描述
    let options = [];
    
    if (food.weight) {
      options.push(`${food.weight}`);
    }
    if (food.specifications) {
      options.push(food.specifications);
    }
    if (food.category_name) {
      options.push(food.category_name);
    }
    
    // 如果没有特殊选项，提供默认值
    if (options.length === 0) {
      return '标准规格';
    }
    
    return options.join('，');
  },
    
    /**
     * 从后端获取地址列表
     */
    fetchAddressList: function() {
      wx.showLoading({ title: '加载地址中...' });
      
      // 获取用户信息（假设存储在本地）
      const userInfo = wx.getStorageSync('userInfo');
      const userId = userInfo?.id || '';
      console.log('获取用户ID:', userId);
      
      // 传递用户ID到API
      addressAPI.getAddressList({ userId })
        .then(res => {
          wx.hideLoading();
          console.log('获取地址列表成功:', res);
          
          if (res.data && res.data.list && res.data.list.length > 0) {
            // 获取地址列表
            const addresses = res.data.list;
            this.setData({ addressList: addresses });
            
            // 查找默认地址或使用第一个地址
            const defaultAddress = addresses.find(addr => addr.is_default) || addresses[0];
            if (defaultAddress) {
              // 格式化地址信息
              // 确保详细地址字段正确获取（时羊村123等详细地址）
              const detailAddress = defaultAddress.detail_address || defaultAddress.address || defaultAddress.detail || '';
              const formattedAddress = {
                id: defaultAddress.id,
                name: defaultAddress.receiver_name || defaultAddress.name,
                phone: defaultAddress.phone,
                location: this.formatLocation(defaultAddress),
                province: defaultAddress.province || '',
                city: defaultAddress.city || '',
                district: defaultAddress.district || '',
                detail: detailAddress
              };
              console.log('默认地址格式化后（包含详细地址）:', formattedAddress);
              this.setData({ address: formattedAddress });
            }
          } else {
            wx.showToast({ 
              title: '暂无地址信息', 
              icon: 'none',
              success: () => {
                // 延迟跳转到地址管理页面
                setTimeout(() => {
                  wx.navigateTo({ url: '/pages/old_address/addresses?from=order-confirm' });
                }, 1500);
              }
            });
          }
        })
        .catch(error => {
          wx.hideLoading();
          console.error('获取地址列表失败:', error);
          
          // 如果是用户ID为空的错误，提供更具体的提示
          if (error.message && error.message.includes('用户ID不能为空')) {
            wx.showToast({ 
              title: '请先登录', 
              icon: 'none',
              success: () => {
                setTimeout(() => {
                  wx.navigateTo({ url: '/pages/login/login' });
                }, 1500);
              }
            });
          } else {
            wx.showToast({ 
              title: '获取地址失败，请重试', 
              icon: 'none'
            });
          }
        });
    },
    
    /**
     * 格式化地址显示文本
     */
    formatLocation: function(address) {
      const province = address.province || '';
      const city = address.city || '';
      const district = address.district || '';
      // 优先使用 detail_address，然后是 address，最后是 detail 字段
      const detail = address.detail_address || address.address || address.detail || '';
      
      // 拼接完整地址
      return `${province}${city}${district}${detail}`;
    },
    
    /**
  
  /**
   * 选择地址
   */
  selectAddress: function() {
    // 跳转到地址管理页面选择地址
    wx.navigateTo({
      url: '/pages/old_address/addresses?from=order-confirm'
    });
  },
  
  /**
   * 选择配送方式
   */
  selectDeliveryMethod: function(e) {
    const method = e.currentTarget.dataset.method;
    if (method === '自取') {
      // 切换到自取模式时，生成取餐号
      const pickupNumber = this.generatePickupNumber();
    this.setData({
      deliveryMethod: method,
        pickupNumber: pickupNumber,
        'pickupTime.type': '',
        'pickupTime.estimatedTime': '请选择',
        'pickupTime.selectedDate': '',
        'pickupTime.selectedSlot': ''
      });
    } else {
      this.setData({
        deliveryMethod: method,
        'deliveryTime.type': '立即配送'
    });
    }
  },
  
  /**
   * 生成时间选项数据 - 显示今天和明天的时间段，用于左右分栏布局
   */
  generateTimeOptions: function(type) {
    // 确保type参数有效
    const validType = type === 'delivery' || type === 'pickup' ? type : 'delivery';
    
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    // 格式化日期为 MM-DD 格式
    const formatDate = (date) => {
      if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
        return '';
      }
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${month}-${day}`;
    };
    
    // 定义时间段
    const timeSlots = ['09:00 - 11:00', '11:00 - 13:00', '13:00 - 15:00', '15:00 - 17:00', '17:00 - 19:00', '19:00 - 21:00'];
    
    // 生成时间选项，按日期分组
    const timeOptions = {
      today: [],
      tomorrow: []
    };
    
    // 添加今天的选项
    timeSlots.forEach(slot => {
      if (typeof slot !== 'string' || !slot.includes('-')) {
        return;
      }
      
      // 检查当前时间段是否已过期
      const currentHour = today.getHours();
      const slotParts = slot.split('-');
      const slotStartHour = slotParts[0] ? parseInt(slotParts[0].split(':')[0]) : 0;
      const isExpired = currentHour > slotStartHour;
      
      timeOptions.today.push({
        date: '今天',
        slot: slot,
        formattedDate: formatDate(today),
        isExpired: isExpired,
        type: validType,
        estimatedTime: validType === 'delivery' ? `预计${slotParts[0]}后送达` : `预计${slotParts[0]}可取`
      });
    });
    
    // 添加明天的选项
    timeSlots.forEach(slot => {
      if (typeof slot !== 'string' || !slot.includes('-')) {
        return;
      }
      
      const slotParts = slot.split('-');
      timeOptions.tomorrow.push({
        date: '明天',
        slot: slot,
        formattedDate: formatDate(tomorrow),
        isExpired: false,
        type: validType,
        estimatedTime: validType === 'delivery' ? `明天${slotParts[0]}送达` : `明天${slotParts[0]}可取`
      });
    });
    
    console.log('生成的时间选项:', timeOptions);
    return timeOptions;
  },
  
  /**
   * 选择配送时间
   */
  selectDeliveryTime: function() {
    try {
      console.log('打开配送时间选择器');
      const timeOptions = this.generateTimeOptions('delivery');
      
      // 确保生成的时间选项有效
      if (!timeOptions || typeof timeOptions !== 'object' || !timeOptions.today || !timeOptions.tomorrow) {
        console.error('生成的时间选项无效');
        wx.showToast({
          title: '加载时间选项失败',
          icon: 'none',
          duration: 1500
        });
        return;
      }
      
      this.setData({
        showTimePicker: true,
        timeOptionsByDate: timeOptions, // 按日期分组的时间选项
        timePickerTitle: '选择配送时间',
        currentTimeType: 'delivery',
        selectedDate: 'today' // 默认选中今天
      });
    } catch (error) {
      console.error('打开配送时间选择器时出错:', error);
      wx.showToast({
        title: '操作失败，请重试',
        icon: 'none',
        duration: 1500
      });
    }
  },
  
  /**
   * 选择自取时间
   */
  selectPickupTime: function() {
    try {
      console.log('打开自取时间选择器');
      const timeOptions = this.generateTimeOptions('pickup');
      
      // 确保生成的时间选项有效
      if (!timeOptions || typeof timeOptions !== 'object' || !timeOptions.today || !timeOptions.tomorrow) {
        console.error('生成的时间选项无效');
        wx.showToast({
          title: '加载时间选项失败',
          icon: 'none',
          duration: 1500
        });
        return;
      }
      
      this.setData({
        showTimePicker: true,
        timeOptionsByDate: timeOptions, // 按日期分组的时间选项
        timePickerTitle: '选择自取时间',
        currentTimeType: 'pickup',
        selectedDate: 'today' // 默认选中今天
      });
    } catch (error) {
      console.error('打开自取时间选择器时出错:', error);
      wx.showToast({
        title: '操作失败，请重试',
        icon: 'none',
        duration: 1500
      });
    }
  },
  
  /**
   * 切换选中的日期
   */
  selectDateTab: function(e) {
    const date = e.currentTarget.dataset.date;
    this.setData({ selectedDate: date });
  },
  
  /**
   * 选择时间选项
   */
  selectTimeOption: function(e) {
    try {
      console.log('selectTimeOption被调用，event:', e);
      
      // 安全获取事件数据
      if (!e || !e.currentTarget || !e.currentTarget.dataset) {
        console.error('事件数据无效');
        return;
      }
      
      const dateType = e.currentTarget.dataset.date;
      const index = e.currentTarget.dataset.index;
      console.log('选中的日期类型:', dateType, '索引:', index);
      
      // 确保所有必要的数据都存在
      if (!this.data || !this.data.timeOptionsByDate) {
        console.error('时间选项数据容器不存在');
        return;
      }
      
      // 确保dateType有效且对应的数据存在
      if (!dateType || !Array.isArray(this.data.timeOptionsByDate[dateType])) {
        console.error('无效的日期类型或日期数据不存在:', dateType);
        return;
      }
      
      // 确保索引有效
      const timeOptionsArray = this.data.timeOptionsByDate[dateType];
      if (index === undefined || index === null || index < 0 || index >= timeOptionsArray.length) {
        console.error('无效的索引:', index);
        return;
      }
      
      const selectedOption = timeOptionsArray[index];
      console.log('选中的选项:', selectedOption);
      
      // 确保selectedOption存在且是有效的对象
      if (!selectedOption || typeof selectedOption !== 'object') {
        console.error('选中的选项不存在或不是有效的对象');
        return;
      }
      
      // 检查是否选择了过期的时间
      if (selectedOption.hasOwnProperty('isExpired') && selectedOption.isExpired) {
        wx.showToast({
          title: '该时间段已过期',
          icon: 'none',
          duration: 1500
        });
        return;
      }
    
    // 根据当前时间类型更新对应的时间数据
    const currentTimeType = this.data.currentTimeType;
    if (currentTimeType === 'pickup') {
      // 更新自取时间
    this.setData({
        'pickupTime.type': '预约自取',
        'pickupTime.estimatedTime': selectedOption.estimatedTime || '',
        'pickupTime.selectedDate': selectedOption.date || '',
        'pickupTime.selectedSlot': selectedOption.slot || '',
        showTimePicker: false
      });
      console.log('更新后的pickupTime:', this.data.pickupTime);
    } else {
      // 更新配送时间
      this.setData({
        'deliveryTime.type': '预约配送',
      'deliveryTime.estimatedTime': selectedOption.estimatedTime || '',
      'deliveryTime.selectedDate': selectedOption.date || '',
      'deliveryTime.selectedSlot': selectedOption.slot || '',
      showTimePicker: false
    });
    console.log('更新后的deliveryTime:', this.data.deliveryTime);
    }
    
    // 提示用户选择成功
    wx.showToast({
      title: currentTimeType === 'pickup' ? '自取时间已选择' : '配送时间已选择',
      icon: 'success',
      duration: 1000
    });
    } catch (error) {
      console.error('选择时间选项时发生错误:', error);
      wx.showToast({
        title: '选择时间失败，请重试',
        icon: 'none',
        duration: 1500
      });
    }
  },
  
  /**
   * 阻止事件冒泡，防止点击对话框内容关闭选择器
   */
  stopPropagation: function(e) {
    e.stopPropagation();
  },
  
  /**
   * 关闭时间选择器
   */
  closeTimePicker: function() {
    this.setData({ showTimePicker: false });
  },
  
  /**
   * 切换特殊需求选项
   */
  toggleRequirement: function(e) {
    const id = e.currentTarget.dataset.id;
    const currentSelected = [...this.data.specialRequirements.selected];
    const index = currentSelected.indexOf(id);
    
    if (index > -1) {
      currentSelected.splice(index, 1);
    } else {
      currentSelected.push(id);
    }
    
    this.setData({
      'specialRequirements.selected': currentSelected
    });
  },
  
  /**
   * 输入自定义需求
   */
  inputCustomRequirement: function(e) {
    this.setData({
      'specialRequirements.custom': e.detail.value
    });
  },
  
  /**
   * 选择支付方式
   */
  selectPaymentMethod: function() {
    wx.showToast({ title: '找人付功能待实现', icon: 'none' });
  },
  
  /**
   * 打开备注对话框
   */
  openNoteDialog: function() {
    this.setData({
      showNoteDialog: true
    });
  },
  
  /**
   * 保存备注内容
   */
  saveNoteContent: function() {
    this.setData({
      showNoteDialog: false
    });
  },
  
  /**
   * 输入备注内容
   */
  onNoteInput: function(e) {
    this.setData({
      noteContent: e.detail.value
    });
  },
  
  /**
   * 添加默认备注
   */
  addDefaultNote: function(e) {
    const note = e.currentTarget.dataset.note;
    let noteContent = this.data.noteContent;
    
    // 如果已有备注，用逗号分隔，否则直接添加
    if (noteContent) {
      noteContent += `, ${note}`;
    } else {
      noteContent = note;
    }
    
    this.setData({
      noteContent: noteContent
    });
  },
  
  /**
   * 清除备注内容
   */
  clearNoteContent: function() {
    this.setData({
      noteContent: ''
    });
  },
  
  /**
   * 截断字符串，只显示指定长度的字符，其余用省略号代替
   */
  truncateString: function(str, length = 20) {
    if (!str || typeof str !== 'string') {
      return '';
    }
    if (str.length <= length) {
      return str;
    }
    return str.substring(0, length) + '……';
  },
  
  /**
   * 打开餐具选择对话框
   */
  openTablewareDialog: function() {
    this.setData({
      showTablewareDialog: true
    });
  },
  
  /**
   * 关闭餐具选择对话框
   */
  closeTablewareDialog: function() {
    this.setData({
      showTablewareDialog: false
    });
  },
  
  /**
   * 选择餐具数量
   */
  selectTableware: function(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      selectedTableware: index,
      showTablewareDialog: false
    });
  },
  
  /**
   * 打开发票对话框
   */
  openInvoiceDialog: function() {
    wx.showToast({ title: '发票功能待实现', icon: 'none' });
  },
  
  /**
   * 生成取餐号
   * 格式为大写字母-5位数字（A-00001）
   * 每有一个人选择预计取餐则数字+1
   * 每天凌晨4点刷新重新从A-00001开始
   */
  generatePickupNumber: function() {
    // 获取当前时间
    const now = new Date();
    
    // 从本地存储获取取餐号相关信息
    let pickupInfo = wx.getStorageSync('pickupNumberInfo') || {};
    let { resetTimestamp = 0, currentLetter = 'A', currentNumber = 1 } = pickupInfo;
    
    // 计算今天凌晨4点的时间戳
    const today = new Date(now);
    today.setHours(4, 0, 0, 0);
    let resetTimeToday = today.getTime();
    
    // 如果现在的时间小于今天凌晨4点，则重置时间应该是昨天的凌晨4点
    if (now.getTime() < resetTimeToday) {
      resetTimeToday = new Date(today.getTime() - 24 * 60 * 60 * 1000).getTime();
    }
    
    // 检查是否需要重置
    if (resetTimestamp !== resetTimeToday) {
      // 重置为A-00001
      currentLetter = 'A';
      currentNumber = 1;
      resetTimestamp = resetTimeToday;
    }
    
    // 生成5位数字字符串，不足补0
    const formattedNumber = String(currentNumber).padStart(5, '0');
    
    // 构建取餐号
    const pickupNumber = `${currentLetter}-${formattedNumber}`;
    
    // 更新计数器（每有一个人选择预计取餐则数字+1）
    currentNumber++;
    
    // 如果数字达到99999，字母进位
    if (currentNumber > 99999) {
      currentNumber = 1;
      // 字母从A到Z循环
      if (currentLetter === 'Z') {
        currentLetter = 'A';
      } else {
        currentLetter = String.fromCharCode(currentLetter.charCodeAt(0) + 1);
      }
    }
    
    // 保存更新后的信息到本地存储
    wx.setStorageSync('pickupNumberInfo', {
      resetTimestamp,
      currentLetter,
      currentNumber
    });
    
    return pickupNumber;
  },
  
  /**
   * 提交订单
   */
  submitOrder: function() {
    try {
      console.log('开始提交订单...');
      
      // 数据验证
      if (!this.data.totalPrice || this.data.totalPrice <= 0) {
        wx.showToast({ 
          title: '订单金额无效', 
          icon: 'none'
        });
        return;
      }
      
      if (!this.data.orderItems || this.data.orderItems.length === 0) {
        wx.showToast({ 
          title: '订单必须包含商品', 
          icon: 'none'
        });
        return;
      }
      
      // 如果是外送订单，验证地址信息
      if (this.data.deliveryMethod === '外送') {
        if (!this.data.address || !this.data.address.id) {
          wx.showToast({ 
            title: '请选择收货地址', 
            icon: 'none'
          });
          return;
        }
        if (!this.data.address.name) {
          wx.showToast({ 
            title: '收货人姓名不能为空', 
            icon: 'none'
          });
          return;
        }
        if (!this.data.address.phone) {
          wx.showToast({ 
            title: '收货人电话不能为空', 
            icon: 'none'
          });
          return;
        }
      }
      
      // 如果是自取订单，生成新的取餐号
      const pickupNumber = this.data.deliveryMethod === '自取' ? this.generatePickupNumber() : null;
      
      // 更新取餐号
      this.setData({ pickupNumber });
      
      // 转换商品项格式以匹配后端要求
      const items = this.data.orderItems.map(item => ({
        product_id: item.id || '',
        product_name: item.name || '',
        price: Number(item.price) || 0,
        quantity: Number(item.quantity) || 0,
        subtotal: (Number(item.price) || 0) * (Number(item.quantity) || 0)
      }));
      
      // 验证商家ID
      if (!this.data.merchantId) {
        wx.showToast({ 
          title: '商家信息缺失，请重新选择商家', 
          icon: 'none',
          duration: 3000
        });
        return;
      }
      
      // 验证并格式化商家ID
      let merchantId = String(this.data.merchantId || '').trim();
      if (!merchantId) {
        wx.showToast({ 
          title: '商家ID缺失，请返回重新选择', 
          icon: 'none',
          duration: 3000
        });
        return;
      }
      
      console.log('提交订单时的商家ID:', merchantId, '类型:', typeof merchantId);
      
      // 收集订单信息（符合后端API格式要求）
      const orderData = {
        total_amount: Number(this.data.totalPrice),
        payment_method: 'points',
        order_type: this.data.deliveryMethod === '自取' ? 'dine_in' : 'takeaway',
        remark: this.data.noteContent || null,
        items: items,
        pickup_number: pickupNumber,
        utensils: Number(this.data.selectedTableware) || 0,
        merchant_id: merchantId
        // 不包含user_coupon_id，因为数据库表中没有这个字段
      };
      
      // 如果是外送订单，添加配送地址信息
      if (this.data.deliveryMethod === '外送' && this.data.address) {
        // 构建完整地址，确保包含详细地址（如"时羊村123"）
        // 优先使用 location（已通过 formatLocation 格式化，包含详细地址）
        // 如果 location 不存在，则手动拼接，确保包含 detail 字段
        let fullAddress = '';
        if (this.data.address.location) {
          fullAddress = this.data.address.location;
        } else {
          const province = this.data.address.province || '';
          const city = this.data.address.city || '';
          const district = this.data.address.district || '';
          const detail = this.data.address.detail || this.data.address.detail_address || this.data.address.address || '';
          fullAddress = `${province}${city}${district}${detail}`;
        }
        
        console.log('提交订单时的完整地址（包含详细地址）:', fullAddress);
        orderData.delivery_address = fullAddress;
        orderData.recipient_name = this.data.address.name || '';
        orderData.recipient_phone = this.data.address.phone || '';
        
        console.log('配送地址信息:', {
          delivery_address: orderData.delivery_address,
          recipient_name: orderData.recipient_name,
          recipient_phone: orderData.recipient_phone
        });
      }
      
      // 添加配送时间：如果选择立即配送，传递 null；否则传递选择的时间
      if (this.data.deliveryMethod === '外送') {
        if (this.data.deliveryTime && this.data.deliveryTime.estimatedTime && this.data.deliveryTime.estimatedTime !== '立即配送') {
          orderData.scheduledDeliveryTime = this.data.deliveryTime.estimatedTime;
        } else {
          orderData.scheduledDeliveryTime = null;
        }
      } else if (this.data.deliveryMethod === '自取') {
        if (this.data.pickupTime && this.data.pickupTime.estimatedTime && this.data.pickupTime.estimatedTime !== '立即自取' && this.data.pickupTime.estimatedTime !== '请选择') {
          orderData.scheduledDeliveryTime = this.data.pickupTime.estimatedTime;
        } else {
          orderData.scheduledDeliveryTime = null;
        }
      }
      
      // 添加配送费（外送时）
      if (this.data.deliveryMethod === '外送') {
        orderData.delivery_fee = this.data.deliveryFee || 0;
      }
      
      console.log('提交的订单数据:', JSON.stringify(orderData));
      
      // 显示订单提交中提示
      wx.showLoading({ title: '提交订单中...' });
      
      // 获取token
      const token = wx.getStorageSync('token');
      console.log('使用的token:', token ? '存在' : '不存在');
      
      // 调用后端API创建订单
      wx.request({
        url: getApiUrl('/order'),
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          'Authorization': token ? `Bearer ${token}` : ''
        },
        data: orderData,
        success: (res) => {
          wx.hideLoading();
          console.log('API响应状态码:', res.statusCode);
          console.log('API响应数据:', JSON.stringify(res.data));
          
          if (res.statusCode === 200 && res.data && res.data.success !== false) {
            // 保存订单信息到本地存储
            const orderInfo = {
              orderId: res.data.data?.orderId || res.data.orderId,
              orderNo: res.data.data?.orderNo || res.data.orderNo,
              ...orderData
            };
            wx.setStorageSync('lastOrder', orderInfo);
            
            // 获取订单信息用于跳转
            const orderId = orderInfo.orderId || '';
            const orderNo = orderInfo.orderNo || '';
            const totalAmount = this.data.totalPrice || 0;
            const deliveryMethod = this.data.deliveryMethod || '外送';
            
            // 跳转到支付成功页面
            wx.redirectTo({
              url: `/pages/pay_success/pay_success?orderId=${orderId}&orderNo=${orderNo}&totalAmount=${totalAmount}&deliveryMethod=${deliveryMethod}`
            });
          } else {
            const errorMsg = res.data?.message || res.data?.error || '订单提交失败';
            console.log('订单提交失败原因:', errorMsg);
            wx.showToast({ 
              title: errorMsg,
              icon: 'none',
              duration: 3000
            });
          }
        },
        fail: (err) => {
          wx.hideLoading();
          console.error('订单提交失败:', JSON.stringify(err));
          wx.showToast({ 
            title: '网络异常，请稍后重试', 
            icon: 'none',
            duration: 3000
          });
        }
      });
    } catch (error) {
      wx.hideLoading();
      console.error('提交订单过程中发生异常:', JSON.stringify(error));
      wx.showToast({ 
        title: '提交订单时发生错误', 
        icon: 'none',
        duration: 3000
      });
    }
  },
  
  /**
   * 图片加载错误处理
   */
  onImageError: function(e) {
    const type = e.currentTarget.dataset.type;
    console.warn('图片加载失败:', type, e);
    
    // 根据类型设置默认值
    if (type === 'logo') {
      this.setData({
        'merchantInfo.logo': '' // 设置为空，不显示图片
      });
    }
  },

  /**
   * 返回上一页
   */
  navigateBack: function() {
    wx.navigateBack();
  }
});