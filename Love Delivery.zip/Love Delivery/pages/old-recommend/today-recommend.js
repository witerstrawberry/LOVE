const app = getApp();
const { productAPI, cartAPI, orderAPI, aiAPI, merchantAPI, addressAPI } = require('../../utils/api.js');
const { getFullImageUrl } = require('../../utils/imageUtils');

// 将价格标准化为数字，容忍字符串、带货币符号的格式
function normalizePrice(val) {
  if (typeof val === 'number') return val;
  if (typeof val === 'string') {
    // 提取数字和小数点
    const matched = val.match(/[\d\.]+/g);
    if (matched && matched.length) {
      return parseFloat(matched.join('')) || 0;
    }
  }
  return 0;
}
// 根据商品名称拉取商品图的辅助方法（只在AI未返回图片时才调用）
async function buildProductImageMap() {
  try {
    const res = await productAPI.getProducts();
    // 兼容多种返回结构
    const list =
      (res && res.data && Array.isArray(res.data) && res.data) ||
      (res && res.data && res.data.products && Array.isArray(res.data.products) && res.data.products) ||
      [];
    const map = {};
    list.forEach(item => {
      if (item && item.name) {
        map[item.name] = item.image_url || item.image || '';
      }
    });
    return map;
  } catch (e) {
    console.warn('获取商品图片映射失败:', e);
    return {};
  }
}
Page({
  data: {
    recommendedDishes: [],
    nutritionTip: '',
    isLoading: false,
    userInfo: {},
    nutritionNeeds: [],
    merchantId: '',
    defaultAddress: {},
    utensilsOptions: ['按餐量提供', '一份餐具', '两份餐具', '三份餐具'],
    utensilsIndex: 0,
    cartCounts: {}, // 记录每个菜品已加购数量
    totalCount: 0,
    totalPrice: 0
  },
  onLoad: function() {
    this.getUserInfo();
    this.loadMerchantInfo();
    this.loadDefaultAddress();
    this.getAIDishRecommendations();
  },
  // 餐具选择
  onUtensilsChange: function(e) {
    const idx = Number(e.detail.value) || 0;
    this.setData({ utensilsIndex: idx });
  },
  onShow: function() {
    // 页面显示时可以刷新推荐
  },
  // 获取用户信息
  getUserInfo: function() {
    const userInfo = wx.getStorageSync('userInfo') || {};
    const nutritionNeeds = wx.getStorageSync('nutritionNeeds') || ['低盐', '低脂', '易消化'];
    this.setData({
      userInfo,
      nutritionNeeds
    });
  },
  // 获取商家信息（公开接口），写入缓存和页面状态
  loadMerchantInfo: function() {
    const cachedId = wx.getStorageSync('merchantId');
    const params = cachedId ? { merchantId: cachedId } : {};
    merchantAPI.getPublicMerchantInfo(params)
      .then(res => {
        let merchantData = null;
        if (res && typeof res === 'object') {
          // 兼容多种返回结构
          if (res.success && res.data) {
            merchantData = res.data;
          } else if (res.data && res.data.merchant) {
            merchantData = res.data.merchant;
          } else if (res.data) {
            merchantData = res.data;
          } else if (res.merchant) {
            merchantData = res.merchant;
          }
        }

        const resolvedId = merchantData && (merchantData.id || merchantData.merchant_id);
        if (resolvedId) {
          wx.setStorageSync('merchantId', resolvedId);
          this.setData({ merchantId: resolvedId });
        }
      })
      .catch(err => {
        console.warn('获取商家信息失败，使用缓存/默认:', err);
        if (cachedId) {
          this.setData({ merchantId: cachedId });
        }
      });
  },
  // 获取当前登录用户的默认地址（从本地缓存拉取一次）
  loadDefaultAddress: function() {
    const cached = wx.getStorageSync('defaultAddress') || {};
    this.setData({ defaultAddress: cached });

    const userInfo = wx.getStorageSync('userInfo') || {};
    const userId = userInfo.id || userInfo.userId || '';
    if (!userId) return;

    // 调后端地址列表，取默认地址或第一个地址
    addressAPI.getAddressList({ userId, pageSize: 20 })
      .then(res => {
        let list = [];
        if (res && res.data && Array.isArray(res.data.list)) {
          list = res.data.list;
        } else if (Array.isArray(res)) {
          list = res;
        }

        if (!list.length) return;

        const defaultAddr = list.find(a => a.is_default) || list[0];
        if (defaultAddr) {
          const formatted = {
            id: defaultAddr.id,
            name: defaultAddr.name || defaultAddr.receiver_name || defaultAddr.recipient_name || '',
            phone: defaultAddr.phone || defaultAddr.contact_phone || '',
            province: defaultAddr.province || '',
            city: defaultAddr.city || '',
            district: defaultAddr.district || '',
            detail: defaultAddr.detail || defaultAddr.detail_address || defaultAddr.address || ''
          };
          wx.setStorageSync('defaultAddress', formatted);
          this.setData({ defaultAddress: formatted });
        }
      })
      .catch(err => {
        console.warn('获取默认地址失败，沿用缓存:', err);
      });
  },
  // 调用 AI API 获取推荐菜品
  getAIDishRecommendations: function() {
    this.setData({ isLoading: true });
    // 准备请求数据
    const requestData = {
      userInfo: this.data.userInfo,
      nutritionNeeds: this.data.nutritionNeeds,
      currentDate: new Date().toISOString(),
      preferences: wx.getStorageSync('foodPreferences') || []
    };
    // 使用的 aiAPI 模块调用菜品推荐接口
    aiAPI.getDishRecommendations(requestData)
      .then(async data => {
        // 检查返回的数据结构，确保有必要的字段
        const dishes = data.dishes || data.recommendations || [];
        const nutritionTip = data.nutritionTip || data.advice || '今天的推荐菜品注重营养均衡，适合您的健康需求。';
        // 如果AI未返回图片，则尝试从商品列表中匹配图片
        let productImageMap = {};
        const needImage = dishes.some(dish => !(dish.image || dish.imgUrl || dish.image_url));
        if (needImage) {
          productImageMap = await buildProductImageMap();
        }
        this.setData({
          // 仅使用后端返回的图片，不再使用本地兜底；若后端未提供图片，则置空
          recommendedDishes: dishes.map(dish => {
            const name = dish.name || dish.title || '';
            const imagePath = dish.image || dish.imgUrl || dish.image_url || productImageMap[name] || '';
            const image = imagePath ? getFullImageUrl(imagePath) : '';
            const rawId = dish.id || dish.productId || `dish_${Date.now()}_${Math.random()}`;
            const id = String(rawId);
            const price = normalizePrice(dish.price || dish.cost || 0);
            return {
              id,
              name: dish.name || dish.title || '未知菜品',
              description: dish.description || dish.desc || '暂无描述',
              price,
              image,
              nutrition: dish.nutrition || {},
              count: this.data.cartCounts[id] || 0
            };
          }),
          nutritionTip,
          isLoading: false
        });
                // 缓存推荐结果
        wx.setStorageSync('lastRecommendations', this.data.recommendedDishes);
      })
      .catch(error => {
        console.error('AI 推荐失败:', error);
        wx.showToast({
          title: '获取推荐失败',
          icon: 'none'
        });
        // 失败时使用模拟数据
        this.useMockData();
      });
  },


  // 当API调用失败时，显示空状态
  useMockData: function() {
    // 不使用模拟数据，直接显示空状态
    this.setData({
      recommendedDishes: [],
      nutritionTip: '获取推荐失败，请稍后重试',
      isLoading: false
    });
  },

  // 添加到购物车
  addToCart: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const idx = e.currentTarget.dataset.idx;
    // 兼容字符串/数字ID
    const dish = this.data.recommendedDishes.find(d => d.id == dishId);
    
    if (dish) {
      // 本地先行更新数量，保障体验
      const cartCounts = { ...this.data.cartCounts };
      const key = String(dish.id);
      cartCounts[key] = (cartCounts[key] || 0) + 1;

      // 同步更新推荐列表中的数量，避免依赖异步setData合并
      const recommendedDishes = [...this.data.recommendedDishes];
      if (idx !== undefined && recommendedDishes[idx]) {
        recommendedDishes[idx] = {
          ...recommendedDishes[idx],
          count: cartCounts[key]
        };
      } else {
        // 兜底按ID更新
        const targetIndex = recommendedDishes.findIndex(d => d.id == key);
        if (targetIndex >= 0) {
          recommendedDishes[targetIndex] = {
            ...recommendedDishes[targetIndex],
            count: cartCounts[key]
          };
        }
      }

      this.updateCartState(cartCounts, recommendedDishes);

      // 调用购物车 API 添加菜品
      cartAPI.addToCart(dishId, 1)
        .then(() => {
          wx.showToast({
            title: '已加入购物车',
            icon: 'success'
          });
        })
        .catch(() => {
          // 失败也保持本地数量，提示用户
          wx.showToast({
            title: '网络异常，稍后同步',
            icon: 'none'
          });
        });
    }
  },

  // 更新页面商品数量与合计
  updateCartState(cartCounts, recommendedDishesParam = null) {
    const recommendedDishes = recommendedDishesParam
      ? recommendedDishesParam
      : this.data.recommendedDishes.map(dish => ({
          ...dish,
          count: cartCounts[String(dish.id)] || 0
        }));

    const totalCount = Object.values(cartCounts).reduce((sum, c) => sum + (c || 0), 0);
    const totalPrice = recommendedDishes.reduce((sum, dish) => {
      const qty = cartCounts[String(dish.id)] || 0;
      const priceNum = Number(dish.price) || 0;
      return sum + qty * priceNum;
    }, 0);

    this.setData({
      cartCounts,
      recommendedDishes,
      totalCount,
      totalPrice: Number(totalPrice.toFixed(2))
    });
  },

  // 一键下单全部推荐菜品
  oneClickOrder: function() {
    const { recommendedDishes, cartCounts, defaultAddress, utensilsIndex } = this.data;
    const userInfo = wx.getStorageSync('userInfo') || {};
    const address = defaultAddress && Object.keys(defaultAddress).length ? defaultAddress : (wx.getStorageSync('defaultAddress') || {});
    const merchantId =
      userInfo.merchant_id ||
      userInfo.merchantId ||
      this.data.merchantId ||
      wx.getStorageSync('merchantId') ||
      '';

    // 基于当前状态重新计算，避免使用可能未同步的总价
    const selectedDishes = recommendedDishes.filter(d => (cartCounts[String(d.id)] || 0) > 0);
    const totalAmount = selectedDishes.reduce((sum, dish) => {
      const qty = cartCounts[String(dish.id)] || 0;
      const price = normalizePrice(dish.price);
      return sum + qty * price;
    }, 0);
    const normalizedTotal = Number(totalAmount.toFixed(2));
    const totalCount = Object.values(cartCounts).reduce((s, c) => s + (c || 0), 0);

    if (!selectedDishes.length || normalizedTotal <= 0) {
      wx.showToast({
        title: '请先选择菜品',
        icon: 'none'
      });
      return;
    }

    if (!address || !address.name || !address.phone || !address.detail) {
      wx.showToast({
        title: '请先完善默认收货地址',
        icon: 'none'
      });
      return;
    }

    // 保证页面合计同步展示
    this.setData({ totalPrice: normalizedTotal, totalCount });

    wx.showLoading({ title: '正在下单...' });

    // 按后端期望字段格式传递
    const orderData = {
      total_amount: normalizedTotal,
      merchant_id: merchantId,
      order_type: 'takeaway',
      payment_method: 'online',
      delivery_address: address,
      recipient_name: address.name || userInfo.name || '',
      recipient_phone: address.phone || userInfo.phone || '',
      utensils: utensilsIndex, // 0-按餐量，1/2/3份
      items: selectedDishes.map(dish => {
        const qty = cartCounts[String(dish.id)] || 0;
        const price = normalizePrice(dish.price);
        return {
          product_id: dish.id,
          product_name: dish.name || '',
          quantity: qty,
          price,
          subtotal: Number((qty * price).toFixed(2))
        };
      }),
      remark: 'AI 推荐套餐'
    };

    // 调用创建订单 API
    orderAPI.createOrder(orderData)
      .then(order => {
        wx.hideLoading();
        wx.showModal({
          title: '下单成功',
          content: '下单成功',
          success: res => {
            if (res.confirm) {
              wx.navigateTo({ url: '/pages/orders/my-orders' });
            }
          }
        });
      })
      .catch(error => {
        console.error('下单失败:', error);
        wx.hideLoading();
        // 模拟下单成功
        wx.showModal({
          title: '下单成功',
          content: '下单成功',
          success: res => {
            if (res.confirm) {
              wx.navigateTo({ url: '/pages/orders/my-orders' });
            }
          }
        });
      });
  },

  // 补充：获取营养建议的方法
  getNutritionAdvice: function() {
    aiAPI.getNutritionAdvice(this.data.userInfo.id)
      .then(advice => {
        if (advice && advice.tip) {
          this.setData({ nutritionTip: advice.tip });
        }
      })
      .catch(error => {
        console.error('获取营养建议失败:', error);
      });
  },
  
  // 生命周期方法
  onShareAppMessage: function() {
    return {
      title: '今日菜品推荐 - AI智能搭配',
      path: '/pages/old-recommend/today-recommend'
    };
  },

  // 下拉刷新
  onPullDownRefresh: function() {
    this.getAIDishRecommendations();
    setTimeout(() => {
      wx.stopPullDownRefresh();
    }, 500);
  }
});