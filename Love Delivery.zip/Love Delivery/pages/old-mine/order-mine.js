// 我的页面 - 老人端
const { authAPI, pointsAPI, contactsAPI, orderAPI } = require('../../utils/api');

Page({
  data: {
    // 用户基本信息
    userInfo: {
      name: '',
      age: '',
      avatar: '/images/elder-avatar.png',
      id: ''
    },
    // 联系人信息
    contacts: [
      {
        id: 1,
        name: '女儿 李小红',
        phone: '138****1234',
        relation: '子女'
      },
      {
        id: 2,
        name: '社区志愿者 小王',
        phone: '139****5678',
        relation: '志愿者'
      }
    ],
    // 账户余额（初始值为0，等待从后端API获取真实数据）
    balance: 0,
    // 订单统计（初始值为0，等待API返回）
    orderStats: {
      pending: 0,
      completed: 0,
      cancelled: 0
    },
    // 设置项
    settings: [
      {
        id: 'address',
        name: '收货地址',
        icon: '📍',
        showArrow: true
      },
      {
        id: 'favorite',
        name: '我的收藏',
        icon: '❤️',
        showArrow: true
      },
      {
        id: 'history',
        name: '浏览历史',
        icon: '🕒',
        showArrow: true
      },
      {
        id: 'help',
        name: '帮助中心',
        icon: '❓',
        showArrow: true
      },
      {
        id: 'about',
        name: '关于我们',
        icon: 'ℹ️',
        showArrow: true
      }
    ],
    // 联系人弹窗显示状态
    showContactModal: false,
    // 新联系人信息
    newContact: {
      name: '',
      phone: '',
      relation: ''
    }
  },

  onLoad() {
    // 页面加载时的初始化逻辑
    console.log('我的页面加载');
    // 从后端获取用户信息，然后获取积分余额和联系人列表
    this.getUserProfile().then(() => {
      // 并行获取积分余额、联系人列表和订单统计
      Promise.all([
        this.getUserPointsBalance(),
        this.getContactsFromServer(),
        this.getOrderStats()
      ]).catch(err => {
        console.error('初始化数据获取失败:', err);
      });
    }).catch(err => {
      console.error('获取用户信息失败:', err);
    });
  },
  
  onShow() {
    // 页面显示时刷新订单统计
    // 检查用户是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo && userInfo.id) {
      this.getOrderStats();
    }
  },
  
  // 从服务器获取联系人列表
  getContactsFromServer() {
    return contactsAPI.getContacts()
      .then(res => {
        console.log('从服务器获取联系人列表成功:', res);
        
        if (res.success && res.data && Array.isArray(res.data)) {
          // 格式化联系人数据，适配后端返回的数据结构
          const formattedContacts = res.data.map(contact => {
            // 获取联系人名称，尝试多种可能的字段名
            const contactName = contact.contact_name || 
                               contact.nickname || 
                               contact.contact_user_nickname || 
                               (contact.contact_user_details && contact.contact_user_details.nickname) || 
                               '未设置昵称';
            
            // 获取电话号码并隐藏中间4位
            const contactPhone = contact.contact_phone ? 
                                contact.contact_phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') : 
                                '';
            
            // 获取关系信息
            const relation = contact.relationship || '';
            
            return {
              id: contact.id || Math.floor(Math.random() * 10000),
              name: contactName,
              phone: contactPhone,
              relation: relation,
              // 保留原始数据，方便后续使用
              originalData: contact
            };
          });
          
          console.log('格式化后的联系人列表:', formattedContacts);
          
          // 更新联系人列表
          this.setData({
            contacts: formattedContacts
          });
        }
      })
      .catch(err => {
        console.error('从服务器获取联系人列表失败:', err);
        // 获取失败时继续使用本地数据，不影响用户体验
      });
  },

  // 获取用户信息
  getUserProfile() {
    wx.showLoading({
      title: '加载中...',
    });
    
    return new Promise((resolve, reject) => {
      authAPI.getProfile()
        .then(res => {
          wx.hideLoading();
          console.log('获取用户信息成功:', res);
          
          if (res.success && res.data) {
            const userData = res.data;
            this.setData({
              userInfo: {
                name: userData.nickname || userData.name || '用户',
                age: userData.age || '',
                avatar: userData.avatar || '/images/elder-avatar.png',
                id: userData.id || ''
              }
              // 注意：余额应该从 getUserPointsBalance() API 获取，不从这里获取
              // 因为 getProfile API 返回的是 points 字段，且应该统一使用积分API
            });
          }
          resolve();
        })
        .catch(err => {
          wx.hideLoading();
          console.error('获取用户信息失败:', err);
          wx.showToast({
            title: '获取信息失败',
            icon: 'none'
          });
          reject(err);
        });
    });
  },

  // 地址跳转
  GoToOrderAdress() {
    wx.navigateTo({
      url: '/pages/old_address/addresses'
    });
  },
  // 查看订单列表
  viewOrders(e) {
    const { type } = e.currentTarget.dataset;
    console.log('跳转到订单列表，类型:', type);
    wx.navigateTo({
      url: `/pages/order_list/order_list?type=${type}`,
      success: () => {
        console.log('跳转成功');
      },
      fail: (err) => {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        });
      }
    });
  },

  // 联系某人
  contactPerson(e) {
    const { phone } = e.currentTarget.dataset;
    wx.makePhoneCall({
      phoneNumber: phone.replace(/\*/g, '1'), // 实际应用中应该使用真实电话号码
      success: function() {
        console.log('拨打电话成功');
      },
      fail: function() {
        console.log('拨打电话失败');
      }
    });
  },

  // 设置项点击
  settingItemClick(e) {
    const { id } = e.currentTarget.dataset;
    switch(id) {
      case 'address':
        wx.navigateTo({ url: '/pages/old_address/addresses' });
        break;
      case 'favorite':
        wx.navigateTo({ url: '/pages/collection/index' });
        break;
      case 'history':
        // 跳转到订单列表页面，显示所有订单
        wx.navigateTo({ url: '/pages/order_list/order_list?type=all' });
        break;
      case 'help':
        wx.navigateTo({ url: '/pages/help-center/index' });
        break;
      case 'about':
        wx.navigateTo({ url: '/pages/about/about' });
        break;
      default:
        wx.showToast({
          title: '功能开发中',
          icon: 'none'
        });
    }
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除登录状态
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('token');
          // 跳转到登录页
          wx.redirectTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },
  
  // 获取用户积分余额
  getUserPointsBalance() {
    return pointsAPI.getUserPointsBalance()
      .then(res => {
        console.log('获取积分余额成功:', res);
        
        // 详细处理不同的数据结构
        if (res && res.success && res.data) {
          // 确保只使用数值类型的balance
          const balanceValue = typeof res.data.balance === 'number' ? res.data.balance : 0;
          console.log('设置积分余额:', balanceValue);
          this.setData({
            balance: balanceValue
          });
        } else if (res && !res.success) {
          console.warn('获取积分余额返回失败状态:', res.message);
          // 如果API返回错误但有余额数据，也尝试使用
          if (res.data && typeof res.data.balance === 'number') {
            this.setData({
              balance: res.data.balance
            });
          }
        } else {
          console.warn('获取积分余额返回数据结构异常:', res);
          // 发生异常时确保balance是数值0
          this.setData({
            balance: 0
          });
        }
      })
      .catch(err => {
        console.error('获取积分余额失败:', err);
        // 添加错误提示
        wx.showToast({
          title: '获取积分信息失败',
          icon: 'none',
          duration: 1500
        });
      });
  },

  // 编辑个人资料
  editProfile() {
    wx.navigateTo({
      url: '/pages/edit-profile/edit-profile'
    });
  },

  // 添加联系人
  addContact() {
    // 重置新联系人信息
    this.setData({
      newContact: {
        name: '',
        phone: '',
        relation: ''
      },
      showContactModal: true
    });
  },

  // 关闭联系人弹窗
  closeContactModal() {
    this.setData({ showContactModal: false });
  },

  // 处理姓名输入
  onNameInput(e) {
    this.setData({
      'newContact.name': e.detail.value
    });
  },

  // 处理电话输入
  onPhoneInput(e) {
    this.setData({
      'newContact.phone': e.detail.value
    });
  },

  // 处理关系输入
  onRelationInput(e) {
    this.setData({
      'newContact.relation': e.detail.value
    });
  },

  // 确认添加联系人
  confirmAddContact() {
    const { name, phone, relation } = this.data.newContact;
    
    // 简单的表单验证
    if (!name || !phone || !relation) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }
    
    // 验证电话号码格式（简单验证）
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({
        title: '请输入正确的手机号码',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '添加中...',
    });
    
    // 调用后端API添加联系人
    // 根据后端API要求，需要提供contact_user_id、contact_role_id和relationship字段
    // 这里使用临时ID和默认角色ID，实际应用中应该从用户选择或系统获取
    contactsAPI.createContact({
      contact_user_id: Math.floor(Math.random() * 10000), // 临时生成的用户ID
      contact_role_id: 2, // 假设默认角色ID为2（可以根据实际情况调整）
      relationship: relation, // 将前端的relation映射到后端的relationship
      contact_phone: phone // 添加电话号码字段
    })
    .then(res => {
      wx.hideLoading();
      console.log('联系人添加到后端成功:', res);
      
      // 获取后端返回的联系人ID或使用本地生成的ID
      const newId = res.data?.id || Math.max(...this.data.contacts.map(contact => contact.id), 0) + 1;
      
      // 格式化电话号码（隐藏中间4位）
      const formattedPhone = phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
      
      // 创建新联系人对象
      const contactToAdd = {
        id: newId,
        name,
        phone: formattedPhone,
        relation
      };
      
      // 添加到联系人列表
      const updatedContacts = [...this.data.contacts, contactToAdd];
      
      // 更新数据
      this.setData({
        contacts: updatedContacts,
        showContactModal: false
      });
      
      // 显示添加成功提示
      wx.showToast({
        title: '添加成功',
        icon: 'success'
      });
    })
    .catch(err => {
      wx.hideLoading();
      console.error('联系人添加到后端失败:', err);
      
      // 即使后端失败，也可以先添加到本地
      wx.showModal({
        title: '添加结果',
        content: '联系人已添加到本地，但同步到服务器失败。请检查网络连接后重试。',
        showCancel: false,
        success: (resModal) => {
          if (resModal.confirm) {
            // 生成新联系人的ID
            const newId = Math.max(...this.data.contacts.map(contact => contact.id), 0) + 1;
            
            // 格式化电话号码（隐藏中间4位）
            const formattedPhone = phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
            
            // 创建新联系人对象
            const contactToAdd = {
              id: newId,
              name,
              phone: formattedPhone,
              relation
            };
            
            // 添加到联系人列表
            const updatedContacts = [...this.data.contacts, contactToAdd];
            
            // 更新数据
            this.setData({
              contacts: updatedContacts,
              showContactModal: false
            });
          }
        }
      });
    });
  },

  // 获取订单统计信息
  getOrderStats() {
    console.log('开始获取订单统计信息...');
    return orderAPI.getOrderStats()
      .then(res => {
        console.log('获取订单统计API完整响应:', JSON.stringify(res, null, 2));
        
        // 处理不同的响应格式
        let statsData = null;
        if (res && res.success && res.data) {
          statsData = res.data;
          console.log('从 res.data 获取统计数据:', statsData);
        } else if (res && res.data && !res.success) {
          // 有些API可能直接返回data
          statsData = res.data;
          console.log('从 res.data (无success) 获取统计数据:', statsData);
        } else if (res && typeof res.pending !== 'undefined') {
          // 如果直接返回统计数据对象
          statsData = res;
          console.log('直接使用 res 作为统计数据:', statsData);
        } else {
          console.warn('无法识别响应格式:', res);
        }
        
        if (statsData) {
          // 更新订单统计数据，确保所有字段都是数字
          const newStats = {
            pending: parseInt(statsData.pending) || 0,
            completed: parseInt(statsData.completed) || 0,
            cancelled: parseInt(statsData.cancelled) || 0
          };
          
          console.log('解析后的订单统计数据:', newStats);
          console.log('原始数据 - pending:', statsData.pending, '类型:', typeof statsData.pending);
          console.log('原始数据 - completed:', statsData.completed, '类型:', typeof statsData.completed);
          console.log('原始数据 - cancelled:', statsData.cancelled, '类型:', typeof statsData.cancelled);
          
          this.setData({
            orderStats: newStats
          });
          console.log('订单统计已更新，当前页面数据:', this.data.orderStats);
        } else {
          console.warn('订单统计数据格式异常，使用默认值:', res);
          // 如果数据格式异常，重置为0
          this.setData({
            orderStats: {
              pending: 0,
              completed: 0,
              cancelled: 0
            }
          });
        }
      })
      .catch(err => {
        console.error('获取订单统计失败:', err);
        console.error('错误详情:', JSON.stringify(err, null, 2));
        // 获取失败时重置为0，确保界面显示正常
        this.setData({
          orderStats: {
            pending: 0,
            completed: 0,
            cancelled: 0
        }
      });
    });
  }
});