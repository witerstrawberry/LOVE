/**
 * 用户存储管理工具
 */

// 用户信息存储键名
const USER_INFO_KEY = 'userInfo';

/**
 * 获取用户信息
 * @returns {Object} 用户信息对象，包含角色信息等
 */
function getUserInfo() {
  try {
    const userInfoData = wx.getStorageSync(USER_INFO_KEY);
    
    // 检查数据是否存在
    if (!userInfoData) {
      return null;
    }
    
    // 检查数据类型，如果已经是对象就直接返回
    if (typeof userInfoData === 'object') {
      return userInfoData;
    }
    
    // 如果是字符串类型，尝试解析JSON
    if (typeof userInfoData === 'string') {
      return JSON.parse(userInfoData);
    }
    
    return null;
  } catch (error) {
    console.error('获取用户信息失败:', error);
    // 解析失败时，可以尝试清理存储的数据
    try {
      wx.removeStorageSync(USER_INFO_KEY);
      console.log('已清理损坏的用户信息存储');
    } catch (cleanError) {
      console.error('清理用户信息存储失败:', cleanError);
    }
    return null;
  }
}

/**
 * 设置用户信息
 * @param {Object} userInfo 用户信息对象
 */
function setUserInfo(userInfo) {
  try {
    wx.setStorageSync(USER_INFO_KEY, JSON.stringify(userInfo));
    return true;
  } catch (error) {
    console.error('设置用户信息失败:', error);
    return false;
  }
}

/**
 * 清除用户信息
 */
function clearUserInfo() {
  try {
    wx.removeStorageSync(USER_INFO_KEY);
    return true;
  } catch (error) {
    console.error('清除用户信息失败:', error);
    return false;
  }
}

module.exports = {
  getUserInfo,
  setUserInfo,
  clearUserInfo
};